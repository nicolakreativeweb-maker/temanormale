<?php
/**
 * Part — Griglia full page pagine figlie (shortcode shortcode_grid_pagine_figlie)
 * NKCS041126 — la query arriva da nkcs_pagine_figlie_query() ($nkcs_query,
 * impostata in modulo.php). Card con immagine di copertina (immagine in
 * evidenza della pagina figlia) a tutta card, titolo e descrizione centrati.
 * Titolo e descrizione dai campi card del gruppo group_nkcs_seo
 * (nkcs_seo_is_card, nkcs_seo_card_titolo, nkcs_seo_card_desc), con gli stessi
 * fallback della lista (titolo pagina, excerpt manuale).
 */

if (!defined('ABSPATH')) exit;
?>

<?php if ($nkcs_query->have_posts()) : ?>
    <div class="nkcs-grid-full">
        <?php while ($nkcs_query->have_posts()) : $nkcs_query->the_post();

            // Campi card attivi solo con "Mostra come card"
            $is_card     = (bool) get_field('nkcs_seo_is_card');
            $card_titolo = ($is_card ? get_field('nkcs_seo_card_titolo') : '') ?: get_the_title();

            // Descrizione card: excerpt manuale se presente, altrimenti descrizione card ACF
            global $post;
            $card_desc = !empty($post->post_excerpt)
                ? $post->post_excerpt
                : ($is_card ? get_field('nkcs_seo_card_desc') : '');
        ?>
            <a href="<?php the_permalink(); ?>" class="nkcs-grid-full__item">
                <?php if (has_post_thumbnail()) : ?>
                    <?php the_post_thumbnail('large', ['class' => 'nkcs-grid-full__item-img', 'loading' => 'lazy', 'alt' => '']); ?>
                <?php endif; ?>
                <span class="nkcs-grid-full__item-overlay" aria-hidden="true"></span>
                <span class="nkcs-grid-full__item-body">
                    <h3 class="nkcs-grid-full__item-title"><?php echo esc_html($card_titolo); ?></h3>
                    <?php if ($card_desc) : ?>
                        <p class="nkcs-grid-full__item-excerpt">
                            <?php echo esc_html(wp_trim_words($card_desc, 20, '…')); ?>
                        </p>
                    <?php endif; ?>
                </span>
                <?php // NKCS111126 — freccia in alto a destra, img/arrow-right.png, dentro un cerchio che in hover della card prende lo sfondo (decorativa: tutta la card è il link) ?>
                <span class="nkcs-grid-full__item-arrow" aria-hidden="true">
                    <img src="<?php echo esc_url(TEMPLATE_URI . 'img/arrow-right.png'); ?>" alt="" width="20" height="15" loading="lazy">
                </span>
            </a>
        <?php endwhile; ?>
    </div>
<?php endif; ?>
<?php wp_reset_postdata(); ?>
