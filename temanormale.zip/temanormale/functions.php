<?php
// Costanti
if (!defined('TEMPLATE_URI')) {
    define('TEMPLATE_URI', get_template_directory_uri() . '/');
}

define('ICL_DONT_LOAD_LANGUAGE_SELECTOR_CSS', true);


function get_permalink_by_path($path)
{
    $page = get_page_by_path($path);
    return $page ? esc_url(get_permalink($page->ID)) : '#';
}

// SETUP DEL TEMA
if (!function_exists('nb_setup_tema')) {
    function nb_setup_tema()
    {
        load_textdomain('nkb', get_template_directory() . './languages');
        add_theme_support('html5', array('comment-list', 'comment-form', 'search-form', 'gallery', 'caption', 'style', 'script'));
        add_theme_support('title-tag');
        add_theme_support('menus');
        add_theme_support('post-thumbnails');
        add_post_type_support('page', 'excerpt'); // opzionale se vuoi anche nelle pagine
        add_theme_support('widgets');

        register_nav_menus([
            'primary' => 'Menu Principale',
            'footer' => 'Menu footer',
            'paesi' => 'Menu paesi'
        ]);
    }
    add_action('after_setup_theme', 'nb_setup_tema');
}

// Dati globali: caricati per primi, gli altri file ne dipendono.
require_once get_theme_file_path('inc/contatti/contatti.php');
require_once get_theme_file_path('inc/assets/assets.php');
require_once get_theme_file_path('inc/admin/admin.php');

// Layout: varianti di menu/hero/footer in template-parts/ — NKCS100926
require_once get_theme_file_path('inc/layout/menu.php');
require_once get_theme_file_path('inc/layout/layout.php');

// Registro moduli NKCS — NKCS040926
// I moduli non ancora migrati vengono saltati senza errore.
require_once get_theme_file_path('inc/moduli/nkcs-moduli-init.php');

// Registro blocchi NKCS — NKCS100926
require_once get_theme_file_path('inc/blocks/nkcs-blocks-init.php');

// Shortcode generici (non legati a un modulo) — NKCS170926
require_once get_theme_file_path('inc/shortcode/nkcs-shortcode-sede.php');
require_once get_theme_file_path('inc/shortcode/nkcs-shortcode-sede-form.php'); // NKCS041126

// Nasconde la admin bar solo nel frontend
add_filter('show_admin_bar', '__return_false');
