<?php
/**
 * Modulo Pagine figlie — shortcode generici sulle pagine figlie di una pagina padre
 * NKCS220926 — sostituisce il modulo "lavorazioni" (rimosso insieme a
 * [shortcode_list_lavorazioni] e alla costante NKCS_LAVORAZIONI_PARENT_SLUG).
 * La pagina padre si passa sempre con parent_slug (obbligatorio, niente default):
 *   [shortcode_list_pagine_figlie parent_slug="lavorazioni"]              → griglia
 *   [shortcode_list_pagine_figlie parent_slug="lavorazioni" colonne="4"]  → card per riga (desktop)
 *   [shortcode_swiper_pagine_figlie parent_slug="pali-di-fondazione"]     → swiper
 *   [shortcode_grid_pagine_figlie parent_slug="servizi"]                  → griglia full page, 3 colonne (NKCS041126)
 * parent_slug accetta anche percorsi annidati ("genitore/figlia"), come get_page_by_path().
 * Stili: scss/modules/shortcode/_pagine-figlie-list.scss e _pagine-figlie-swiper.scss
 * JS swiper: js/moduli/swiper-pagine-figlie.js (richiamato da js/main.js)
 */

if (!defined('ABSPATH')) exit;

/**
 * Slug della pagina padre dall'attributo parent_slug dello shortcode.
 *
 * @param array|string $atts Attributi grezzi dello shortcode.
 * @param string       $tag  Nome dello shortcode (per il filtro shortcode_atts_{$tag}).
 * @return string Slug pulito, stringa vuota se non passato.
 */
function nkcs_pagine_figlie_slug($atts, string $tag): string
{
	$atts = shortcode_atts(['parent_slug' => ''], $atts, $tag);
	return trim(sanitize_text_field($atts['parent_slug']), '/');
}

/**
 * Query delle pagine figlie pubblicate, in ordine di menu_order.
 * Il chiamante deve fare wp_reset_postdata() dopo il loop.
 *
 * @param string $slug Slug (o percorso) della pagina padre.
 * @return WP_Query|null null se lo slug è vuoto o la pagina padre non esiste.
 */
function nkcs_pagine_figlie_query(string $slug): ?WP_Query
{
	if ($slug === '') return null;

	$parent = get_page_by_path($slug);

	if (!$parent) {
		if (defined('WP_DEBUG') && WP_DEBUG) {
			error_log('[NKCS] Pagine figlie: pagina padre non trovata: ' . $slug);
		}
		return null;
	}

	return new WP_Query([
		'post_type'      => 'page',
		'post_parent'    => $parent->ID,
		'posts_per_page' => -1,
		'orderby'        => 'menu_order',
		'order'          => 'ASC',
		'post_status'    => 'publish',
	]);
}

/* ==========================================================================
   SHORTCODE
   I part leggono $nkcs_query (e $nkcs_colonne per la griglia) dallo scope
   dell'include.
   ========================================================================== */
add_action('init', function () {

	add_shortcode('shortcode_list_pagine_figlie', function ($atts) {
		$nkcs_query = nkcs_pagine_figlie_query(nkcs_pagine_figlie_slug($atts, 'shortcode_list_pagine_figlie'));
		if (!$nkcs_query) return '';

		// Card per riga su desktop: 2-6, default 3. Sotto i 1200px sempre 2,
		// sotto i 1024px sempre 1 (CSS).
		$atts_colonne = shortcode_atts(['colonne' => 3], $atts, 'shortcode_list_pagine_figlie');
		$nkcs_colonne = max(2, min(6, (int) $atts_colonne['colonne']));

		ob_start();
		include get_theme_file_path('inc/moduli/pagine-figlie/parts/list-pagine-figlie.php');
		return ob_get_clean();
	});

	// NKCS041126 — griglia full page (3 colonne fisse, immagine di copertina + titolo + descrizione)
	add_shortcode('shortcode_grid_pagine_figlie', function ($atts) {
		$nkcs_query = nkcs_pagine_figlie_query(nkcs_pagine_figlie_slug($atts, 'shortcode_grid_pagine_figlie'));
		if (!$nkcs_query) return '';

		ob_start();
		include get_theme_file_path('inc/moduli/pagine-figlie/parts/grid-pagine-figlie.php');
		return ob_get_clean();
	});

	add_shortcode('shortcode_swiper_pagine_figlie', function ($atts) {
		$nkcs_query = nkcs_pagine_figlie_query(nkcs_pagine_figlie_slug($atts, 'shortcode_swiper_pagine_figlie'));
		if (!$nkcs_query) return '';

		ob_start();
		include get_theme_file_path('inc/moduli/pagine-figlie/parts/swiper-pagine-figlie.php');
		return ob_get_clean();
	});
});
