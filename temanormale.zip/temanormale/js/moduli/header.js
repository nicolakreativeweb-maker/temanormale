// Header — NKCS100926 — estratto da main.js (era initHeader() dentro l'IIFE NKCS)
// NKCS180926 — sfondo pieno oltre i 40px di scroll; al reload già scrollati
// lo sfondo compare subito, senza dissolvenza (.is-init sospende la transition).
const SCROLL_OFFSET = 40;

export function initHeader() {
    const header = document.querySelector('.nkcs-header');
    if (!header) return;

    const update = () => header.classList.toggle('scrolled', window.scrollY > SCROLL_OFFSET);

    header.classList.add('is-init');
    update();
    requestAnimationFrame(() => requestAnimationFrame(() => header.classList.remove('is-init')));

    // il browser può ripristinare la posizione di scroll dopo DOMContentLoaded
    window.addEventListener('load', update);
    window.addEventListener('scroll', update, { passive: true });
}
