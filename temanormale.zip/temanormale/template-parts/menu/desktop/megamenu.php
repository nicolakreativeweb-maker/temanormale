<?php

/**
 * Menu desktop — variante megamenu — NKCS131126
 * Sopra i 1024px il menu è lo stesso pannello a tutto schermo del mobile
 * (template-parts/menu/mobile/mobile-menu-fixed.php: hamburger in header +
 * pannello), quindi qui non c'è nulla da stampare.
 * Il file esiste perché NKCS_LAYOUT['menu_desktop'] = 'megamenu' sia una
 * variante esplicita, alternativa a 'orizzontale'.
 */

if (!defined('ABSPATH')) exit;
