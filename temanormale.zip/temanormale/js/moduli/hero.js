// Hero slideshow — NKCS100926 — estratto da main.js (era initHeroSlideshow() dentro l'IIFE NKCS)
// NKCS210926 — riscritto sulla logica di EsteticaChiara (is-active / is-leaving,
// finishLeaving() per i click ravvicinati) + frecce prev/next. Niente dots.
// Agisce SOLO su .nkcs-hero-page--slideshow (template-parts/hero/slideshow.php):
// sulle pagine con la hero statica esce subito.
// NKCS210926 — ogni slide è una pagina: insieme all'immagine cambia anche il testo
// (.nkcs-hero-page__slide-content). Il fade-up dei testi è tutto CSS.
// NKCS210926 — crossfade "pieno" alla negropal.com (vedi _hero.scss), zoom continuo
// con .is-zoom (parte anche sulla prima foto), flash bianco con .is-flashing.
// NKCS210926 — ritmo COSTANTE, in loop infinito. Il mouse sopra
// la hero NON ferma più l'autoplay; un click sulle frecce cambia subito slide e la
// successiva arriva sempre AUTOPLAY_DELAY dopo. Pausa solo con focus da tastiera dentro la
// hero (accessibilità) e con la tab del browser nascosta; con
// prefers-reduced-motion: reduce niente autoplay (le frecce funzionano).
// NKCS220926 — pallini (.nkcs-hero-slides__dot): sincronizzati in goTo(), click =
// vai a quella slide (come le frecce). Visibili solo nella home sotto i 600px
// (vedi _hero.scss), dove le frecce sono nascoste.
// NKCS220926 — ritmo 3.5s (era 4s).
// NKCS230926 — ritmo 5s (era 3.5s): passaggio più lento tra le slide.

export function initHeroSlideshow() {
    const heroSection = document.querySelector('.nkcs-hero-page--slideshow');
    if (!heroSection) return;

    const images = heroSection.querySelectorAll('.nkcs-hero-page__bg-image');
    if (images.length < 2) return;

    const slides = heroSection.querySelectorAll('.nkcs-hero-page__slide-content');
    const btnPrev = heroSection.querySelector('.nkcs-hero-slides__btn--prev');
    const btnNext = heroSection.querySelector('.nkcs-hero-slides__btn--next');
    const dots = heroSection.querySelectorAll('.nkcs-hero-slides__dot');

    // Tempo tra una slide e l'altra in ms — NKCS230926: 10000 (era 5000, prima 3500).
    // Non scendere sotto ~3000: la nuova foto compare in 2s (_hero.scss) e i
    // testi finiscono il fade-up dopo ~1.75s, poi devono restare leggibili.
    // Lo zoom dura 30s: la slide cambia sempre mentre la foto sta zoomando.
    const AUTOPLAY_DELAY = 10000;
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    let current = 0;
    let leavingImageEl = null;
    let leavingTransitionHandler = null;
    let autoplayTimer = null;
    let isFocused = false;

    // Testo della slide visibile: raggiungibile da tastiera e screen reader
    function activateContent(slide) {
        if (!slide) return;
        slide.classList.add('is-active');
        slide.removeAttribute('aria-hidden');
        slide.querySelectorAll('a, button').forEach(el => el.removeAttribute('tabindex'));
    }

    // Testo delle slide nascoste: fuori dal tab e dagli screen reader
    function deactivateContent(slide) {
        if (!slide) return;
        slide.classList.remove('is-active');
        slide.setAttribute('aria-hidden', 'true');
        slide.querySelectorAll('a, button').forEach(el => el.setAttribute('tabindex', '-1'));
    }

    // Pallino della slide attiva
    function updateDots(index) {
        dots.forEach((dot, i) => {
            const active = i === index;
            dot.classList.toggle('is-active', active);
            if (active) {
                dot.setAttribute('aria-current', 'true');
            } else {
                dot.removeAttribute('aria-current');
            }
        });
    }

    // Riporta di colpo a riposo la foto ancora in uscita (click ravvicinati)
    function finishLeaving() {
        if (!leavingImageEl) return;

        if (leavingTransitionHandler) {
            leavingImageEl.removeEventListener('transitionend', leavingTransitionHandler);
            leavingTransitionHandler = null;
        }

        leavingImageEl.classList.add('no-transition');
        leavingImageEl.classList.remove('is-leaving', 'is-zoom');
        void leavingImageEl.offsetWidth; // forza il reflow per applicare subito le classi
        leavingImageEl.classList.remove('no-transition');

        leavingImageEl = null;
    }

    function goTo(index) {
        if (index === current || !images[index]) return;

        // se c'è già un'uscita in corso, chiudila subito
        finishLeaving();

        const outgoing = images[current];
        outgoing.classList.remove('is-active');
        outgoing.classList.add('is-leaving'); // tiene .is-zoom: lo zoom prosegue

        // a fine uscita (solo opacity) torna a riposo e si stacca da solo
        const handler = (e) => {
            if (e.propertyName !== 'opacity') return;
            outgoing.removeEventListener('transitionend', handler);
            outgoing.classList.remove('is-leaving', 'is-zoom');
            if (leavingImageEl === outgoing) leavingImageEl = null;
            if (leavingTransitionHandler === handler) leavingTransitionHandler = null;
        };
        leavingImageEl = outgoing;
        leavingTransitionHandler = handler;
        outgoing.addEventListener('transitionend', handler);

        // --- testo della slide ---
        if (slides.length) {
            deactivateContent(slides[current]);
            activateContent(slides[index]);
        }

        current = index;
        images[current].classList.add('is-active', 'is-zoom');
        updateDots(current);

        // flash bianco: la classe va tolta e rimessa per far ripartire l'animazione
        heroSection.classList.remove('is-flashing');
        void heroSection.offsetWidth;
        heroSection.classList.add('is-flashing');
    }

    // loop infinito: dopo l'ultima torna alla prima (e viceversa)
    function prev() {
        goTo((current - 1 + images.length) % images.length);
    }

    function next() {
        goTo((current + 1) % images.length);
    }

    function stopAutoplay() {
        if (autoplayTimer) {
            clearInterval(autoplayTimer);
            autoplayTimer = null;
        }
    }

    // (Ri)avvia il countdown da zero: la prossima slide arriva sempre AUTOPLAY_DELAY dopo
    function startAutoplay() {
        stopAutoplay();
        if (reducedMotion || isFocused || document.hidden) return;
        autoplayTimer = setInterval(next, AUTOPLAY_DELAY);
    }

    // Frecce — cambiano subito slide; la successiva automatica arriva AUTOPLAY_DELAY dopo il click
    btnPrev?.addEventListener('click', () => { prev(); startAutoplay(); });
    btnNext?.addEventListener('click', () => { next(); startAutoplay(); });

    // Pallini — stessa logica delle frecce
    dots.forEach((dot, i) => {
        dot.addEventListener('click', () => { goTo(i); startAutoplay(); });
    });

    // Drag/swipe con mouse e touch — NKCS220926 — riusa prev()/next(), quindi
    // aggiorna già da sola aria-hidden/tabindex/alt via goTo(). Il cursore "grab"
    // è tutto CSS (.is-dragging in _hero.scss); qui solo la logica del gesto.
    const DRAG_THRESHOLD = 50; // px orizzontali minimi per contare come swipe
    const DRAG_LOCK = 10; // px per capire se il gesto è orizzontale o verticale
    let pointerId = null;
    let dragStartX = 0;
    let dragStartY = 0;
    let dragDeltaX = 0;
    let dragAxis = null; // 'x' | 'y' | null finché non deciso

    function onPointerDown(e) {
        if (e.pointerType === 'mouse' && e.button !== 0) return;
        if (e.target.closest('a, button')) return; // non rubare il click a frecce/link/pulsanti

        pointerId = e.pointerId;
        dragStartX = e.clientX;
        dragStartY = e.clientY;
        dragDeltaX = 0;
        dragAxis = null;
        heroSection.classList.add('is-dragging');
        stopAutoplay();
    }

    function onPointerMove(e) {
        if (e.pointerId !== pointerId) return;

        const deltaX = e.clientX - dragStartX;
        const deltaY = e.clientY - dragStartY;

        if (!dragAxis) {
            if (Math.abs(deltaX) < DRAG_LOCK && Math.abs(deltaY) < DRAG_LOCK) return;
            dragAxis = Math.abs(deltaX) > Math.abs(deltaY) ? 'x' : 'y';
        }

        if (dragAxis === 'y') return; // gesto verticale: lascia scrollare la pagina

        e.preventDefault(); // gesto orizzontale riconosciuto: evita lo scroll touch della pagina
        dragDeltaX = deltaX;
    }

    function onPointerUp(e) {
        if (e.pointerId !== pointerId) return;

        if (dragAxis === 'x' && Math.abs(dragDeltaX) >= DRAG_THRESHOLD) {
            dragDeltaX < 0 ? next() : prev();
        }

        pointerId = null;
        dragAxis = null;
        dragDeltaX = 0;
        heroSection.classList.remove('is-dragging');
        startAutoplay();
    }

    heroSection.addEventListener('pointerdown', onPointerDown);
    heroSection.addEventListener('pointermove', onPointerMove);
    heroSection.addEventListener('pointerup', onPointerUp);
    heroSection.addEventListener('pointercancel', onPointerUp);

    // Pausa su focus da tastiera dentro la hero (:focus-visible: il focus dato dal
    // click del mouse sulle frecce non deve fermare l'autoplay)
    heroSection.addEventListener('focusin', (e) => {
        if (!e.target.matches(':focus-visible')) return;
        isFocused = true;
        stopAutoplay();
    });
    heroSection.addEventListener('focusout', (e) => {
        if (heroSection.contains(e.relatedTarget)) return;
        if (!isFocused) return;
        isFocused = false;
        startAutoplay();
    });

    // Pausa quando la tab del browser non è visibile
    document.addEventListener('visibilitychange', () => {
        document.hidden ? stopAutoplay() : startAutoplay();
    });

    // Zoom anche sulla prima foto: la classe va aggiunta dopo il primo frame,
    // altrimenti il browser non vede il cambio e la transition non parte
    requestAnimationFrame(() => {
        requestAnimationFrame(() => images[current].classList.add('is-zoom'));
    });

    startAutoplay();
}
