<?php
/**
 * Part — Swiper pagine figlie (shortcode shortcode_swiper_pagine_figlie)
 * NKCS220926 — card scura con accento giallo a sinistra, titolo e pillola
 * "Richiedi informazioni": tutta la card porta al permalink della pagina figlia
 * (la pillola è uno span, niente <a> annidati). Dots sotto a destra.
 * NKCS220926 — frecce prev/next in alto a destra, in una pillola bianca divisa
 * in due (SVG di img/arrows/). Stanno FUORI dal .swiper (che ha overflow
 * hidden), dentro il wrapper .nkcs-swiper-pagine-figlie.
 * NKCS220926 — freccia della pillola "Richiedi informazioni" verso destra
 * (arrow-right.svg, era arrow-down.svg).
 * Query da nkcs_pagine_figlie_query() ($nkcs_query, impostata in modulo.php).
 * Titolo: titolo card ACF (nkcs_seo_card_titolo) se "Mostra come card", altrimenti
 * il titolo della pagina — stessa regola della griglia.
 * Init Swiper in js/moduli/swiper-pagine-figlie.js.
 */

if (!defined('ABSPATH')) exit;

$arrows_uri = TEMPLATE_URI . 'img/arrows/';
?>

<?php if ($nkcs_query->have_posts()) : ?>
    <div class="nkcs-swiper-pagine-figlie">

        <div class="nkcs-swiper-pagine-figlie__nav">
            <button type="button" class="nkcs-swiper-pagine-figlie__arrow nkcs-swiper-pagine-figlie__arrow--prev" aria-label="Precedente">
                <img src="<?php echo esc_url($arrows_uri . 'arrow-left.svg'); ?>" alt="" width="26" height="26">
            </button>
            <button type="button" class="nkcs-swiper-pagine-figlie__arrow nkcs-swiper-pagine-figlie__arrow--next" aria-label="Successivo">
                <img src="<?php echo esc_url($arrows_uri . 'arrow-right.svg'); ?>" alt="" width="26" height="26">
            </button>
        </div>

        <div class="nkcs-swiper-pagine-figlie__slider swiper">
            <div class="swiper-wrapper">
                <?php while ($nkcs_query->have_posts()) : $nkcs_query->the_post();

                    $is_card     = (bool) get_field('nkcs_seo_is_card');
                    $card_titolo = ($is_card ? get_field('nkcs_seo_card_titolo') : '') ?: get_the_title();
                ?>
                    <div class="swiper-slide">
                        <a href="<?php the_permalink(); ?>" class="nkcs-swiper-pagine-figlie__card">
                            <span class="nkcs-swiper-pagine-figlie__accent" aria-hidden="true"></span>
                            <h3 class="nkcs-swiper-pagine-figlie__title">
                                <?php echo esc_html($card_titolo); ?>
                            </h3>
                            <span class="nkcs-swiper-pagine-figlie__btn">
                                Scopri di più
                                <img src="<?php echo esc_url($arrows_uri . 'arrow-right.svg'); ?>" alt="" width="14" height="14">
                            </span>
                        </a>
                    </div>
                <?php endwhile; ?>
            </div>
            <div class="swiper-pagination nkcs-swiper-pagine-figlie__pagination"></div>
        </div>

    </div>
<?php endif; ?>
<?php wp_reset_postdata(); ?>
