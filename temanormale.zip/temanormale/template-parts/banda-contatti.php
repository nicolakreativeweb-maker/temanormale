<?php

/**
 * Banda contatti — NKCS220926
 * Stampa il pattern sincronizzato "PATTERN BANDA CONTATTI" (wp_block ID 278),
 * modificabile da Aspetto → Pattern senza toccare il tema.
 * Richiamata da page.php subito prima di get_footer().
 * Sostituisce inc/contatti/banda-contatti.php (puntava al pattern 698, non più esistente).
 * Se il pattern non esiste o non è pubblicato non stampa nulla.
 * do_shortcode(): do_blocks() rende solo i blocchi, gli shortcode scritti
 * nel pattern ([nkcs_sede], [contact-form-7]) li esegue il filtro
 * the_content, che qui non passa.
 */

if (!defined('ABSPATH')) exit;

$nkcs_banda_id = 278; // ID del pattern sincronizzato (Aspetto → Pattern)

if (get_post_status($nkcs_banda_id) !== 'publish') return;

echo do_shortcode(do_blocks('<!-- wp:block {"ref":' . $nkcs_banda_id . '} /-->'));
