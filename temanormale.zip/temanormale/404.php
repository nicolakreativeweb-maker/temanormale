<?php get_header(); ?>

<?php
/* NKCS210926 — linguetta bianca "scorri giù" (template-parts/hero/linguetta.php)
   come nelle altre hero; #content-intro dopo la section come àncora. */
// NKCS041126 — titolo, descrizione e immagine dal gruppo ACF "Pagina 404"
// (Contatti Globali), con fallback ai valori statici.
$nkcs_404    = nkcs_pagina_404();
$hero_id     = $nkcs_404['immagine_id'];
$hero_src    = $hero_id ? wp_get_attachment_image_url($hero_id, 'full') : false;
// NKCS041126 — img/404-not-found.jpg rimossa: senza immagine nei campi ACF la hero resta senza sfondo
$hero_src    = $hero_src ?: '';
$hero_alt    = $hero_id ? (string) get_post_meta($hero_id, '_wp_attachment_image_alt', true) : '';
$hero_titolo = $nkcs_404['titolo'] ?: 'Pagina non trovata';

// Breadcrumb: su 404 abbiamo solo Home + elemento corrente
$breadcrumbs = [
    ['label' => 'Home', 'url' => home_url('/')],
    ['label' => $hero_titolo, 'url' => null],
];
?>

<section class="nkcs-hero-page">

    <div class="nkcs-hero-page__bg">
        <?php if ($hero_src) : ?>
            <img
                src="<?= esc_url($hero_src) ?>"
                alt="<?= esc_attr($hero_alt) ?>"
                width="1920"
                height="1080"
                fetchpriority="high"
                decoding="sync">
        <?php endif; ?>
    </div>

    <div class="nkcs-hero-page__overlay"></div>

    <div class="nkcs-hero-page__content">

        <div class="nkcs-hero-page__content__title-wrapper">

            <nav class="nkcs-breadcrumbs" aria-label="Breadcrumb">
                <?php foreach ($breadcrumbs as $i => $crumb) : ?>
                    <?php if ($crumb['url']) : ?>
                        <a href="<?= esc_url($crumb['url']) ?>" class="nkcs-breadcrumbs__link"><?= esc_html($crumb['label']) ?></a>
                    <?php else : ?>
                        <span class="nkcs-breadcrumbs__current" aria-current="page"><?= esc_html($crumb['label']) ?></span>
                    <?php endif; ?>
                    <?php if ($i < count($breadcrumbs) - 1) : ?>
                        <span class="nkcs-breadcrumbs__sep" aria-hidden="true"></span>
                    <?php endif; ?>
                <?php endforeach; ?>
            </nav>

            <h1 class="nkcs-hero-page__title has-xlarge-font-size">
                <?= esc_html($hero_titolo) ?>
            </h1>

            <?php if ($nkcs_404['descrizione']) : ?>
                <div class="nkcs-hero-page__sub">
                    <?= wp_kses_post($nkcs_404['descrizione']) ?>
                </div>
            <?php endif; ?>

            <?php // NKCS041126 — pulsante secondary, senza freccia ?>
            <div class="flex__center mt--10 gap--10">
                <a class="btn btn--secondary" href="<?= esc_url(home_url('/')) ?>">Torna alla Home</a>
            </div>

        </div>

    </div>

    <?php /* NKCS031126 — linguetta "scorri giù" rimossa dalle hero */ ?>

</section>

<div id="content-intro"></div><!-- NKCS210926 — àncora della linguetta -->

<?php get_footer(); ?>
