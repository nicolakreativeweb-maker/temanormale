<?php

/**
 * SHORTCODE — Sede + Form — NKCS041126
 * ------------------------------------------------------------
 * A sinistra titolo + dati della sede (stesso box di [nkcs_sede]), a destra
 * il form Contact Form 7 in un riquadro vetro.
 *
 * NKCS131126 — rimosso il gruppo ACF "Form Contatti" (nkcs_form_contatti) da
 * Contatti Globali: titolo e form ora si passano solo come attributi dello
 * shortcode (titolo di default "Richiedi maggiori informazioni"; senza
 * attributo form il riquadro del form non viene stampato).
 *
 * Uso:
 *   [nkcs_sede_form]                          → sede principale (prima riga di Sedi)
 *   [nkcs_sede_form slug="sede-principale"]   → sede precisa
 *
 * Attributi:
 *   slug    string  Slug della sede. Vuoto = prima sede.
 *   mappa   bool    "0" per nascondere la mappa. Default: mostrata.
 *   titolo  string  Titolo sopra i dati della sede (vuoto = "Richiedi maggiori informazioni").
 *   form    string  Shortcode CF7 da mostrare a destra (vuoto = nessun form).
 *
 * Stili: scss/components/_sede-form.scss
 *
 * @package NKCS
 */

if (! defined('ABSPATH')) {
    exit;
}

function nkcs_shortcode_sede_form($atts): string
{
    $atts = shortcode_atts([
        'slug'   => '',
        'mappa'  => '1',
        'titolo' => '',
        'form'   => '',
    ], $atts, 'nkcs_sede_form');

    $titolo = trim($atts['titolo']);
    if ($titolo === '') $titolo = 'Richiedi maggiori informazioni';

    $form_sc = trim($atts['form']);

    $sede_html = nkcs_shortcode_sede([
        'slug'   => $atts['slug'],
        'mappa'  => $atts['mappa'],
        'titolo' => '0',
    ]);

    ob_start();
?>
    <div class="nkcs-sede-form">
        <h2 class="nkcs-sede-form__title"><?= esc_html($titolo) ?></h2>

        <div class="nkcs-sede-form__info">
            <?= $sede_html // phpcs:ignore WordPress.Security.EscapeOutput — già escapato in nkcs_shortcode_sede() 
            ?>
        </div>

        <?php if ($form_sc !== '') : ?>
            <div class="nkcs-sede-form__form">
                <?= do_shortcode($form_sc) ?>
            </div>
        <?php endif; ?>
    </div>
<?php
    return ob_get_clean();
}
add_shortcode('nkcs_sede_form', 'nkcs_shortcode_sede_form');
