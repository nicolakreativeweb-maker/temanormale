// Gallery Swiper — slider Swiper + lightbox PhotoSwipe sul blocco acf/gallery-swiper — NKCS110926
// Swiper è globale, caricato a parte (Greenshift): non importato qui (Greenshift).
// PhotoSwipe è esposto su window da inc/assets/assets.php, stesso pattern di gallery-grid.js.

export function initGallerySwiper() {
    const wrappers = document.querySelectorAll('.nkcs-gallery-swiper');
    if (!wrappers.length) return;

    if (!window.Swiper) {
        console.warn('[NKCS] Swiper non disponibile');
        return;
    }

    wrappers.forEach(el => {
        const wrap = el.closest('.nkcs-gallery-swiper-wrap') || el.parentElement;
        const cols = {
            mobile: parseInt(el.dataset.colMobile, 10) || 1,
            tabletSm: parseInt(el.dataset.colTabletSm, 10) || 2,
            tablet: parseInt(el.dataset.colTablet, 10) || 3,
            desktop: parseInt(el.dataset.colDesktop, 10) || 4,
        };

        // Conto le slide reali (escludo eventuali cloni già inseriti da Swiper)
        const slidesCount = el.querySelectorAll('.swiper-slide:not(.swiper-slide-duplicate)').length;

        const prevBtn = wrap.querySelector('.swiper-button-prev');
        const nextBtn = wrap.querySelector('.swiper-button-next');
        const mqMobile = window.matchMedia('(max-width: 600px)');

        let swiper = null;

        // NKCS111126 — frecce visibili solo se c'è qualcosa da scorrere: servono più
        // slide di quelle mostrate nello stesso momento (slidesPerView del breakpoint attivo)
        const syncArrows = () => {
            if (!swiper) return;
            const perView = Number(swiper.params.slidesPerView) || 1;
            const hide = slidesCount <= perView;
            [prevBtn, nextBtn].forEach(btn => btn && btn.classList.toggle('is-hidden', hide));
        };

        const build = () => {
            if (swiper) swiper.destroy(true, true);

            // NKCS111126 — loop SOLO sotto i 600px (basta più di una slide per vista);
            // sopra i 600px mai in loop
            const enableLoop = mqMobile.matches && slidesCount > cols.mobile;

            swiper = new window.Swiper(el, {
                slidesPerView: cols.mobile,
                spaceBetween: 12,
                loop: enableLoop,
                speed: 600,
                grabCursor: true,
                preventClicks: true,
                preventClicksPropagation: true,
                threshold: 5, // NKCS111126 — sotto i 5px è un click, sopra è uno swipe
                navigation: {
                    // NKCS111126 — frecce fuori dal .swiper, nel wrapper (possono sporgere)
                    nextEl: nextBtn,
                    prevEl: prevBtn,
                },
                breakpoints: {
                    0: { slidesPerView: cols.mobile, spaceBetween: 12 },
                    601: { slidesPerView: cols.tabletSm, spaceBetween: 12 },
                    769: { slidesPerView: cols.tablet, spaceBetween: 4 },
                    1025: { slidesPerView: cols.desktop, spaceBetween: 1 },
                },
                on: {
                    breakpoint: syncArrows,
                    resize: syncArrows,
                },
            });

            syncArrows();
        };

        build();

        // Passando la soglia dei 600px il loop va ricalcolato: ricreo lo swiper
        mqMobile.addEventListener('change', build);
    });

    // NKCS111126 — immagini e link non trascinabili (niente "fantasma" del drag nativo)
    wrappers.forEach(el => {
        el.addEventListener('dragstart', (e) => e.preventDefault());
    });

    function initLightbox() {
        if (!window.PhotoSwipeLightbox || !window.PhotoSwipe) {
            console.warn('[NKCS] PhotoSwipe non disponibile');
            return;
        }

        wrappers.forEach(el => {
            if (el.dataset.pswpReady === '1') return; // niente doppia init
            el.dataset.pswpReady = '1';

            // Dataset costruito solo dalle slide reali (no cloni del loop Swiper),
            // nell'ordine del markup PHP: è questo che PhotoSwipe userà per
            // conteggio/counter e navigazione, non i figli presenti nel DOM.
            const realItems = Array.from(
                el.querySelectorAll('.swiper-slide:not(.swiper-slide-duplicate) .nkcs-gallery-swiper__item')
            );
            const dataSource = realItems.map(a => ({
                src: a.getAttribute('href'),
                width: parseInt(a.dataset.pswpWidth, 10),
                height: parseInt(a.dataset.pswpHeight, 10),
                alt: a.querySelector('img')?.alt || '',
            }));

            const lightbox = new window.PhotoSwipeLightbox({
                pswpModule: window.PhotoSwipe,

                zoom: true,
                initialZoomLevel: 'fit',
                secondaryZoomLevel: 2,
                maxZoomLevel: 4,
                wheelToZoom: true,
                pinchToClose: true,

                bgOpacity: 0.92,
                showHideAnimationType: 'fade',
                counter: true,
                close: true,
                arrowKeys: true,
                loop: true,
                preload: [1, 2],

                paddingFn: (viewportSize) => ({
                    top: 30,
                    bottom: viewportSize.x < 768 ? 60 : 30,
                    left: 20,
                    right: 20,
                }),
            });

            lightbox.init();

            // Click su QUALSIASI slide, reale o clonata dal loop di Swiper:
            // risalgo sempre all'indice nel dataset reale tramite l'href,
            // così il counter e la navigazione restano corretti (es. "3 di 8").
            el.addEventListener('click', (e) => {
                const link = e.target.closest('.nkcs-gallery-swiper__item');
                if (!link || !el.contains(link)) return;
                e.preventDefault();

                // NKCS111126 — slide laterale (non interamente visibile): niente
                // lightbox, la gallery scorre verso di lei come con uno swipe.
                const swiperEl = el.swiper;
                const slide = link.closest('.swiper-slide');
                if (swiperEl && slide) {
                    const box = el.getBoundingClientRect();
                    const r = slide.getBoundingClientRect();
                    const tol = 2;
                    if (r.left < box.left - tol) { swiperEl.slidePrev(); return; }
                    if (r.right > box.right + tol) { swiperEl.slideNext(); return; }
                }

                const href = link.getAttribute('href');
                const index = dataSource.findIndex(item => item.src === href);
                if (index === -1) return;

                lightbox.loadAndOpen(index, dataSource);
            });
        });
    }

    if (window.nkcsPhotoSwipeReady) {
        initLightbox();
    } else {
        window.addEventListener('nkcs:photoswipe-ready', initLightbox, { once: true });
    }
}
