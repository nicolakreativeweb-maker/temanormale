// Popup selezione sede — NKCS160926 — namespace NKCS
// Icona "Sedi" nella barra mobile → apre un overlay con l'elenco sedi
// (nome + indirizzo + tel: se presente) letto da data-sedi sul nodo
// #nkcs-sede-popup. NKCS170926 — aggiunto l'indirizzo alla card.

const NKCS = window.NKCS || (window.NKCS = {});

NKCS.initSedePopup = function initSedePopup() {
    const popup = document.getElementById('nkcs-sede-popup');
    const trigger = document.getElementById('nkcs-sede-trigger');
    if (!popup || !trigger) return;

    const list = popup.querySelector('.nkcs-sede-popup__list');
    const closers = popup.querySelectorAll('[data-sede-close]');

    let sedi = [];
    try {
        sedi = JSON.parse(popup.dataset.sedi || '[]');
    } catch (e) {
        sedi = [];
    }

    const renderSedi = () => {
        list.innerHTML = '';

        sedi.forEach((sede) => {
            const item = document.createElement('li');
            item.className = 'nkcs-sede-popup__item';

            const nome = document.createElement('span');
            nome.className = 'nkcs-sede-popup__nome';
            nome.textContent = sede.nome || '';
            item.appendChild(nome);

            if (sede.indirizzo) {
                const query = encodeURIComponent([sede.nome, sede.indirizzo].filter(Boolean).join(', '));
                const indirizzo = document.createElement('a');
                indirizzo.className = 'nkcs-sede-popup__indirizzo';
                indirizzo.href = 'https://www.google.com/maps/search/?api=1&query=' + query;
                indirizzo.target = '_blank';
                indirizzo.rel = 'noopener noreferrer';
                indirizzo.innerHTML = '<i class="fa-solid fa-location-dot" aria-hidden="true"></i>';
                indirizzo.appendChild(document.createTextNode(sede.indirizzo));
                item.appendChild(indirizzo);
            }

            const btnContainer = document.createElement('div');
            btnContainer.className = 'nkcs-sede-popup__btns';

            if (sede.href && sede.numero) {
                const tel = document.createElement('a');
                tel.className = 'nkcs-sede-popup__tel';
                tel.href = sede.href;
                tel.innerHTML = '<i class="fa-solid fa-phone" aria-hidden="true"></i>';
                tel.appendChild(document.createTextNode(sede.numero));
                btnContainer.appendChild(tel);
            }

            if (sede.indirizzo) {
                const query = encodeURIComponent([sede.nome, sede.indirizzo].filter(Boolean).join(', '));
                const mappa = document.createElement('a');
                mappa.className = 'nkcs-sede-popup__mappa';
                mappa.href = 'https://www.google.com/maps/search/?api=1&query=' + query;
                mappa.target = '_blank';
                mappa.rel = 'noopener noreferrer';
                mappa.innerHTML = '<i class="fa-solid fa-map" aria-hidden="true"></i>';
                mappa.appendChild(document.createTextNode('Mappa'));
                btnContainer.appendChild(mappa);
            }

            if (btnContainer.children.length > 0) {
                item.appendChild(btnContainer);
            }

            list.appendChild(item);
        });
    };

    const openPopup = () => {
        renderSedi();
        popup.classList.add('is-open');
        trigger.setAttribute('aria-expanded', 'true');
        document.addEventListener('keydown', onKeydown);
    };

    const closePopup = () => {
        popup.classList.remove('is-open');
        trigger.setAttribute('aria-expanded', 'false');
        document.removeEventListener('keydown', onKeydown);
    };

    const onKeydown = (e) => {
        if (e.key === 'Escape') closePopup();
    };

    trigger.addEventListener('click', openPopup);
    closers.forEach((el) => el.addEventListener('click', closePopup));
};

export function initSedePopup() {
    NKCS.initSedePopup();
}
