<?php

/**
 * Hero — variante pagina (immagine di copertina) — NKCS100926
 * Markup condiviso, usato da page.php. Markup invariato.
 * NKCS100926 — 404.php ha una hero con markup diverso (niente classi sul
 * breadcrumb, niente __sub, niente caret-down): resta inline in 404.php,
 * non usa questa variante.
 * NKCS110926 — pulsanti dal repeater nkcs_seo_pulsanti (nkcs_hero_pulsanti())
 * NKCS170926 — rimosso il riferimento ad archive-necrologi.php (eliminato).
 * NKCS210926 — linguetta bianca "scorri giù" in fondo (template-parts/hero/linguetta.php).
 *
 * NKCS031126 — occhiello (span .nkcs-occhiello--secondary-white) sopra l'H1, da $args['occhiello'].
 * NKCS131126 — occhiello tolto dalla hero.
 *
 * $args attesi:
 *   'src', 'alt', 'width', 'height'  immagine di sfondo
 *   'title'                          string, già risolto dal chiamante
 *   'description'                    string|false, HTML descrizione SEO
 *   'breadcrumbs'                    array di ['label' => string, 'url' => string|null]
 *   'buttons'                        righe del repeater nkcs_seo_pulsanti, opzionale
 *   'class'                          string, classe modificatore opzionale aggiunta alla section
 *                                    (es. 'nkcs-hero-page--home' per la frontpage) — NKCS170926
 */

if (!defined('ABSPATH')) exit;

$nkcs_src         = $args['src'] ?? '';
$nkcs_alt         = $args['alt'] ?? '';
$nkcs_width       = $args['width'] ?? 1920;
$nkcs_height      = $args['height'] ?? 1080;
$nkcs_title       = $args['title'] ?? '';
$nkcs_description = $args['description'] ?? false;
$nkcs_breadcrumbs = $args['breadcrumbs'] ?? [];
$nkcs_buttons     = $args['buttons'] ?? [];
$nkcs_class       = $args['class'] ?? '';
?>

<section class="nkcs-hero-page<?= $nkcs_class ? ' ' . esc_attr($nkcs_class) : '' ?>">

    <div class="nkcs-hero-page__bg">
        <img
            class="skip-lazy no-lazy"
            data-no-lazy="1"
            loading="eager"
            src="<?= esc_url($nkcs_src) ?>"
            alt="<?= esc_attr($nkcs_alt) ?>"
            width="<?= esc_attr($nkcs_width) ?>"
            height="<?= esc_attr($nkcs_height) ?>"
            fetchpriority="high"
            decoding="sync">
    </div>

    <div class="nkcs-hero-page__overlay"></div>

    <div class="nkcs-hero-page__content">

        <div class="nkcs-hero-page__content__title-wrapper">

            <nav class="nkcs-breadcrumbs" aria-label="Breadcrumb">
                <?php foreach ($nkcs_breadcrumbs as $i => $crumb) : ?>
                    <?php if ($crumb['url']) : ?>
                        <a href="<?= esc_url($crumb['url']) ?>" class="nkcs-breadcrumbs__link"><?= esc_html($crumb['label']) ?></a>
                    <?php else : ?>
                        <span class="nkcs-breadcrumbs__current" aria-current="page"><?= esc_html($crumb['label']) ?></span>
                    <?php endif; ?>
                    <?php if ($i < count($nkcs_breadcrumbs) - 1) : ?>
                        <span class="nkcs-breadcrumbs__sep" aria-hidden="true"></span>
                    <?php endif; ?>
                <?php endforeach; ?>
            </nav>

            <h1 class="nkcs-hero-page__title has-xlarge-font-size">
                <?= wp_kses($nkcs_title, ['br' => []]) ?><!-- NKCS100726 -->
            </h1>

            <?php if ($nkcs_description) : ?>
                <div class="nkcs-hero-page__sub">
                    <?= wp_kses_post($nkcs_description) ?>
                </div>
            <?php endif; ?>

            <?php nkcs_hero_pulsanti($nkcs_buttons); ?>
        </div>

    </div>

    <?php /* NKCS031126 — linguetta "scorri giù" rimossa dalle hero */ ?>

</section>
