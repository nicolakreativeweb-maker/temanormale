<?php
/**
 * Formattazione base del sito — syntax highlight admin CF7 + form elements
 * NKCS100926 — spostato da inc/moduli/form/modulo.php
 */

if (!defined('ABSPATH')) exit;

function vf_html_syntax_cf7()
{
    $settings = wp_enqueue_code_editor(array('type' => 'text/html'));
    if ($settings === false) {
        return;
    }

    wp_add_inline_script(
        'code-editor',
        sprintf('jQuery( function() { wp.codeEditor.initialize( "wpcf7-form", %s ); } );', wp_json_encode($settings))
    );
}
add_action('admin_print_styles-toplevel_page_wpcf7', 'vf_html_syntax_cf7');

add_filter('wpcf7_autop_or_not', '__return_false');

add_filter('wpcf7_form_elements', function ($content) {
    $content = str_replace('&lt;a', '<a', $content);
    $content = str_replace('&gt;', '>', $content);
    $content = str_replace('&lt;/a&gt;', '</a>', $content);
    return $content;
});

// Validazione campo Nome e Cognome
add_filter('wpcf7_validate_text*', 'custom_name_validation', 20, 2);
function custom_name_validation($result, $tag)
{
    if ($tag->name == 'your-name') {
        $value = isset($_POST['your-name']) ? trim($_POST['your-name']) : '';
        if ($value === '') {
            $result->invalidate($tag, "Inserisci il tuo nome e il tuo cognome.");
        }
    }
    return $result;
}

// Validazione campo Email
add_filter('wpcf7_validate_email*', 'custom_email_validation', 20, 2);
function custom_email_validation($result, $tag)
{
    if ($tag->name == 'your-email') {
        $value = isset($_POST['your-email']) ? trim($_POST['your-email']) : '';
        if ($value === '') {
            $result->invalidate($tag, "Inserisci la tua email.");
        } elseif (! filter_var($value, FILTER_VALIDATE_EMAIL)) {
            $result->invalidate($tag, "Inserisci un indirizzo email valido.");
        }
    }
    return $result;
}

// Validazione campo Telefono
add_filter('wpcf7_validate_tel*', 'custom_tel_validation', 20, 2);
function custom_tel_validation($result, $tag)
{
    if ($tag->name == 'tel') {
        $value = isset($_POST['tel']) ? trim($_POST['tel']) : '';
        if ($value === '') {
            $result->invalidate($tag, "Inserisci il tuo numero di cellulare.");
        } elseif (! preg_match('/^[0-9\s\+\-]+$/', $value)) {
            $result->invalidate($tag, "Il numero di cellulare non è valido.");
        }
    }
    return $result;
}

add_filter('wpcf7_validate_textarea*', 'custom_message_validation', 20, 2);
function custom_message_validation($result, $tag)
{
    if ($tag->name == 'messaggio') {
        $value = isset($_POST['messaggio']) ? trim($_POST['messaggio']) : '';
        if ($value === '') {
            $result->invalidate($tag, "Inserisci il tuo messaggio.");
        }
    }
    return $result;
}
