<?php

/**
 * Barra mobile fissa — Sedi (popup) + Tel + Scroll-top — NKCS100926
 * Spostato da footer.php. Markup invariato.
 * Interattività (nascondi a fine pagina, scroll to top) in js/moduli/mobile-bar.js.
 *
 * NKCS160926 — aggiunta icona "Sedi": apre un popup con l'elenco sedi
 * (nkcs_contatti()['sedi']) e il relativo numero di telefono, associato per
 * slug tramite nkcs_contatto('telefoni', $slug). Vedi js/moduli/sede-popup.js
 * → initSedePopup(). L'icona telefono resta un link tel: diretto verso la
 * sede principale.
 *
 * NKCS170926 — rimosso il pulsante WhatsApp fluttuante. Barra ridisegnata
 * a "pillola" flottante sopra i 600px (tablet), con la voce aggiuntiva
 * scroll-to-top. Sotto i 600px torna al layout a fascia intera con le sole
 * voci Sedi/Chiama (design precedente).
 *
 * NKCS170926 — rimossa la voce "Necrologi" (i necrologi non esistono più):
 * nella pillola "Chiama" occupa lo spazio restante e mostra l'etichetta
 * (vedi scss/components/_mobile-bar.scss).
 */

if (!defined('ABSPATH')) exit;

$nkcs_contatti = nkcs_contatti();
$nkcs_telefono = $nkcs_contatti['telefono'];

// Elenco sedi per il popup: nome + indirizzo + telefono associato per slug (se presente)
$nkcs_sedi_popup = [];
foreach ($nkcs_contatti['sedi'] as $nkcs_sede) {
    $nkcs_sede_tel = nkcs_contatto('telefoni', $nkcs_sede['slug']);
    $nkcs_indirizzo = trim(wp_strip_all_tags(str_replace(['<br>', '<br/>', '<br />'], ', ', $nkcs_sede['indirizzo'])));
    $nkcs_sedi_popup[] = [
        'nome'      => $nkcs_sede['nome'],
        'indirizzo' => $nkcs_indirizzo,
        'href'      => $nkcs_sede_tel['href'] ?? '',
        'numero'    => $nkcs_sede_tel['numero'] ?? '',
    ];
}
?>

<div class="nkcs-mobile-bar">
    <ul class="nkcs-mobile-bar__list">

        <li class="nkcs-mobile-bar__item nkcs-mobile-bar__item--sede">
            <button type="button"
                class="nkcs-mobile-bar__btn"
                id="nkcs-sede-trigger"
                aria-haspopup="dialog"
                aria-controls="nkcs-sede-popup">
                <i class="fa-solid fa-location-dot" aria-hidden="true"></i>
                <span class="has-large-font-size">Sedi</span>
            </button>
        </li>

        <li class="nkcs-mobile-bar__item nkcs-mobile-bar__item--tel">
            <a class="nkcs-mobile-bar__btn"
                href="tel:<?= esc_attr(preg_replace('/\D+/', '', $nkcs_telefono)) ?>"
                aria-label="Chiama <?= esc_attr($nkcs_telefono) ?>">
                <i class="fa-solid fa-phone" aria-hidden="true"></i>
                <span class="has-large-font-size">Chiama</span>
            </a>
        </li>

        <li class="nkcs-mobile-bar__item nkcs-mobile-bar__item--top">
            <button type="button" class="nkcs-mobile-bar__btn" id="nkcs-scroll-top" aria-label="Torna in cima">
                <i class="fa-solid fa-arrow-up" aria-hidden="true"></i>
            </button>
        </li>

    </ul>
</div><!-- end nkcs-mobile-bar -->

<div class="nkcs-sede-popup"
    id="nkcs-sede-popup"
    data-sedi="<?= esc_attr(wp_json_encode($nkcs_sedi_popup)) ?>">
    <div class="nkcs-sede-popup__overlay" data-sede-close></div>
    <div class="nkcs-sede-popup__box" role="dialog" aria-modal="true" aria-label="Scegli la sede">
        <button type="button" class="nkcs-sede-popup__close" data-sede-close aria-label="Chiudi">
            <i class="fa-solid fa-xmark" aria-hidden="true"></i>
        </button>
        <h3 class="nkcs-sede-popup__title">Le nostre sedi</h3>
        <ul class="nkcs-sede-popup__list"><!-- popolata via JS, vedi initSedePopup() --></ul>
    </div>
</div><!-- end nkcs-sede-popup -->
