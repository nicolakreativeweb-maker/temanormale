<?php
/**
 * Admin — personalizzazioni backend del tema
 * NKCS100926 — spostato da inc/admin.php dentro una cartella propria,
 * in previsione di contenuto futuro (dashboard, colonne admin comuni,
 * capability, ecc. — non ancora utilizzato)
 */

if (!defined('ABSPATH')) exit;

/**
 * CSS admin per la Pagina Opzioni ACF — NKCS100926
 */
add_action('admin_enqueue_scripts', function ($hook) {
    // Carica solo sulla pagina opzioni "contatti-globali"
    if (strpos($hook, 'contatti-globali') === false) return;

    wp_enqueue_style(
        'nkcs-admin-acf',
        get_template_directory_uri() . '/inc/admin/admin-acf.css',
        array(),
        '1.0'
    );
});