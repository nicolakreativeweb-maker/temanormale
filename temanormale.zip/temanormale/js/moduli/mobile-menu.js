// Mobile-menu — slide da destra — NKCS100926 — estratto da main.js (era initMegamenu() dentro l'IIFE NKCS)
// NKCS100926 — rinominati id e classi: nkcs-megamenu-fixed → nkcs-menu-mobile,
// nkcs-navbar-toggle → nkcs-menu-mobile-toggle, nkcs-megamenu-close → nkcs-menu-mobile-close.
// NKCS100926 — file rinominato da megamenu.js, funzione initMegamenu → initMobileMenu.

// === MOBILE MENU IOF Corona — slide da destra (NKCS260626) ===
export function initMobileMenu() {
    const mega = document.getElementById('nkcs-menu-mobile');
    const toggle = document.getElementById('nkcs-menu-mobile-toggle');
    if (!mega || !toggle) return;

    const open = () => {
        mega.classList.add('is-open');
        mega.setAttribute('aria-hidden', 'false');
        toggle.setAttribute('aria-expanded', 'true');
        toggle.setAttribute('aria-label', 'Chiudi il menu'); // NKCS111126
        document.body.classList.add('nkcs-no-scroll');
    };

    const close = () => {
        mega.classList.remove('is-open');
        mega.setAttribute('aria-hidden', 'true');
        toggle.setAttribute('aria-expanded', 'false');
        toggle.setAttribute('aria-label', 'Apri il menu'); // NKCS111126
        document.body.classList.remove('nkcs-no-scroll');
    };

    toggle.addEventListener('click', () => {
        mega.classList.contains('is-open') ? close() : open();
    });

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && mega.classList.contains('is-open')) close();
    });

    // NKCS131126 — variante 'orizzontale' (body.nkcs-menu--orizzontale): sopra
    // i 1024px il pannello è nascosto dal CSS. Se era aperto e la finestra si
    // allarga oltre i 1024px lo chiudo, così non resta il blocco dello scroll.
    window.matchMedia('(min-width: 1025px)').addEventListener('change', (e) => {
        if (e.matches && document.body.classList.contains('nkcs-menu--orizzontale') && mega.classList.contains('is-open')) {
            close();
        }
    });

    mega.querySelectorAll('.nkcs-menu-mobile__item.has-sub > .nkcs-menu-mobile__link')
        .forEach((link) => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                link.closest('.nkcs-menu-mobile__item').classList.toggle('is-open');
            });
        });
}
