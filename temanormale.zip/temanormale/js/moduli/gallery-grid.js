// Gallery Grid — lightbox PhotoSwipe sul blocco acf/gallery-grid — NKCS_PHOTOSWIPE

export function initGalleryGrid() {
    const grids = document.querySelectorAll('.nkcs-gallery-grid');
    if (!grids.length) return;

    function initLightbox() {
        if (!window.PhotoSwipeLightbox || !window.PhotoSwipe) {
            console.warn('[NKCS] PhotoSwipe non disponibile');
            return;
        }

        grids.forEach(grid => {
            if (grid.dataset.pswpReady === '1') return; // niente doppia init
            grid.dataset.pswpReady = '1';

            const lightbox = new window.PhotoSwipeLightbox({
                gallery: grid,
                children: '.nkcs-gallery-grid__item',
                pswpModule: window.PhotoSwipe,

                zoom: true,
                initialZoomLevel: 'fit',
                secondaryZoomLevel: 2,
                maxZoomLevel: 4,
                wheelToZoom: true,
                pinchToClose: true,

                bgOpacity: 0.92,
                showHideAnimationType: 'fade',
                counter: true,
                close: true,
                arrowKeys: true,
                loop: true,
                preload: [1, 2],

                paddingFn: (viewportSize) => ({
                    top: 30,
                    bottom: viewportSize.x < 768 ? 60 : 30,
                    left: 20,
                    right: 20,
                }),
            });

            lightbox.init();
        });
    }

    if (window.nkcsPhotoSwipeReady) {
        initLightbox();
    } else {
        window.addEventListener('nkcs:photoswipe-ready', initLightbox, { once: true });
    }
}
