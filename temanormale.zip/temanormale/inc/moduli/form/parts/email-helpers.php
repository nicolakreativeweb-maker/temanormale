<?php
/**
 * Helper email condivisi — usati da qualsiasi form CF7
 * Onoranze Funebri Aguiari — NKCS080726
 * NKCS080726 — firma: Tel/Numero Verde in bold e su righe separate + font Georgia
 * NKCS080726 — tutti i link firma: color #222, nessuna sottolineatura
 * NKCS080726 — wrap: logo in alto a sx, formattazione e colori aggiornati
 * NKCS100926 — spostato da inc/moduli/form/modulo.php.
 * NKCS100926 — nkcs_azienda() legge i dati firma dal gruppo ACF
 * nkcs_contatti_firma e From/Reply-To dal gruppo nkcs_email_invio.
 * Nessun valore hardcoded: se un campo è vuoto, resta vuoto (il Reply-To
 * vuoto ripiega sul From).
 * NKCS170926 — logo firma leggermente più alto (max-width 70px → 90px).
 * NKCS170926 — ogni riga della firma (email, tel, numero verde, Facebook)
 * compare solo se il relativo campo ACF è valorizzato, come già l'indirizzo.
 * NKCS170926 — logo firma +5px di altezza: ora vincolato in altezza (non più
 * in larghezza), calcolata sulle dimensioni naturali del file quando note.
 * NKCS170926 — rimosso il riferimento all'hook email dei necrologi (eliminato).
 * NKCS220926 — font email: da Georgia (serif) a Poppins con fallback
 * sans-serif simili (Helvetica Neue / Helvetica / Arial), vedi nkcs_email_font().
 * NKCS220926 — firma: nome azienda e indirizzo passano da nkcs_esc_br() invece
 * di esc_html(): un <br> scritto nel campo ACF diventa un vero a capo (prima
 * compariva il testo "<br>"). Ogni altro tag resta escluso.
 * NKCS220926 — logo spostato dall'alto dell'email alla firma: sotto la
 * lineetta, prima del nome azienda (nkcs_email_firma()).
 * NKCS220926 — logo in firma più grande: max-width 160px (era 120px).
 * NKCS131126 — tolta la riga Facebook dalla firma (e i campi ACF
 * nkcs_firma_facebook_label / nkcs_firma_facebook_url dal gruppo Contatti Firma).
 * NKCS131126 — tolti i campi Indirizzo, Link Google Maps, Telefono e Numero
 * Verde della firma. Al loro posto nkcs_firma_sedi_slug: slug di Contatti
 * Globali → Sedi separati da virgola (es. "sede-principale, sede-secondaria").
 * Per ogni sede che esiste la firma mostra indirizzo (+ link Maps) e i
 * telefoni con lo stesso slug (nkcs_contatti_per_slug); con più sedi compare
 * anche il nome della sede. Campo vuoto = sede principale.
 * Rimossa nkcs_tel_href(), non più usata (il tel: lo genera nkcs_href_tel()
 * in inc/contatti/contatti.php).
 * NKCS131126 — contenitore della firma da <p> a <div>: dentro ci sono i
 * blocchi sede (div), che in un <p> non sarebbero HTML valido.
 * NKCS131126 — tolto anche il campo "Email in firma" (nkcs_firma_email): le
 * email sono le righe di Contatti Globali → Email con lo slug della sede,
 * mostrate nel blocco sede dopo i telefoni.
 */

if (!defined('ABSPATH')) exit;

/* ==========================================================================
   1. CONFIG AZIENDA (unica fonte dei dati)
   Firma → gruppo ACF nkcs_contatti_firma. Invio (From/Reply-To) → gruppo ACF
   nkcs_email_invio. Se un campo è vuoto resta vuoto; Reply-To vuoto usa il From.
   ========================================================================== */
function nkcs_azienda()
{
    static $cfg = null;
    if ($cfg !== null) return $cfg;

    $has_acf = function_exists('get_field');

    // Gruppo firma
    $f = $has_acf ? get_field('nkcs_contatti_firma', 'option') : array();
    if (!is_array($f)) $f = array();

    // Gruppo invio
    $e = $has_acf ? get_field('nkcs_email_invio', 'option') : array();
    if (!is_array($e)) $e = array();

    // Ritorna il valore ACF se valorizzato, altrimenti stringa vuota
    $val = function ($src, $key) {
        return (isset($src[$key]) && $src[$key] !== '' && $src[$key] !== null) ? $src[$key] : '';
    };

    // Logo: gestisco return URL (string), Array o ID
    $logo = $f['nkcs_firma_logo'] ?? '';
    if (is_array($logo))       $logo = $logo['url'] ?? '';
    elseif (is_numeric($logo)) $logo = wp_get_attachment_image_url((int) $logo, 'full');

    // NKCS131126 — sedi della firma: slug separati da virgola. Per ogni slug
    // che esiste in Contatti Globali → Sedi: indirizzo, Maps e telefoni con lo
    // stesso slug (helper in inc/contatti/contatti.php). Slug inesistenti
    // saltati; campo vuoto = sede principale (prima riga di Sedi).
    $slugs = array_values(array_unique(array_filter(
        array_map('trim', explode(',', (string) $val($f, 'nkcs_firma_sedi_slug'))),
        'strlen'
    )));
    $righe_sedi = $slugs
        ? array_map(fn($s) => nkcs_contatto('sedi', $s), $slugs)
        : [nkcs_contatto('sedi')];

    $sedi = [];
    foreach (array_filter($righe_sedi) as $s) {
        $sedi[] = [
            'nome'      => $s['nome'],
            'indirizzo' => $s['indirizzo'],
            'maps'      => $s['link']['url'] ?? '',
            'telefoni'  => nkcs_contatti_per_slug('telefoni', $s['slug']), // righe: slug, etichetta, numero, href
            'email'     => nkcs_contatti_per_slug('email', $s['slug']),    // righe: slug, etichetta, indirizzo, href
        ];
    }

    // Invio: From e Reply-To; se il no-reply è vuoto uso il From
    $from    = $val($e, 'nkcs_email_from');
    $noreply = $val($e, 'nkcs_email_noreply');
    if ($noreply === '') $noreply = $from;

    $cfg = array(
        'nome'           => $val($f, 'nkcs_firma_nome'),
        'email'          => $from,       // From header
        'noreply'        => $noreply,    // Reply-To di default
        'sedi'           => $sedi,        // NKCS131126 — righe: nome, indirizzo, maps, telefoni
        'logo'           => $logo,
        'accent'         => $val($f, 'nkcs_firma_accent'),
    );

    return $cfg;
}

/* ==========================================================================
   1b. FONT EMAIL (unico punto da modificare)
   NKCS220926 — era Georgia (serif). Ora Poppins, il font del sito, con
   fallback sans-serif dalla forma simile: la maggior parte dei client email
   (Gmail, Outlook) non carica font esterni, quindi in pratica il testo esce
   in Helvetica Neue / Helvetica / Arial; Poppins compare solo dove è
   installato sul dispositivo.
   Stack senza apici doppi: finisce dentro style="..." inline.
   ========================================================================== */
function nkcs_email_font()
{
    return "Poppins, 'Helvetica Neue', Helvetica, Arial, sans-serif";
}

/* ==========================================================================
   2. FIRMA EMAIL (HTML)
   ========================================================================== */
function nkcs_email_firma()
{
    $a    = nkcs_azienda();
    $font = nkcs_email_font();

    $link_style = 'color:#222; text-decoration:none;';

    // Ogni riga compare solo se il dato è valorizzato — niente etichette o link vuoti.
    // Le righe si uniscono con <br> (niente <br> finale).

    // NKCS131126 — un blocco per sede: [nome sede se più di una], indirizzo
    // (cliccabile se c'è il link Maps), una riga "Tel. numero (etichetta)"
    // per ogni telefono e una "Email indirizzo (etichetta)" per ogni email
    // con lo slug della sede.
    $multi     = count($a['sedi']) > 1;
    $sedi_html = '';
    foreach ($a['sedi'] as $s) {
        $righe = [];
        if ($multi) {
            $righe[] = '<strong>' . nkcs_esc_br($s['nome']) . '</strong>';
        }
        if ($s['indirizzo'] !== '') {
            // NKCS220926 — <br> del campo ACF convertiti in a capo veri (nkcs_esc_br)
            $indirizzo = nkcs_esc_br($s['indirizzo']);
            $righe[]   = $s['maps'] !== ''
                ? '<em><a href="' . esc_url($s['maps']) . '" style="' . $link_style . '">' . $indirizzo . '</a></em>'
                : '<em>' . $indirizzo . '</em>';
        }
        foreach ($s['telefoni'] as $t) {
            $etichetta = $t['etichetta'] !== '' ? ' (' . esc_html($t['etichetta']) . ')' : '';
            $righe[]   = '<strong>Tel.</strong> <a href="' . esc_url($t['href'], ['tel']) . '" style="' . $link_style . '">' . esc_html($t['numero']) . '</a>' . $etichetta;
        }
        foreach ($s['email'] as $m) {
            $etichetta = $m['etichetta'] !== '' ? ' (' . esc_html($m['etichetta']) . ')' : '';
            $righe[]   = '<strong>Email</strong> <a href="' . esc_url($m['href'], ['mailto']) . '" style="' . $link_style . '">' . esc_html($m['indirizzo']) . '</a>' . $etichetta;
        }
        if ($righe) {
            $sedi_html .= '<div style="margin:8px 0 0 0;">' . implode('<br>', $righe) . '</div>';
        }
    }

    // NKCS220926 — logo in firma: sotto la lineetta, sopra il nome azienda
    $logo_html = '';
    if (!empty($a['logo'])) {
        $logo_html = '<img src="' . esc_url($a['logo']) . '" alt="' . esc_attr(wp_strip_all_tags($a['nome'])) . '" style="max-width:160px; height:auto; display:block; margin:0 0 12px 0; border:0;">'; // NKCS220926 — era 120px
    }

    // NKCS131126 — contenitore <div> (era <p>): dentro ci sono i blocchi sede
    // NKCS220926 — anche il nome in firma converte gli eventuali <br>
    return '
        <div style="margin:22px 0 0 0; padding-top:16px; border-top:1px solid #e6e0d8; line-height:1.6; font-family:' . $font . '; font-size:14px; color:#222222;">
          ' . $logo_html . '
          <strong>' . nkcs_esc_br($a['nome']) . '</strong>
          ' . $sedi_html . '
        </div>
    ';
}

/* ==========================================================================
   3. WRAPPER HTML (corpo + firma)
   NKCS220926 — il logo non sta più in alto: è nella firma (vedi sopra).
   ========================================================================== */
function nkcs_email_wrap($inner_html)
{
    $font = nkcs_email_font();

    return '<div style="font-family:' . $font . '; font-size:15px; line-height:1.7; color:#333333; max-width:600px; padding:24px; background-color:#ffffff;">'
        . $inner_html
        . nkcs_email_firma()
        . '</div>';
}

/* ==========================================================================
   4. HEADERS
   ========================================================================== */
function nkcs_email_headers($reply_to = '')
{
    $a = nkcs_azienda();
    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . $a['nome'] . ' <' . $a['email'] . '>',
        'Reply-To: ' . ($reply_to !== '' ? $reply_to : $a['noreply']),
    );
    return $headers;
}
