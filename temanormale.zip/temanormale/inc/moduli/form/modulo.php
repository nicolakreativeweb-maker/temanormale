<?php
/**
 * Modulo Form — entry point del modulo
 * NKCS100926 — creato come modulo, spostato da inc/cf7.php
 * NKCS100926 — logica divisa in file dentro parts/ (vedi ciascun file per
 * la provenienza storica): syntax highlight admin, helper email condivisi,
 * hook email caso base.
 * NKCS170926 — rimosso il redirect post-submit del vecchio form necrologio
 * ($_POST['submit_necrologio']): i necrologi non esistono più nel tema.
 */

if (!defined('ABSPATH')) exit;

require_once __DIR__ . '/parts/admin-syntax-highlight.php';
require_once __DIR__ . '/parts/email-helpers.php';
require_once __DIR__ . '/parts/hook-email-base.php';
