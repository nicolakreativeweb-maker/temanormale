<?php
// Prendi il valore del campo spacer_size
$size = get_field('spacer_size');
?>

<div class="spacer-<?php echo esc_attr($size); ?>"></div>
