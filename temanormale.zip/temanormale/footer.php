</main>

<?php
/*
 * Footer — NKCS210926
 * Tutti i dati arrivano da nkcs_contatti() (inc/contatti/contatti.php),
 * che legge la options page "Contatti Globali" (nkcs_contatti_globali + nkcs_footer).
 *
 * Struttura a 4 colonne (max-width 1000px) — NKCS041126:
 *   1. Logo grande + indirizzo + logo Facebook (30px)
 *   2. Sede e recapiti — telefono + email + orari (repeater 'nkcs_sede_orari' della sede, NKCS131126)
 *   3. Sitemap         — wp_nav_menu location "footer"
 *   4. Operiamo a      — wp_nav_menu location "paesi", voci su 2 colonne uguali
 * Sfondo footer $black, barra finale $black-1.
 *
 * NKCS220926 — mobile bar disattivata (commentata sotto, file lasciato in
 * template-parts/menu/mobile/mobile-bar.php): al suo posto il pulsante
 * "Chiama" fisso in basso a destra (template-parts/chiama-fisso.php).
 * NKCS220926 — link policy della barra finale come elementi separati
 * (nav.footer__policy > a.footer__policy-link), non più uniti da " | " in
 * un unico span: sopra i 600px restano in riga (separatore via CSS), sotto
 * i 600px diventano pulsanti glass uno sotto l'altro (layout/_footer.scss).
 *
 * NKCS131126 — titoli h4 delle colonne sostituiti con segnaposto generici
 * ("Colonna 1" / "Colonna 2" / "Colonna 3", al posto di "Sede e recapiti" /
 * "Sitemap" / "Operiamo a"). Contenuti delle colonne invariati.
 */
$nkcs_contatti = nkcs_contatti();
$nkcs_privacy  = $nkcs_contatti['privacy_policy'];
$nkcs_cookie   = $nkcs_contatti['cookie_policy'];

$nkcs_footer           = $nkcs_contatti['footer'];
$nkcs_nome_azienda     = $nkcs_footer['nome_azienda'] ?: get_bloginfo('name'); // alt del logo
$nkcs_nome_azienda_end = $nkcs_footer['nome_azienda_end'];                     // barra finale
$nkcs_piva             = $nkcs_footer['piva'];

// Logo primario da ACF (gruppo nkcs_loghi, options page "Contatti Globali").
// Fallback sul logo statico del tema se il campo non è ancora compilato.
$nkcs_loghi    = get_field('nkcs_loghi', 'option');
$nkcs_logo     = $nkcs_loghi['nkcs_logo_default'] ?? null;
$nkcs_logo_src = $nkcs_logo['url'] ?? (TEMPLATE_URI . 'img/logo-white.png');
$nkcs_logo_alt = ($nkcs_logo['alt'] ?? '') ?: $nkcs_nome_azienda;

// Colonna 1: sede principale (prima riga di Sedi). Colonna 2: telefono + email.
// NKCS131126 — telefono, email e Facebook: riga con lo stesso slug della sede
// (prima: slug fisso 'principale'), altrimenti la prima riga del repeater.
$nkcs_col_sede  = nkcs_contatto('sedi');
$nkcs_col_tel   = nkcs_contatto_sede('telefoni', $nkcs_col_sede);
$nkcs_col_email = nkcs_contatto_sede('email', $nkcs_col_sede);
$nkcs_facebook  = nkcs_contatto_sede('facebook', $nkcs_col_sede); // NKCS041126 — logo Facebook sotto l'indirizzo

// Barra finale — NKCS230926: due gruppi separati (non più un'unica stringa)
// perché sotto i 600px vanno su due righe: 1) nome – Copyright anno,
// 2) All rights reserved – P.IVA. Sopra i 600px restano in riga con "–".
$nkcs_copyright_riga1 = [];
if ($nkcs_nome_azienda_end) $nkcs_copyright_riga1[] = esc_html($nkcs_nome_azienda_end);
$nkcs_copyright_riga1[] = 'Copyright ' . esc_html(date('Y'));

$nkcs_copyright_riga2 = ['All rights reserved'];
if ($nkcs_piva) $nkcs_copyright_riga2[] = 'P.IVA ' . esc_html($nkcs_piva);

// Barra finale: link policy (solo quelli valorizzati) + preferenze iubenda
// NKCS230926 — label brevi fisse ("Privacy" / "Cookie"), non più il titolo
// del link ACF (che restava troppo lungo, es. "Privacy Policy").
$nkcs_policy = [];
foreach ([[$nkcs_privacy, 'Privacy'], [$nkcs_cookie, 'Cookie']] as [$l, $label]) {
    if (!$l) continue;
    $nkcs_policy[] = '<a href="' . esc_url($l['url']) . '" target="' . esc_attr($l['target'] ?: '_self') . '" class="footer__policy-link has-white-color">'
        . esc_html($label) . '</a>';
}
$nkcs_policy[] = '<a href="#" class="footer__policy-link iubenda-cs-preferences-link has-white-color">Gestisci preferenze cookie</a>';
?>

<?php // get_template_part('template-parts/menu/mobile/mobile-bar'); // NKCS220926 — disattivata ?>
<?php // get_template_part('template-parts/chiama-fisso'); // NKCS031126 — disattivato (pulsante "Chiama" fisso in basso a destra) ?>

<footer>

    <div class="footer nkcs-gsap-reveal nkcs-gsap-fade-up--scrolled">

        <!-- Col 1: logo grande + indirizzo + logo Facebook — NKCS041126 -->
        <div class="footer__col footer__col--brand">
            <img class="footer-logo" src="<?= esc_url($nkcs_logo_src) ?>" alt="<?= esc_attr($nkcs_logo_alt) ?>">

            <?php if ($nkcs_col_sede && $nkcs_col_sede['indirizzo']) : ?>
                <?php
                // Indirizzo cliccabile: link della sede (ACF), altrimenti ricerca su Google Maps
                $nkcs_sede_link = $nkcs_col_sede['link'] ?? null;
                $nkcs_maps_url  = $nkcs_sede_link['url']
                    ?? 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode(wp_strip_all_tags(preg_replace('#<br\s*/?>#i', ', ', $nkcs_col_sede['indirizzo'])));
                ?>
                <p class="ft-paragraph">
                    <a class="footer__indirizzo has-white-color" href="<?= esc_url($nkcs_maps_url) ?>" target="_blank" rel="noopener">
                        <strong><?= nkcs_esc_br($nkcs_col_sede['indirizzo']) ?></strong>
                    </a>
                </p>
            <?php endif; ?>

            <?php if ($nkcs_facebook) : ?>
                <?php // Solo il logo di Facebook (icona), sotto l'indirizzo ?>
                <a class="footer__facebook has-white-color" href="<?= esc_url($nkcs_facebook['link']['url']) ?>" target="<?= esc_attr($nkcs_facebook['link']['target'] ?: '_blank') ?>" rel="noopener" aria-label="<?= esc_attr($nkcs_facebook['etichetta'] ?: ($nkcs_facebook['link']['title'] ?: 'Facebook')) ?>">
                    <i class="fa-brands fa-facebook" aria-hidden="true"></i>
                </a>
            <?php endif; ?>
        </div><!-- end footer__col -->

        <!-- Col 2: Sede e recapiti (telefono, email, orari della sede) -->
        <div class="footer__col footer__col--recapiti">
            <h4 class="ft-h4">Colonna 1</h4>

            <div class="footer__content">
                <p class="ft-paragraph">
                    <?php if ($nkcs_col_tel) : ?>
                        <span class="has-white-color">
                            <strong>Telefono:</strong>
                            <a href="<?= esc_attr($nkcs_col_tel['href']) ?>" class="has-white-color"><?= esc_html($nkcs_col_tel['numero']) ?></a>
                        </span>
                    <?php endif; ?>

                    <?php if ($nkcs_col_email) : ?>
                        <span class="has-white-color footer__email">
                            <strong>Email:</strong>
                            <a href="<?= esc_attr($nkcs_col_email['href']) ?>" class="has-white-color"><?= esc_html($nkcs_col_email['indirizzo']) ?></a>
                        </span>
                    <?php endif; ?>
                </p>

                <?php if (!empty($nkcs_col_sede['orari'])) : ?>
                    <?php // NKCS131126 — una riga per fascia oraria: "Label: orario" ?>
                    <div class="nkcs-orari has-white-color">
                        <strong>Orari:</strong>
                        <?php foreach ($nkcs_col_sede['orari'] as $nkcs_orario) : ?>
                            <p><?= esc_html(implode(': ', array_filter([$nkcs_orario['label'], $nkcs_orario['orario']], 'strlen'))) ?></p>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div><!-- end footer__col -->

        <!-- Col 3: Sitemap -->
        <div class="footer__col footer__col--sitemap">
            <h4 class="ft-h4">Colonna 2</h4>
            <div class="footer__content">
                <?php wp_nav_menu([
                    'theme_location' => 'footer',
                    'container'      => false,
                    'menu_id'        => 'nkcs-footer-sitemap-menu',
                    'menu_class'     => 'footer__menu',
                    'fallback_cb'    => false,
                    'link_before'    => '<span class="has-white-color">',
                    'link_after'     => '</span>',
                ]); ?>
            </div>
        </div><!-- end footer__col -->

        <!-- Col 4: Operiamo a (menu "paesi"), voci divise in due colonne uguali -->
        <?php if (has_nav_menu('paesi')) : ?>
            <div class="footer__col footer__col--paesi">
                <h4 class="ft-h4">Colonna 3</h4>
                <div class="footer__content">
                    <?php wp_nav_menu([
                        'theme_location' => 'paesi',
                        'container'      => false,
                        'menu_id'        => 'nkcs-footer-paesi-menu',
                        'menu_class'     => 'footer__menu footer__menu--2col',
                        'fallback_cb'    => false,
                        'link_before'    => '<span class="has-white-color">',
                        'link_after'     => '</span>',
                    ]); ?>
                </div>
            </div><!-- end footer__col -->
        <?php endif; ?>

    </div><!-- end .footer -->

    <div class="footer__end__wrapper">
        <div class="footer__end">
            <div class="footer__end__col">
                <div class="footer__content">
                    <p class="ft-paragraph ft-paragraph--row flex__center footer__copyright">
                        <span class="has-white-color footer__copyright-line">
                            <?= implode(' &ndash; ', $nkcs_copyright_riga1) ?>
                        </span>
                        <span class="has-white-color footer__copyright-line">
                            <?= implode(' &ndash; ', $nkcs_copyright_riga2) ?>
                        </span>
                    </p>
                </div>

                <div class="footer__content footer__content--policy">
                    <nav class="footer__policy" aria-label="Informative legali">
                        <?= implode('', $nkcs_policy) ?>
                    </nav>
                </div>

            </div><!-- end footer__end__col -->

            <div class="footer__end__col">
                <a href="https://agenziakreativeweb.it/">
                    <img class="powerby" src="<?= TEMPLATE_URI ?>img/poweredby.png" alt="Poweredby kreativeweb">
                </a>
            </div><!-- end footer__end__col -->
        </div><!-- end footer__end -->
    </div><!-- end footer__end__wrapper -->

</footer><!-- end footer -->
<?php wp_footer(); ?>
</body>

</html>
