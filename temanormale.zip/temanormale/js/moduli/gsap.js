// Animazioni GSAP — NKCS100926 — estratto da main.js (era initGsapAnimation() dentro l'IIFE NKCS)
// gsap e ScrollTrigger sono globali, caricati a parte (js/gsap/*.min.js): non importati qui.
//
// NKCS051126 — aggiunta la variante .nkcs-gsap-fade-up--scrolled (ScrollTrigger).
//
// .nkcs-gsap-fade-up            → al caricamento, solo opacità, in sequenza (invariata)
// .nkcs-gsap-fade-up--scrolled  → stesso fade-up della hero (@keyframes nkcs-hero-fade-up,
//                                 0.8s cubic-bezier(0.25, 0, 0.15, 1)), ma parte quando la
//                                 cima dell'elemento tocca il fondo del viewport, una volta sola.
//
// ScrollTrigger decide SOLO quando partire: aggiunge la classe .is-in e l'animazione è
// CSS (stesso keyframe e stessa curva della hero, gira sul compositor del browser → fluida
// uguale). Lo scatto precedente veniva da un tween GSAP con easing diverso.
//
// Come regge refresh e layout che cambiano:
// - stato iniziale nascosto via CSS (scss/base/_animations.scss), così non c'è flash
//   prima che il JS giri; solo se gli script sono attivi e senza "riduci movimento";
// - ScrollTrigger.batch: un solo osservatore, e gli elementi che entrano insieme
//   (colonne, card) escono a cascata con un ritardo crescente (--nkcs-fade-delay);
// - elementi già superati dallo scroll (refresh con scroll ripristinato dal browser):
//   mostrati subito, senza animare cose che l'utente non vede;
// - fine animazione: classe .is-revealed, il CSS non li nasconde più e non resta
//   nessun transform addosso;
// - ScrollTrigger.refresh() (debounce) dopo caricamento font, immagini (load) e
//   ripristino da bfcache (pageshow), perché cambiano l'altezza della pagina;
// - se gsap/ScrollTrigger mancano: tutto visibile, niente contenuto nascosto per sempre.

const SCROLLED_SELECTOR = '.nkcs-gsap-fade-up--scrolled';
const REVEALED_CLASS = 'is-revealed';
const IN_CLASS = 'is-in';
const START = 'top bottom'; // cima dell'elemento = fondo del viewport
const BASE_DELAY = 0.15;    // piccolo ritardo prima che parta, così non scatta appena tocca il fondo
const STAGGER = 0.1;        // secondi tra un elemento e l'altro di uno stesso gruppo

let scrolledReady = false;

function revealNow(el) {
    el.classList.add(REVEALED_CLASS);
}

function playIn(el, delay) {
    el.style.setProperty('--nkcs-fade-delay', `${delay}s`);
    el.classList.add(IN_CLASS);
    el.addEventListener('animationend', () => {
        el.classList.add(REVEALED_CLASS);
        el.classList.remove(IN_CLASS);
        el.style.removeProperty('--nkcs-fade-delay');
    }, { once: true });
}

function debounce(fn, wait) {
    let t;
    return (...args) => {
        clearTimeout(t);
        t = setTimeout(() => fn(...args), wait);
    };
}

function initFadeUpScrolled() {
    if (scrolledReady) return;

    const items = gsap.utils.toArray(SCROLLED_SELECTOR);
    if (!items.length) return;
    scrolledReady = true;

    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Senza ScrollTrigger o con "riduci movimento": tutto visibile subito
    if (reduceMotion || typeof ScrollTrigger === 'undefined') {
        items.forEach(revealNow);
        return;
    }

    gsap.registerPlugin(ScrollTrigger);
    // Barra indirizzi mobile che si nasconde: non deve far ricalcolare tutto
    ScrollTrigger.config({ ignoreMobileResize: true });

    // Già fuori schermo in alto (refresh con scroll ripristinato): mostrati senza animare
    const pending = items.filter((el) => {
        if (el.getBoundingClientRect().bottom < 0) {
            revealNow(el);
            return false;
        }
        return true;
    });

    ScrollTrigger.batch(pending, {
        start: START,
        once: true,
        interval: 0.1,   // raggruppa gli elementi che entrano entro 0,1s
        batchMax: 6,
        onEnter: (batch) => batch.forEach((el, i) => playIn(el, BASE_DELAY + i * STAGGER)),
    });

    // La pagina cambia altezza dopo font, immagini e ripristino bfcache:
    // ricalcola le posizioni (una volta sola ogni raffica di eventi)
    const refresh = debounce(() => ScrollTrigger.refresh(), 150);
    window.addEventListener('load', refresh, { once: true });
    window.addEventListener('pageshow', (e) => { if (e.persisted) refresh(); });
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(refresh);
}

export function initGsapAnimation() {
    // Senza gsap non c'è niente da animare: nessun elemento deve restare nascosto
    if (typeof gsap === 'undefined') {
        document.querySelectorAll(SCROLLED_SELECTOR).forEach(revealNow);
        return;
    }

    gsap.utils.toArray('.nkcs-gsap-fade-up').forEach((el, i) => {
        gsap.fromTo(el, { opacity: 0 }, { opacity: 1, duration: 1, ease: 'sine.out', delay: i * 0.15 });
    });

    initFadeUpScrolled();
}
