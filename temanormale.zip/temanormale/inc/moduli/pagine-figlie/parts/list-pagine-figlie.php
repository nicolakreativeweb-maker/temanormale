<?php
/**
 * Part — Griglia pagine figlie (shortcode shortcode_list_pagine_figlie)
 * NKCS220926 — ex inc/moduli/lavorazioni/parts/list-lavorazioni.php, reso
 * generico: la query arriva da nkcs_pagine_figlie_query() ($nkcs_query,
 * impostata in modulo.php), classi nkcs-grid-lavorazioni* → nkcs-grid-pagine-figlie*.
 * Card dai campi del gruppo group_nkcs_seo (nkcs_seo_is_card,
 * nkcs_seo_card_titolo, nkcs_seo_card_desc); icona fissa da img/lavorazioni/;
 * card per riga da $nkcs_colonne (attributo "colonne").
 */

if (!defined('ABSPATH')) exit;

$colonne   = $nkcs_colonne ?? 3;
$icona_src = TEMPLATE_URI . 'img/lavorazioni/icon-lavorazione.svg';
?>

<?php if ($nkcs_query->have_posts()) : ?>
    <div class="nkcs-grid-pagine-figlie" style="--nkcs-pagine-figlie-cols: <?php echo esc_attr($colonne); ?>;">
        <?php while ($nkcs_query->have_posts()) : $nkcs_query->the_post();

            // Campi card attivi solo con "Mostra come card"
            $is_card     = (bool) get_field('nkcs_seo_is_card');
            $card_titolo = ($is_card ? get_field('nkcs_seo_card_titolo') : '') ?: get_the_title();

            // Descrizione card: excerpt manuale se presente, altrimenti descrizione card ACF
            global $post;
            $card_desc = !empty($post->post_excerpt)
                ? $post->post_excerpt
                : ($is_card ? get_field('nkcs_seo_card_desc') : '');
        ?>
            <a href="<?php the_permalink(); ?>" class="nkcs-grid-pagine-figlie__item">
                <span class="nkcs-grid-pagine-figlie__item-icona">
                    <img src="<?php echo esc_url($icona_src); ?>" alt="" width="36" height="36">
                </span>
                <div class="nkcs-grid-pagine-figlie__item-body">
                    <h3 class="nkcs-grid-pagine-figlie__item-title">
                        <?php echo esc_html($card_titolo); ?>
                    </h3>
                    <?php if ($card_desc) : ?>
                        <p class="nkcs-grid-pagine-figlie__item-excerpt">
                            <?php echo esc_html(wp_trim_words($card_desc, 20, '…')); ?>
                        </p>
                    <?php endif; ?>
                    <span class="nkcs-grid-pagine-figlie__item-link">
                        <i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
                        Scopri di più
                    </span>
                </div>
            </a>
        <?php endwhile; ?>
    </div>
<?php endif; ?>
<?php wp_reset_postdata(); ?>
