// FAQ Yoast SEO — accordion — NKCS180926
// Blocco "FAQ" di Yoast: .schema-faq > .schema-faq-section > .schema-faq-question + .schema-faq-answer
// Una domanda aperta per blocco; ogni risposta viene avvolta in .nkcs-faq-panel
// (animazione a griglia). Stili in scss/vendor/_yoast-faq.scss.

export function initFaqYoast() {
    document.querySelectorAll('.schema-faq').forEach((faq, faqIndex) => {
        const sections = [...faq.querySelectorAll('.schema-faq-section')];
        if (!sections.length) return;

        const setOpen = (section, open) => {
            section.classList.toggle('is-open', open);
            const question = section.querySelector('.schema-faq-question');
            if (question) question.setAttribute('aria-expanded', open ? 'true' : 'false');
        };

        sections.forEach((section, i) => {
            const question = section.querySelector('.schema-faq-question');
            const answer = section.querySelector('.schema-faq-answer');
            if (!question || !answer) return;

            if (!answer.id) answer.id = `nkcs-faq-${faqIndex}-${i}`;

            // wrapper per l'animazione a griglia (lo schema JSON-LD di Yoast non dipende dal DOM)
            const panel = document.createElement('div');
            panel.className = 'nkcs-faq-panel';
            answer.before(panel);
            panel.appendChild(answer);

            question.setAttribute('role', 'button');
            question.setAttribute('tabindex', '0');
            question.setAttribute('aria-controls', answer.id);
            question.setAttribute('aria-expanded', 'false');

            const toggle = () => {
                const willOpen = !section.classList.contains('is-open');
                sections.forEach((s) => setOpen(s, false));
                setOpen(section, willOpen);
            };

            question.addEventListener('click', toggle);
            question.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    toggle();
                }
            });
        });

        faq.classList.add('nkcs-faq-ready');
    });
}
