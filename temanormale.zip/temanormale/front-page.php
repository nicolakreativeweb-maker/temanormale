<?php
/* NKCS110926 — hero dai campi del gruppo group_nkcs_seo (nkcs_seo_h1, nkcs_seo_desc, nkcs_seo_pulsanti);
   NKCS150926 — hero passata da slideshow (Ken Burns multi-immagine) a variante
   'pagina': una sola immagine fissa, come le altre hero del sito.
   NKCS160926 — immagine di copertina dall'immagine in evidenza della pagina
   (come page.php), non più dal campo ACF gallery homepage_images (rimosso).
   NKCS210926 — 'slides' da nkcs_hero_slides(): slideshow opzionale (flag ACF
   group_nkcs_hero_slides). Flag OFF o < 2 immagini → hero identica a prima. */
?>
<?php get_header(); ?>

<?php if (have_posts()) : the_post(); ?>

    <?php
    // ============================================================
    // CONFIG
    // ============================================================
    $seo_title       = get_field('nkcs_seo_h1');
    $seo_description = get_field('nkcs_seo_desc');
    $seo_pulsanti    = get_field('nkcs_seo_pulsanti');
    // NKCS131126 — occhiello tolto dalla hero (il campo nkcs_seo_occhiello resta nel backend, non più letto)

    // ============================================================
    // IMMAGINE HERO — immagine in evidenza della pagina, fallback statico
    // ============================================================
    $hero_id  = get_post_thumbnail_id();
    $hero_alt = '';
    $hero_src = get_template_directory_uri() . '/img/hero.jpg';

    // NKCS041126 — senza immagine in evidenza: immagine del gruppo ACF "Pagina 404"
    // (Contatti Globali); se manca anche quella resta il fallback statico.
    if (!$hero_id) {
        $hero_id = nkcs_pagina_404()['immagine_id'];
    }

    if ($hero_id) {
        $hero_src = esc_url(wp_get_attachment_image_url($hero_id, 'full'));
        $hero_alt = esc_attr(get_post_meta($hero_id, '_wp_attachment_image_alt', true));
    }

    if (empty($hero_alt)) {
        $hero_alt = esc_attr(get_the_title());
    }
    ?>

    <?php
    nkcs_layout_part('hero_home', [
        'src'         => $hero_src,
        'alt'         => $hero_alt,
        'width'       => 1920,
        'height'      => 1080,
        'title'       => $seo_title ?: get_the_title(),
        'description' => $seo_description,
        'breadcrumbs' => [],
        'buttons'     => $seo_pulsanti,
        'class'       => 'nkcs-hero-page--home',
        'slides'      => nkcs_hero_slides(get_the_ID()), // NKCS210926
    ]);
    ?>

    <div class="gutenberg-content" id="content-intro">
        <?php the_content(); ?>
    </div>

<?php endif; ?>


<?php wp_reset_postdata(); ?>
<?php get_footer(); ?>
