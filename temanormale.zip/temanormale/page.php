<?php
/* NKCS110926 — hero dai campi del gruppo group_nkcs_seo (nkcs_seo_h1, nkcs_seo_desc, nkcs_seo_pulsanti)
   NKCS210926 — 'slides' da nkcs_hero_slides(): slideshow opzionale (flag ACF
   group_nkcs_hero_slides). Flag OFF o < 2 immagini → hero identica a prima.
   NKCS220926 — banda contatti da template-parts/banda-contatti.php (pattern
   sincronizzato 278), sempre prima del footer. */
?>
<?php get_header(); ?>

<?php if (have_posts()) : the_post(); ?>

    <?php
    $hero_id  = get_post_thumbnail_id();
    $hero_alt = '';
    $hero_src = get_template_directory_uri() . '/img/hero.jpg';

    // NKCS041126 — senza immagine in evidenza: immagine del gruppo ACF "Pagina 404"
    // (Contatti Globali); se manca anche quella resta il fallback statico.
    if (!$hero_id) {
        $hero_id = nkcs_pagina_404()['immagine_id'];
    }

    if ($hero_id) {
        $hero_src = esc_url(wp_get_attachment_image_url($hero_id, 'full'));
        $hero_alt = esc_attr(get_post_meta($hero_id, '_wp_attachment_image_alt', true));
    }

    if (empty($hero_alt)) {
        $hero_alt = esc_attr(get_the_title());
    }

    $hero_srcset = $hero_id ? esc_attr(wp_get_attachment_image_srcset($hero_id, 'full')) : '';
    $hero_sizes  = '100vw';

    $seo_title       = get_field('nkcs_seo_h1');
    $seo_description = get_field('nkcs_seo_desc');
    $seo_pulsanti    = get_field('nkcs_seo_pulsanti');
    ?>


    <?php
    // Costruisce array breadcrumb con eventuali parent
    $breadcrumbs = [
        ['label' => 'Home', 'url' => home_url('/')]
    ];

    // Recupera la catena di parent pages
    $ancestors = array_reverse(get_post_ancestors(get_the_ID()));
    foreach ($ancestors as $ancestor_id) {
        $breadcrumbs[] = [
            'label' => get_the_title($ancestor_id),
            'url'   => get_permalink($ancestor_id),
        ];
    }

    // Pagina corrente — niente URL, è l'ultimo elemento
    $breadcrumbs[] = [
        'label' => get_the_title(),
        'url'   => null,
    ];
    ?>

    <?php
    nkcs_layout_part('hero_pagina', [
        'src'         => $hero_src,
        'alt'         => $hero_alt,
        'width'       => 1920,
        'height'      => 1080,
        // NKCS111126 — occhiello non più mostrato nelle pagine interne (resta solo nella
        // frontpage); il campo ACF nkcs_seo_occhiello resta nel backend.
        'title'       => $seo_title ?: get_the_title(),
        'description' => $seo_description,
        'breadcrumbs' => $breadcrumbs,
        'buttons'     => $seo_pulsanti,
        // NKCS131126 — niente 'slides': lo slideshow è solo in homepage (front-page.php)
    ]);
    ?>

    <div class="gutenberg-content" id="content-intro">
        <?php the_content(); ?>
    </div>

<?php endif; ?>

<?php wp_reset_postdata(); ?>

<?php get_template_part('template-parts/banda-contatti'); // NKCS220926 ?>

<?php get_footer(); ?>
