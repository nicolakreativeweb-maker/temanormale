<?php

/**
 * Hero — linguetta bianca "scorri giù" — NKCS210926
 * Semicerchio bianco centrato sul bordo inferiore della hero, con la freccia
 * img/arrows/arrow-down.svg. Porta a #content-intro (front-page.php, page.php,
 * 404.php). Stili in scss/layout/_hero.scss → .nkcs-hero-page__tab.
 * Incluso da template-parts/hero/pagina.php, slideshow.php e 404.php,
 * sempre come ultimo figlio della section .nkcs-hero-page.
 */

if (!defined('ABSPATH')) exit;
?>

<a class="nkcs-hero-page__tab" href="#content-intro" aria-label="Scorri al contenuto">
    <img
        src="<?= esc_url(get_template_directory_uri() . '/img/arrows/arrow-down.svg') ?>"
        alt=""
        width="40"
        height="54">
</a>
