<?php

/**
 * Menu desktop — variante orizzontale — NKCS100926
 * Spostato da header.php. Markup invariato.
 * NKCS100926 — rinominato il blocco BEM: nkcs-nav → nkcs-menu-desktop
 * (nkcs-nav__list → nkcs-menu-desktop__list). aria-label distinto da
 * quello del menu mobile: due <nav> nella stessa pagina devono avere
 * etichette diverse.
 * NKCS150926 — aggiunta iconcina Facebook dopo la voce "Contatti",
 * link dalla stessa fonte del footer (nkcs_contatti()['facebook']).
 * NKCS131126 — di nuovo in uso: si attiva con NKCS_LAYOUT['menu_desktop'] = 'orizzontale'
 * (inc/layout/layout.php). Visibile solo sopra i 1024px (layout/_menu.scss).
 */

if (!defined('ABSPATH')) exit;

$nkcs_facebook = nkcs_contatto('facebook');
?>

<nav class="nkcs-menu-desktop" aria-label="Menu principale desktop">
    <?php
    wp_nav_menu([
        'theme_location' => 'primary',
        'container'      => false,
        'menu_class'     => 'nkcs-menu-desktop__list',
        'menu_id'        => false,
        'depth'          => 2,
        'fallback_cb'    => false,
    ]);
    ?>

    <?php if ($nkcs_facebook) : ?>
        <a class="nkcs-menu-desktop__facebook"
            href="<?= esc_url($nkcs_facebook['link']['url']) ?>"
            target="<?= esc_attr($nkcs_facebook['link']['target'] ?: '_blank') ?>"
            rel="noopener"
            aria-label="Facebook">
            <i class="fa-brands fa-facebook-f"></i>
        </a>
    <?php endif; ?>
</nav>
