<?php

/**
 * Pulsante "Chiama" fisso in basso a destra — NKCS220926
 * Sostituisce la mobile bar (template-parts/menu/mobile/mobile-bar.php, ora
 * commentata in footer.php). Visibile a tutte le larghezze; tap = chiamata.
 * Numero: riga Telefoni con lo stesso slug della sede principale (NKCS131126,
 * prima "<slug>--cell"), altrimenti la prima riga di Telefoni.
 * Senza numero non stampa nulla.
 * Si nasconde vicino alla fine pagina: js/moduli/chiama-fisso.js.
 * Stili: scss/components/_chiama-fisso.scss
 */

if (!defined('ABSPATH')) exit;

$nkcs_cell = nkcs_contatto_sede('telefoni');

if (!$nkcs_cell) return;
?>

<a class="nkcs-chiama-fisso" href="<?= esc_url($nkcs_cell['href'], ['tel']) ?>" aria-label="Chiama <?= esc_attr($nkcs_cell['numero']) ?>">
    <span class="nkcs-chiama-fisso__icon"><i class="fa-solid fa-phone" aria-hidden="true"></i></span>
    <span class="nkcs-chiama-fisso__numero"><?= esc_html($nkcs_cell['numero']) ?></span>
</a>
