<?php

/**
 * ============================================================
 * ASSETS — CSS, JS e font del tema — NKCS040926
 * ------------------------------------------------------------
 * Estratto da functions.php per tenerlo pulito.
 * Qui dentro sta tutto ciò che viene accodato al frontend:
 *   - nb_carica_script()             → CSS e JS del tema
 *   - theme_force_greenshift_swiper() → dipendenze Swiper da Greenshift
 *   - tema_preload_fonts()            → preload dei woff2
 *   - nb_gutenberg_support()          → editor-styles Gutenberg
 *
 * Il JS resta centralizzato in js/main.js: i moduli in inc/moduli/ non
 * registrano script propri. NKCS100926 — main.js è ora un modulo ES
 * nativo (import/export): le sue funzioni initXxx vivono divise per
 * feature in js/moduli/, ma da WordPress si accoda SOLO js/main.js —
 * gli import li risolve il browser. Vedi nb_carica_script() più sotto.
 *
 * NKCS100926 — nb_gutenberg_support() spostata qui da inc/gutenberg.php,
 * ora eliminato.
 * ============================================================
 */

// Blocca l'accesso diretto al file
if (!defined('ABSPATH')) {
    exit;
}

// ============================================================
// CSS E JS DEL TEMA
// ============================================================
if (!function_exists('nb_carica_script')) {
    function nb_carica_script()
    {
        // INIT CSS
        wp_enqueue_style('fontawesome', TEMPLATE_URI . 'css/all.css', [], null);
        wp_enqueue_style('style', TEMPLATE_URI . 'css/style.css', [], '1.0.20'); // NKCS131126 — 1.0.6: varianti menu desktop; 1.0.7: orizzontale fluido sotto i 1500px; 1.0.8: voci più vicine; 1.0.9: header staccato; 1.0.10: header staccato $white-1 (prova); 1.0.11: hero 30px sotto l'header staccato; 1.0.12: hero pagine più bassa, 20px sotto l'header; 1.0.13: hero pagine un po' più alta; 1.0.14: logo senza pillola bianca; 1.0.15: logo 30px; 1.0.16: via lineetta breadcrumbs; 1.0.17: occhiello senza lineetta; 1.0.18: via black-2 e black-3; 1.0.19: colori neutri blu/grigio; 1.0.20: elenchi senza margini
        wp_enqueue_style('photoswipe', TEMPLATE_URI . 'css/photoswipe.css', [], '5.4.4');
        // INIT JS
        wp_enqueue_script('gsap', TEMPLATE_URI . 'js/gsap/gsap-3.15.0.min.js', [], '3.15.0', true);
        wp_enqueue_script('gsap-scrolltrigger', TEMPLATE_URI . 'js/gsap/ScrollTrigger-3.15.0.min.js', ['gsap'], '3.15.0', true);

        wp_enqueue_script('main', TEMPLATE_URI . 'js/main.js', ['gsap', 'gsap-scrolltrigger'], '1.0.7', true); // NKCS131126 — 1.0.7: mobile-menu.js chiude il pannello sopra i 1024px (variante orizzontale)
    }

    add_action('wp_enqueue_scripts', 'nb_carica_script');
}

// Aggiunge type="module" al tag di main.js — NKCS100926
add_filter('script_loader_tag', function ($tag, $handle) {
    if ($handle === 'main') {
        $tag = str_replace(' src=', ' type="module" src=', $tag);
    }
    return $tag;
}, 10, 2);


// ============================================================
// PHOTOSWIPE — modulo ESM esposto su window per il blocco Gallery Grid
// PhotoSwipe 5 è distribuito solo come ES module, e wp_enqueue_script
// non emette type="module". Lo espongo su window da uno script inline
// nel footer, così main.js (che NON è un module) può usarlo — NKCS_PHOTOSWIPE
// File sorgente in locale (js/photoswipe/), non più dalla CDN unpkg,
// per non dipendere da un dominio esterno e velocizzare il caricamento.
// ============================================================
function nkcs_photoswipe_module()
{
?>
    <script type="module">
        import PhotoSwipeLightbox from '<?= TEMPLATE_URI ?>js/photoswipe/photoswipe-lightbox.esm.js';
        import PhotoSwipe from '<?= TEMPLATE_URI ?>js/photoswipe/photoswipe.esm.js';

        window.PhotoSwipeLightbox = PhotoSwipeLightbox;
        window.PhotoSwipe = PhotoSwipe;

        // Il modulo ESM è deferred: può eseguire PRIMA o DOPO main.js.
        // Il flag copre il caso "prima" (main.js lo legge e parte subito),
        // l'evento copre il caso "dopo" (main.js sta già in ascolto).
        window.nkcsPhotoSwipeReady = true;
        window.dispatchEvent(new Event('nkcs:photoswipe-ready'));
    </script>
<?php
}
add_action('wp_footer', 'nkcs_photoswipe_module', 5);


// ============================================================
// INIT JS (DIPENDENZA JS DI SWIPER)
// ============================================================
function theme_force_greenshift_swiper()
{
    // CSS Swiper — preso direttamente da Greenshift
    wp_enqueue_style(
        'gsswiper-css',
        plugins_url('greenshift-animation-and-page-builder-blocks/libs/swiper/swiper-bundle.min.css'),
        [],
        '9.3.3'
    );

    wp_enqueue_script('gsswiper');
    wp_enqueue_script('gs-swiper-init');
}
add_action('wp_enqueue_scripts', 'theme_force_greenshift_swiper');


// ============================================================
// PRELOAD DEI FONT
// NKCS170926 — Noto Serif → Mulish, Lora → Libre Baskerville
// NKCS170926 — rimosso Dancing Script (usato solo dai necrologi, eliminati)
// NKCS210926 — Mulish e Libre Baskerville → Poppins (unico font del tema)
// ============================================================
function tema_preload_fonts()
{
    echo '<link rel="preload" href="' . TEMPLATE_URI . 'fonts/poppins-v24-latin-regular.woff2" as="font" type="font/woff2" crossorigin>';
    // NKCS111126 — preload Poppins 600 (h3)
    echo '<link rel="preload" href="' . TEMPLATE_URI . 'fonts/poppins-v24-latin-600.woff2" as="font" type="font/woff2" crossorigin>';
    echo '<link rel="preload" href="' . TEMPLATE_URI . 'fonts/poppins-v24-latin-700.woff2" as="font" type="font/woff2" crossorigin>';
}
add_action('wp_head', 'tema_preload_fonts');


// ============================================================
// SUPPORTO EDITOR GUTENBERG — NKCS100926 (spostato da inc/gutenberg.php)
// ============================================================
function nb_gutenberg_support()
{
    // Abilito la possibilità di caricare stili CSS nell'editor back-end di Gutenberg
    add_theme_support('editor-styles');

    // Carico il mio stile CSS per l'editor di Gutenber
    add_editor_style('css/editor.css');
}
add_action('after_setup_theme', 'nb_gutenberg_support');
