<?php
// ============================================================
// BLOCCO ACF: Gallery Swiper + PhotoSwipe — NKCS110926
// Blocco gemello di acf/gallery-grid: stesse celle 1:1 e stessa
// lightbox PhotoSwipe al click, ma le immagini scorrono in uno
// Swiper invece di stare tutte in griglia fissa. Swiper è la
// libreria globale già caricata da Greenshift (vedi
// theme_force_greenshift_swiper() in inc/assets/assets.php),
// nessun nuovo enqueue necessario.
//
// Campi ACF sul blocco (acf/gallery-swiper), gruppo
// "group_nkcs_gallery_swiper":
//   - "nkcs_gallery_swiper_images"        (Gallery)
//   - "nkcs_gallery_swiper_col_desktop"   (Select 1-6) — ≥1024px, default 4
//   - "nkcs_gallery_swiper_col_tablet"    (Select 1-6) — 769-1024px, default 3
//   - "nkcs_gallery_swiper_col_tablet_sm" (Select 1-6) — 768px, default 2
//   - "nkcs_gallery_swiper_col_mobile"    (Select 1-4) — ≤600px, default 1
// I 4 valori vanno in altrettanti data-attribute sul wrapper,
// letti da js/moduli/gallery-swiper.js per i breakpoints di
// Swiper (slidesPerView, non gestibile via CSS come nel blocco
// griglia).
// ============================================================

$gallery       = get_field('nkcs_gallery_swiper_images');
$col_desktop   = get_field('nkcs_gallery_swiper_col_desktop');
$col_tablet    = get_field('nkcs_gallery_swiper_col_tablet');
$col_tablet_sm = get_field('nkcs_gallery_swiper_col_tablet_sm');
$col_mobile    = get_field('nkcs_gallery_swiper_col_mobile');

if (empty($gallery) || !is_array($gallery)) {
    if (!empty($is_preview)) {
        echo '<p style="padding:20px;text-align:center;opacity:.6;">Seleziona le immagini nel campo Gallery per vedere l\'anteprima.</p>';
    }
    return;
}

if ($is_preview) {
    printf(
        '<div style="padding:20px;text-align:center;opacity:.6;">Gallery Swiper — %d immagini selezionate</div>',
        count($gallery)
    );
    return;
}

$align_class = !empty($block['align']) ? 'align' . $block['align'] : '';
$swiper_uid  = 'nkcs-gallery-swiper-' . $block['id'];

$cols_desktop   = (!empty($col_desktop) && (int) $col_desktop > 0) ? (int) $col_desktop : 4;
$cols_tablet    = (!empty($col_tablet) && (int) $col_tablet > 0) ? (int) $col_tablet : 3;
$cols_tablet_sm = (!empty($col_tablet_sm) && (int) $col_tablet_sm > 0) ? (int) $col_tablet_sm : 2;
$cols_mobile    = (!empty($col_mobile) && (int) $col_mobile > 0) ? (int) $col_mobile : 1;
?>

<?php // NKCS111126 — classe nkcs-gallery-swiper-wrap: larghezza piena anche dentro contenitori flex con align-items: flex-start (Greenshift) ?>
<div class="nkcs-gallery-swiper-wrap <?= esc_attr($align_class) ?>">
    <div class="nkcs-gallery-swiper swiper"
        id="<?= esc_attr($swiper_uid) ?>"
        data-col-desktop="<?= esc_attr($cols_desktop) ?>"
        data-col-tablet="<?= esc_attr($cols_tablet) ?>"
        data-col-tablet-sm="<?= esc_attr($cols_tablet_sm) ?>"
        data-col-mobile="<?= esc_attr($cols_mobile) ?>">

        <div class="swiper-wrapper">
            <?php foreach ($gallery as $img) :
                $full  = wp_get_attachment_image_src($img['ID'], 'full');
                $large = wp_get_attachment_image_src($img['ID'], 'large');
                if (!$full || !$large) continue;
            ?>
                <div class="swiper-slide">
                    <a class="nkcs-gallery-swiper__item"
                        draggable="false"
                        href="<?= esc_url($full[0]) ?>"
                        data-pswp-width="<?= esc_attr($full[1]) ?>"
                        data-pswp-height="<?= esc_attr($full[2]) ?>"
                        target="_blank">
                        <img class="nkcs-gallery-swiper__image"
                            draggable="false"
                            src="<?= esc_url($large[0]) ?>"
                            alt="<?= esc_attr($img['alt'] ?: get_the_title()) ?>"
                            loading="lazy"
                            decoding="async">
                        <span class="nkcs-gallery-swiper__zoom" aria-hidden="true">
                            <i class="fa-solid fa-circle-plus"></i>
                        </span>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>

    </div>

    <?php // NKCS111126 — frecce FUORI dal .swiper (overflow: hidden) così possono sporgere dal contenitore. Nascoste da Swiper (swiper-button-lock) se non ci sono altre foto da scorrere ?>
    <button class="swiper-button-prev" type="button" aria-label="Immagine precedente">
        <i class="fa-solid fa-chevron-left" aria-hidden="true"></i>
    </button>
    <button class="swiper-button-next" type="button" aria-label="Immagine successiva">
        <i class="fa-solid fa-chevron-right" aria-hidden="true"></i>
    </button>
</div>
