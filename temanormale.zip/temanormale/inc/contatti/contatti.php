<?php

/**
 * CONTATTI GLOBALI — NKCS
 *
 * Unica fonte dei dati di contatto del sito, letti dalla ACF Options Page
 * "Contatti Globali" (slug contatti-globali, gruppo group_nkcs_opzioni):
 *   - nkcs_contatti_globali → sedi, telefoni, email, social, policy
 *   - nkcs_footer           → piva, nome azienda, nome azienda barra finale
 *
 * I gruppi nkcs_contatti_firma e nkcs_email_invio NON passano di qui:
 * la firma email è un contesto indipendente, letto da nkcs_azienda()
 * in inc/moduli/form/parts/email-helpers.php.
 * Eccezione — NKCS131126: indirizzo, link Maps, telefoni ed email della firma
 * vengono da qui, dalle sedi indicate in nkcs_firma_sedi_slug (slug separati
 * da virgola → nkcs_contatto('sedi', slug) + nkcs_contatti_per_slug()).
 *
 * La Options Page NON è registrata dal tema: arriva dalla UI di ACF PRO.
 * Se ACF non è attivo, la funzione restituisce comunque l'array completo
 * con tutti i valori vuoti, così i template non vanno mai in errore.
 *
 * Storico:
 * NKCS070726 — aggiunti repeater sedi / telefoni / operiamo_a
 * NKCS040926 — spostata da functions.php a inc/contatti.php
 * NKCS100926 — spostata da inc/contatti.php a inc/contatti/contatti.php
 *              (raggruppata con banda-contatti.php nella stessa cartella)
 * NKCS110926 — riscritta sulla nuova struttura ACF (nkcs_contatti_globali +
 *              nkcs_footer). Ogni repeater è normalizzato in una lista di
 *              righe con chiavi corte e href già pronti. Aggiunti gli helper
 *              nkcs_contatto() (riga per slug) e nkcs_href_tel().
 * NKCS180926 — rimosso WhatsApp dal tema (lista whatsapp_lista e chiave whatsapp).
 * NKCS170926 — @package aggiornato (i necrologi non esistono più nel tema).
 * NKCS210926 — aggiunto 'orari' (wysiwyg) alla normalizzazione di 'sedi'.
 * NKCS220926 — banda-contatti.php non è più in questa cartella: ora è
 *              template-parts/banda-contatti.php (pattern sincronizzato 278).
 * NKCS131126 — 'orari' della sede non è più un wysiwyg: ora è il repeater
 *              nkcs_sede_orari (sottocampi nkcs_orario_label + nkcs_orario),
 *              normalizzato in righe ['label' => …, 'orario' => …].
 *
 * Uso nei template:
 *   $nkcs_contatti = nkcs_contatti();
 *   foreach ($nkcs_contatti['telefoni'] as $tel) { ... $tel['href'] ... }
 *   $tel = nkcs_contatto_sede('telefoni');          // telefono della sede principale
 *   $tutti = nkcs_contatti_per_slug('telefoni', 'sede-principale');
 *
 * Convenzione slug — NKCS131126 (campo *_slug obbligatorio in ogni repeater):
 * lo slug lega le righe alla sede. In ogni repeater si usa lo STESSO slug
 * della sede (es. "sede-principale" in Sedi, Telefoni, Email, Facebook…):
 * è il repeater stesso a dire di che contatto si tratta, niente più suffissi
 * "--tel" / "--cell" / "--email". La sede principale è la prima riga di Sedi.
 *
 * @package NKCS
 */

if (! defined('ABSPATH')) {
    exit;
}

/**
 * Stampa un campo di testo (es. indirizzo) permettendo solo <br>.
 * Come esc_html() ma senza scappare i <br> scritti nel campo ACF.
 *
 * @param string $testo Testo come scritto in ACF.
 * @return string HTML pronto per l'output (già escapato).
 */
function nkcs_esc_br($testo): string
{
    return wp_kses((string) $testo, ['br' => []]);
}

/**
 * Href tel: da un numero visualizzato.
 * "0426 79056" → "tel:+39042679056" · "+39 800 200 289" → "tel:+39800200289"
 * Se il numero non ha prefisso internazionale (+ o 00) aggiunge +39.
 *
 * @param string $numero Numero come scritto in ACF.
 * @return string Href completo, oppure '' se il numero è vuoto.
 */
function nkcs_href_tel($numero): string
{
    $pulito = preg_replace('/[^0-9+]/', '', (string) $numero);
    if ($pulito === '') return '';

    if (strpos($pulito, '00') === 0) {
        $pulito = '+' . substr($pulito, 2);
    } elseif ($pulito[0] !== '+') {
        $pulito = '+39' . $pulito;
    }
    return 'tel:' . $pulito;
}

/**
 * Restituisce i contatti globali del sito, normalizzati.
 *
 * Il risultato è memorizzato in una static: get_field() viene interrogato
 * una sola volta per richiesta, anche se header e footer la chiamano entrambi.
 * Le righe senza il dato principale (numero, indirizzo, url) vengono scartate.
 *
 * @return array {
 *     @type array      $sedi           Righe: slug, nome, localita, indirizzo, link (ACF link|null), immagine_id (int),
 *                                      orari (righe: label, orario — scartate quelle del tutto vuote).
 *     @type array      $telefoni       Righe: slug, etichetta, numero, href.
 *     @type array      $email          Righe: slug, etichetta, indirizzo, href.
 *     @type array      $facebook       Righe: slug, etichetta, link (ACF link).
 *     @type array      $instagram      Righe: slug, etichetta, link (ACF link).
 *     @type array|null $privacy_policy Campo ACF link.
 *     @type array|null $cookie_policy  Campo ACF link.
 *     @type array      $footer         piva, nome_azienda, nome_azienda_end,
 *                                      operiamo_a (righe: nome, link).
 *
 *     Chiavi di compatibilità (lette da template-parts/menu/mobile/mobile-bar.php,
 *     da rimuovere quando anche quel file sarà cablato):
 *     @type string     $telefono       Numero della riga telefoni con lo slug della sede principale (o la prima).
 * }
 */
function nkcs_contatti(): array
{
    static $cache = null;
    if ($cache !== null) return $cache;

    $has_acf = function_exists('get_field');

    $raw = $has_acf ? get_field('nkcs_contatti_globali', 'option') : [];
    if (!is_array($raw)) $raw = [];

    $raw_footer = $has_acf ? get_field('nkcs_footer', 'option') : [];
    if (!is_array($raw_footer)) $raw_footer = [];

    // Stringa pulita da un array ACF
    $txt = function ($src, $key) {
        return isset($src[$key]) && is_string($src[$key]) ? trim($src[$key]) : '';
    };

    // Link ACF valido (array con url) oppure null
    $link = function ($src, $key) {
        $l = $src[$key] ?? null;
        return (is_array($l) && !empty($l['url'])) ? $l : null;
    };

    // Righe di un repeater (sempre array)
    $righe = function ($key) use ($raw) {
        return (isset($raw[$key]) && is_array($raw[$key])) ? $raw[$key] : [];
    };

    // --- Sedi ---------------------------------------------------------------
    $sedi = [];
    foreach ($righe('nkcs_sedi') as $r) {
        $nome = $txt($r, 'nkcs_sede_nome');
        if ($nome === '') continue;

        // NKCS131126 — orari: repeater label + orario
        $orari = [];
        $raw_orari = (isset($r['nkcs_sede_orari']) && is_array($r['nkcs_sede_orari'])) ? $r['nkcs_sede_orari'] : [];
        foreach ($raw_orari as $o) {
            if (!is_array($o)) continue;
            $o_label  = $txt($o, 'nkcs_orario_label');
            $o_orario = $txt($o, 'nkcs_orario');
            if ($o_label === '' && $o_orario === '') continue;
            $orari[] = ['label' => $o_label, 'orario' => $o_orario];
        }

        $sedi[] = [
            'slug'        => $txt($r, 'nkcs_sede_slug'),
            'nome'        => $nome,
            'localita'    => $txt($r, 'nkcs_sede_localita'),
            'indirizzo'   => $txt($r, 'nkcs_sede_indirizzo'),
            'link'        => $link($r, 'nkcs_sede_link'),
            'immagine_id' => absint($r['nkcs_sede_immagine'] ?? 0),
            'orari'       => $orari,
        ];
    }

    // --- Telefoni -----------------------------------------------------------
    // nkcs_tel_link (text) vince sull'href generato dal numero.
    $telefoni = [];
    foreach ($righe('nkcs_telefoni') as $r) {
        $numero = $txt($r, 'nkcs_tel_numero');
        if ($numero === '') continue;
        $href = $txt($r, 'nkcs_tel_link');
        if ($href !== '' && stripos($href, 'tel:') !== 0) $href = nkcs_href_tel($href);
        $telefoni[] = [
            'slug'      => $txt($r, 'nkcs_tel_slug'),
            'etichetta' => $txt($r, 'nkcs_tel_etichetta'),
            'numero'    => $numero,
            'href'      => $href !== '' ? $href : nkcs_href_tel($numero),
        ];
    }

    // --- Email --------------------------------------------------------------
    // nkcs_email_link (text) vince sul mailto: generato dall'indirizzo.
    $email = [];
    foreach ($righe('nkcs_email') as $r) {
        $indirizzo = preg_replace('/\s+/', '', $txt($r, 'nkcs_email_indirizzo'));
        if ($indirizzo === '') continue;
        $href = $txt($r, 'nkcs_email_link');
        if ($href !== '' && stripos($href, 'mailto:') !== 0) $href = 'mailto:' . $href;
        $email[] = [
            'slug'      => $txt($r, 'nkcs_email_slug'),
            'etichetta' => $txt($r, 'nkcs_email_etichetta'),
            'indirizzo' => $indirizzo,
            'href'      => $href !== '' ? $href : 'mailto:' . $indirizzo,
        ];
    }

    // --- Social (Facebook / Instagram) -------------------------------------
    $social = function ($key, $pref) use ($righe, $txt, $link) {
        $out = [];
        foreach ($righe($key) as $r) {
            $l = $link($r, $pref . '_link');
            if (!$l) continue;
            $out[] = [
                'slug'      => $txt($r, $pref . '_slug'),
                'etichetta' => $txt($r, $pref . '_etichetta'),
                'link'      => $l,
            ];
        }
        return $out;
    };

    // --- Operiamo a (footer) -----------------------------------------------
    // NKCS110926 — campo non ancora creato in ACF: previsto come repeater
    // nkcs_operiamo_a dentro nkcs_footer (sottocampi nkcs_op_nome, nkcs_op_link
    // page_link). Finché non esiste la lista resta vuota.
    $operiamo = [];
    $raw_op   = (isset($raw_footer['nkcs_operiamo_a']) && is_array($raw_footer['nkcs_operiamo_a'])) ? $raw_footer['nkcs_operiamo_a'] : [];
    foreach ($raw_op as $r) {
        $nome = $txt($r, 'nkcs_op_nome');
        if ($nome === '') continue;
        $operiamo[] = [
            'nome' => $nome,
            'link' => is_string($r['nkcs_op_link'] ?? null) ? $r['nkcs_op_link'] : '',
        ];
    }

    // --- Compatibilità mobile-bar.php --------------------------------------
    // NKCS131126 — stesso slug della sede principale (prima: slug fisso 'principale')
    $slug_princ     = $sedi[0]['slug'] ?? '';
    $tel_principale = '';
    foreach ($telefoni as $t) {
        if ($slug_princ !== '' && $t['slug'] === $slug_princ) {
            $tel_principale = $t['numero'];
            break;
        }
    }
    if ($tel_principale === '' && $telefoni) $tel_principale = $telefoni[0]['numero'];

    $cache = [
        'sedi'           => $sedi,
        'telefoni'       => $telefoni,
        'email'          => $email,
        'facebook'       => $social('nkcs_facebook', 'nkcs_fb'),
        'instagram'      => $social('nkcs_instagram', 'nkcs_ig'),
        'privacy_policy' => $link($raw, 'nkcs_privacy_policy'),
        'cookie_policy'  => $link($raw, 'nkcs_cookie_policy'),
        'footer'         => [
            'piva'             => $txt($raw_footer, 'nkcs_footer_piva'),
            'nome_azienda'     => $txt($raw_footer, 'nkcs_footer_nome_azienda'),
            'nome_azienda_end' => $txt($raw_footer, 'nkcs_footer_nome_azienda_end'),
            'operiamo_a'       => $operiamo,
        ],

        // Compatibilità (vedi docblock)
        'telefono'       => $tel_principale,
    ];
    return $cache;
}

/**
 * Una singola riga di una lista contatti, cercata per slug.
 * Senza slug restituisce la prima riga della lista.
 *
 * @param string $tipo Chiave lista: sedi | telefoni | email | facebook | instagram.
 * @param string $slug Valore del campo *_slug della riga.
 * @return array|null
 */
function nkcs_contatto(string $tipo, string $slug = ''): ?array
{
    $lista = nkcs_contatti()[$tipo] ?? [];
    if (!is_array($lista) || !$lista) return null;
    if ($slug === '') return $lista[0];

    foreach ($lista as $riga) {
        if (($riga['slug'] ?? '') === $slug) return $riga;
    }
    return null;
}

/**
 * NKCS131126 — Riga di una lista contatti collegata a una sede: quella con lo
 * stesso slug della sede. Senza sede usa la sede principale (prima riga di
 * Sedi). Se nessuna riga ha quello slug restituisce la prima della lista.
 *
 * @param string     $tipo Chiave lista: telefoni | email | facebook | instagram.
 * @param array|null $sede Riga di Sedi (da nkcs_contatto('sedi', …)). Null = sede principale.
 * @return array|null
 */
function nkcs_contatto_sede(string $tipo, ?array $sede = null): ?array
{
    $sede = $sede ?: nkcs_contatto('sedi');
    $slug = $sede['slug'] ?? '';
    return ($slug !== '' ? nkcs_contatto($tipo, $slug) : null) ?: nkcs_contatto($tipo);
}

/**
 * NKCS131126 — Tutte le righe di una lista contatti con un certo slug
 * (es. fisso e cellulare della stessa sede in Telefoni).
 *
 * @param string $tipo Chiave lista: sedi | telefoni | email | facebook | instagram.
 * @param string $slug Slug cercato.
 * @return array Righe trovate (vuoto se nessuna).
 */
function nkcs_contatti_per_slug(string $tipo, string $slug): array
{
    if ($slug === '') return [];
    $lista = nkcs_contatti()[$tipo] ?? [];
    if (!is_array($lista)) return [];
    return array_values(array_filter($lista, fn($riga) => ($riga['slug'] ?? '') === $slug));
}


/**
 * NKCS041126 — Gruppo ACF "Pagina 404" (options page "Contatti Globali").
 *
 * @return array {
 *     @type string $titolo       Titolo H1 della 404 ('' se non compilato).
 *     @type string $descrizione  HTML descrizione ('' se non compilata).
 *     @type int    $immagine_id  ID dell'immagine in evidenza (0 se assente).
 * }
 */
function nkcs_pagina_404(): array
{
    static $cache = null;
    if ($cache !== null) return $cache;

    $raw = function_exists('get_field') ? get_field('nkcs_pagina_404', 'option') : [];
    if (!is_array($raw)) $raw = [];

    $cache = [
        'titolo'      => isset($raw['nkcs_404_titolo']) && is_string($raw['nkcs_404_titolo']) ? trim($raw['nkcs_404_titolo']) : '',
        'descrizione' => isset($raw['nkcs_404_descrizione']) && is_string($raw['nkcs_404_descrizione']) ? trim($raw['nkcs_404_descrizione']) : '',
        'immagine_id' => (int) ($raw['nkcs_404_immagine'] ?? 0),
    ];
    return $cache;
}
