<?php /* IOF Corona — header — NKCS260626 */ ?>
<?php /* NKCS031126 — header: logo in pillola bianca a sx; a dx telefono (cerchio), CTA "Preventivo Gratuito" e hamburger, su tutti i breakpoint. Menu desktop orizzontale non più stampato qui (il menu è sempre il pannello a scomparsa). */ ?>
<?php /* NKCS110926 — contatti dalla nuova struttura ACF (nkcs_contatti), numero verde non più hardcoded, alt logo da nkcs_footer_nome_azienda */ ?>
<?php /* NKCS220926 — header a due zone: logo a sinistra, nav (con CTA "Contattaci",
         classe nkcs-menu-item--contatti sulla voce menu) allineata a destra.
         Rimosso il box "In caso di lutto" (retaggio del vecchio tema funerario). */ ?>
<?php /* NKCS220926 — loader iniziale (div.nkcs-loader, solo CSS: components/_loader.scss)
         subito dopo wp_body_open(): spinner bianco su velo $black che scompare in dissolvenza. */ ?>
<?php /* NKCS131126 — rimosso lo snippet Google Tag Manager cablato (GTM-MD9K22TX + stub gtag/dataLayer) dall'<head>. */ ?>
<?php /* NKCS131126 — menu sopra i 1024px a scelta da NKCS_LAYOUT['menu_desktop']: 'megamenu' (hamburger + pannello, come prima) o 'orizzontale' (nav in riga di Geonova, stampata in .header__right). Sotto i 1024px sempre hamburger + pannello. */ ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>

    <meta charset="<?php bloginfo('charset'); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

	<?php /* Google Tag Manager — qui va lo snippet <head> di GTM */ ?>

	<?php wp_head(); ?>
	
</head>

<body <?php body_class(); ?>>
    <?php wp_body_open(); ?>

    <?php
    // --- Contatti per l'header (stessa fonte del footer) ---
    $nkcs_contatti = nkcs_contatti();
    $nkcs_site     = $nkcs_contatti['footer']['nome_azienda'] ?: get_bloginfo('name');

    // --- Logo primario da ACF (gruppo nkcs_loghi, options page "Contatti Globali") ---
    // Fallback sul logo statico del tema se il campo non è ancora compilato.
    $nkcs_loghi    = get_field('nkcs_loghi', 'option');
    $nkcs_logo     = $nkcs_loghi['nkcs_logo_default'] ?? null;
    $nkcs_logo_src = $nkcs_logo['url'] ?? (TEMPLATE_URI . 'img/logo-white.png');
    $nkcs_logo_alt = ($nkcs_logo['alt'] ?? '') ?: $nkcs_site;
    ?>

    <?php // NKCS220926 — loader iniziale: decorativo (aria-hidden), spinner tutto in CSS (niente immagini) ?>
    <div class="nkcs-loader" aria-hidden="true"></div>

    <?php
    // NKCS031126 — numero del pulsante telefono. Al passaggio del mouse il pulsante si apre
    // e mostra il numero (vedi layout/_header.scss → .header__tel-numero).
    // NKCS131126 — riga Telefoni con lo stesso slug della sede principale (niente più "--tel"),
    // fallback sulla prima riga di Telefoni.
    $nkcs_cell = nkcs_contatto_sede('telefoni');

    // NKCS031126 — link "Preventivo Gratuito": voce di menu con classe nkcs-menu-item--contatti,
    // altrimenti fallback su /contatti/
    $nkcs_preventivo_url = home_url('/contatti/');
    foreach (nkcs_menu_tree() as $nkcs_node) {
        if (in_array('nkcs-menu-item--contatti', (array) $nkcs_node['item']->classes, true)) {
            $nkcs_preventivo_url = $nkcs_node['item']->url;
            break;
        }
    }
    ?>

    <?php // NKCS131126 — nkcs-header--sovrapposto | nkcs-header--staccato (Contatti Globali → Menu e header) ?>
    <header class="nkcs-header nkcs-header--<?= esc_attr(nkcs_header_posizione()); ?>">
        <div class="header">
            <div class="header__content">
                <div class="header__logo header__left">
                    <a href="<?= esc_url(home_url('/')); ?>">
                        <img id="header-logo"
                            class="skip-lazy no-lazy"
                            data-no-lazy="1"
                            loading="eager"
                            fetchpriority="high"
                            decoding="sync"
                            src="<?= esc_url($nkcs_logo_src); ?>"
                            alt="<?= esc_attr($nkcs_logo_alt); ?>"
                            width="236" height="40">
                    </a>
                </div>

                <div class="header__right">
                    <?php // NKCS131126 — menu sopra i 1024px: 'megamenu' (nessun markup qui) o 'orizzontale' (nav in riga). Vedi NKCS_LAYOUT. ?>
                    <?php nkcs_layout_part('menu_desktop'); ?>

                    <?php if ($nkcs_cell) : ?>
                        <a class="header__tel"
                            href="<?= esc_url($nkcs_cell['href'], ['tel']); ?>"
                            aria-label="Chiama <?= esc_attr($nkcs_cell['numero']); ?>">
                            <i class="fa-solid fa-phone" aria-hidden="true"></i>
                            <span class="header__tel-numero"><span><?= esc_html($nkcs_cell['numero']); ?></span></span>
                        </a>
                    <?php endif; ?>

                    <a class="header__cta" href="<?= esc_url($nkcs_preventivo_url); ?>">Preventivo Gratuito</a>

                    <?php nkcs_layout_part('menu_mobile', ['parte' => 'toggle']); ?>
                </div>
            </div>
        </div>
    </header>

    <?php if ($nkcs_cell) : ?>
        <?php /* NKCS041126 — pulsante "Chiama" fixed in basso a destra, solo sotto i 1024px (fuori dall'header: un genitore con transform rompe position: fixed). Vedi layout/_header.scss → .nkcs-call-fab */ ?>
        <a class="nkcs-call-fab"
            href="<?= esc_url($nkcs_cell['href'], ['tel']); ?>"
            aria-label="Chiama <?= esc_attr($nkcs_cell['numero']); ?>">
            <i class="fa-solid fa-phone" aria-hidden="true"></i>
        </a>
    <?php endif; ?>

    <?php nkcs_layout_part('menu_mobile', ['parte' => 'pannello']); ?>

    <main>
