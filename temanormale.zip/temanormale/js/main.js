import { initHeader } from './moduli/header.js';
// NKCS220926 — mobile bar e popup sedi disattivati (file lasciati in js/moduli/),
// sostituiti dal pulsante "Chiama" fisso (chiama-fisso.js)
// import { initMobileButtons } from './moduli/mobile-bar.js';
// import { initSedePopup } from './moduli/sede-popup.js';
import { initChiamaFisso } from './moduli/chiama-fisso.js';
import { initFormCf7 } from './moduli/form-cf7.js';
import { initGsapAnimation } from './moduli/gsap.js';
import { initHeroSlideshow } from './moduli/hero.js';
import { initMobileMenu } from './moduli/mobile-menu.js';
import { initGalleryGrid } from './moduli/gallery-grid.js';
import { initGallerySwiper } from './moduli/gallery-swiper.js';
import { initSwiperPagineFiglie } from './moduli/swiper-pagine-figlie.js';
import { initFaqYoast } from './moduli/faq-yoast.js';

function init() {
    initHeader();
    // initMobileButtons();
    // initSedePopup();
    initChiamaFisso();
    initFormCf7();
    initGsapAnimation();
    initHeroSlideshow();
    initMobileMenu();
    initGalleryGrid();
    initGallerySwiper();
    initSwiperPagineFiglie();
    initFaqYoast();
    ScrollTrigger.refresh();
}

document.addEventListener('DOMContentLoaded', init);
