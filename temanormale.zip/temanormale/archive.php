<?php get_header(); ?>

<?php if (have_posts()) : the_post(); ?>

    <?php $title = get_the_title(); ?>

<?php endif; ?>

<?php wp_reset_postdata();  ?>

<?php get_footer(); ?>