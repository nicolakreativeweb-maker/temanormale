<?php
/**
 * REGISTRO BLOCCHI NKCS — NKCS100926
 * ------------------------------------------------------------
 * Registra i blocchi Gutenberg/ACF elencati in NKCS_BLOCKS_ATTIVI.
 * Ogni blocco vive in inc/blocks/<slug>/ con block.json + template
 * (spostato dalla vecchia cartella /blocks/ alla radice del tema).
 *
 * Per disattivare un blocco su un cliente basta commentare la sua
 * riga in NKCS_BLOCKS_ATTIVI.
 */

if (!defined('ABSPATH')) exit;

/**
 * Cartella base dei blocchi, con slash finale.
 */
if (!defined('NKCS_BLOCKS_DIR')) {
    define('NKCS_BLOCKS_DIR', get_template_directory() . '/inc/blocks/');
}

/**
 * Elenco dei blocchi attivi. Lo slug corrisponde al nome della
 * cartella in inc/blocks/.
 */
const NKCS_BLOCKS_ATTIVI = [
    'spacer',
    'gallery-grid',
    'gallery-swiper',
];

/**
 * Registra il block.json di ogni blocco attivo su init.
 *
 * Un blocco dichiarato ma non ancora presente su disco viene
 * saltato senza fatal error. Con WP_DEBUG attivo la mancanza
 * viene comunque loggata.
 *
 * @return void
 */
function nkcs_carica_blocks(): void
{
    foreach (NKCS_BLOCKS_ATTIVI as $slug) {

        // Lo slug diventa parte di un path: accetto solo minuscole, cifre e trattini
        if (!preg_match('/^[a-z0-9\-]+$/', $slug)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[NKCS] Slug blocco non valido, ignorato: ' . $slug);
            }
            continue;
        }

        $dir = NKCS_BLOCKS_DIR . $slug;

        if (!file_exists($dir . '/block.json')) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[NKCS] Blocco attivo ma non trovato: ' . $slug . '/block.json');
            }
            continue;
        }

        register_block_type($dir);
    }
}
add_action('init', 'nkcs_carica_blocks');
