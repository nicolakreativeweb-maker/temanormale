
# ANALISI TEMI — Euroinfissi vs Geonova vs Gasparello

Analisi in sola lettura dei tre temi NKCS in `wp-content/themes/`. Nessun file dei temi è stato modificato.
Tutti i percorsi sono relativi a `wp-content/themes/` nel formato `tema/file:riga`.

## 0. Premessa e metodo

**Nomi verificati da `style.css`**

| Cartella | Theme Name | Description |
|---|---|---|
| `euroinfissi/` | Tema Custom EuroInfissi | Tema custom di nicola bazzolo (tema attivo e di riferimento) |
| `geonova/` | Tema Custom | Geonova |
| `gasparello/` | Tema Custom | Gasparello Autotrasporti |

Geonova e Gasparello hanno lo **stesso Theme Name** ("Tema Custom"): in Aspetto > Temi sono indistinguibili. Tutti e tre hanno Version 1.0 e Text Domain `nkt`.

**Cronologia (timbri `NKCSggmmaa` nei commenti)**
- Geonova arriva fino al 23/09/26: è la base da cui derivano gli altri.
- Gasparello prosegue dal 24/09 al 14/10/26 (timbri 240926, 250926, 280926, 290926, 141026).
- Euroinfissi va dal 03/11 al 12/11/26 (timbri 031126, 041126, 051126, 111126, 121126).
- Euroinfissi è il più evoluto, ma è stato derivato **prima** del lavoro Gasparello: nessuno dei suoi timbri è presente. Quel lavoro generico non è mai stato riportato.
- Le date di modifica dei file non servono: sono quelle della copia di oggi (13/11/26).

**Confronto file (hash MD5)**: 36 file identici nei tre temi; 10 diversi solo in Gasparello; 10 diversi solo in Euroinfissi; 39 diversi in tutti e tre; più file unici per tema (sezione 8).

**CLAUDE.md**: non esiste (cercato in `themes/`, nelle cartelle superiori e in `~/.claude`). Come riferimento ho usato le convenzioni NKCS (skill `nkcs-wordpress-conventions`).

**Build SCSS**: nessun `package.json`, Prepros, gulp, vite o webpack. Il CSS è compilato a mano con Dart Sass CLI (installato globalmente, 1.83.4): output expanded, `@charset "UTF-8"`, sourcemap `sourceRoot:""`. Il compilato è allineato agli SCSS (`euroinfissi/css/style.css.map` elenca esattamente i partial importati). In `css/` restano `.map` orfani (`admin.css.map`, `login.css.map`, `custom/template/hero.css.map`, `tipografia/*.css.map`) e la cartella vuota `custom/template/`.

**Affidabilità**: i punti marcati ✔ li ho verificati direttamente leggendo il codice; gli altri vengono dai report dei tre agenti (uno per tema) con le citazioni da loro riportate.

---

## 1. Tabella comparativa

| Aspetto | Euroinfissi | Geonova | Gasparello |
|---|---|---|---|
| **1. Struttura** | `functions.php:38-55` carica con `require_once get_theme_file_path()`: contatti → assets → admin → `inc/layout/menu` → `layout/layout` → registro moduli (`NKCS_MODULI_ATTIVI`, `inc/moduli/nkcs-moduli-init.php:41`) → registro blocchi (`NKCS_BLOCKS_ATTIVI`, `inc/blocks/nkcs-blocks-init.php:26`) → shortcode sede → `nkcs-shortcode-sede-form.php`. Header a pillola + hamburger. | Stessa architettura, senza `sede-form` (`geonova/functions.php:38-54`). Header classico con menu orizzontale (`geonova/header.php:53-75`). Admin bar nascosta (`geonova/functions.php:57`). | Stessa architettura, con `nkcs-shortcode-card.php` al posto di `sede-form` (`gasparello/functions.php:55`). Header a due fasce (`gasparello/header.php:82-117`). |
| **2. Setup** | Supports: html5, title-tag, post-thumbnails, excerpt su page, widgets (`functions.php:21-26`). Menu `primary`/`footer`/`paesi`. Nessun `add_image_size`. Versioni manuali `style` 1.0.5, `main` 1.0.6 (`inc/assets/assets.php:38,44`). Font Poppins con preload 400/600/700 (`assets.php:113-120`). | Identico; versioni 1.0.2/1.0.3 (`geonova/inc/assets/assets.php:38,44`); preload Poppins 400/700 senza il 600. | Identico; versioni 1.0.4/1.0.3; font Barlow con preload 400/700 (`gasparello/inc/assets/assets.php:112-118`). |
| **3. ACF** | Tutto in `acf-json/`, options page "Contatti Globali" via JSON UI. Hero = galleria di immagini (array). Opzioni con 7 group (loghi, contatti, footer, firma, email_invio, `nkcs_pagina_404`, `nkcs_form_contatti`). SEO con `nkcs_seo_occhiello`. Spacer `title/small/medium/large` coerente col CSS. | Hero = interruttore `nkcs_hero_slideshow_attivo` + relationship `nkcs_hero_pagine` (slide = pagine collegate). Mancano 404 e form_contatti. Spacer con `xlarge`/`default` senza CSS. | Hero = interruttore + galleria per ID (`min 2`, solo jpg/png/webp). Opzioni in più: `nkcs_card_home`, `nkcs_404`, `nkcs_hero_overlay`, `nkcs_footer_descrizione`. Stesso bug spacer. |
| **4. CPT e tassonomie** | Nessuno (solo `page`). | Nessuno. | Nessuno. |
| **5. Front-end** | SCSS `@use "../abstracts" as *`, `@forward` in `scss/style.scss:28-75`; mappa `$bp` 600/768/1024/1200/**1600** (`scss/abstracts/_index.scss:75-81`); `$btn-variants` con hover espliciti (`scss/components/_buttons.scss:125-159`); GSAP 3.15 locale con scroll-reveal ScrollTrigger (`js/moduli/gsap.js`); PhotoSwipe ESM locale; Swiper da Greenshift; JS ES module diviso in `js/moduli/`. | Stessa base; `gsap.js` ridotto a una dissolvenza (`geonova/js/moduli/gsap.js:3-7`), ScrollTrigger caricato quasi per niente; `_nkcs-left-line.scss`, `_nkcs-pattern-full.scss`. | Stessa base di settembre; serie di opacità `--nkcs-*` (`gasparello/scss/base/_general.scss:4-15`, `abstracts/_index.scss:39-110`); `--header-total` (`scss/layout/_header.scss:35-63`); toast CF7 (`js/moduli/form-cf7.js:1-55`). |
| **6. Integrazioni** | CF7: conferma su `wpcf7_before_send_mail` (`inc/moduli/form/parts/hook-email-base.php:14`). Yoast solo stile FAQ. iubenda solo link (`footer.php:65`). GTM non standard e cablato (`header.php:18-23`). Greenshift. | CF7 identico. GA4 standard + `preconnect` iubenda (`geonova/header.php:17-30`). | CF7 identico (font Barlow). gtag cablato prima di `wp_head` (`gasparello/header.php:9-17`). |
| **7. Performance e sicurezza** | Hero LCP con `fetchpriority="high"`, `decoding="sync"`, `skip-lazy` (`template-parts/hero/pagina.php:42-51`). Slideshow tutto `eager` (`slideshow.php:64`). Hero senza srcset. Nessun caricamento condizionale. `tel:`/`mailto:` con `esc_attr`. | Slide dalla 2ª con `loading="lazy"` (`geonova/template-parts/hero/slideshow.php:59-60`) ma senza `skip-lazy`/`eager` sull'hero. | Slideshow con `srcset`/`sizes` e lazy dalla 2ª slide (`gasparello/template-parts/hero/slideshow.php:55-63`). `esc_url(..., ['tel'])` (`gasparello/footer.php:140,146`). |
| **8. Peculiarità** | Vedi sezione 2: header pillola, FAB chiamata, `[nkcs_sede_form]`, griglia pagine figlie, occhiello, scroll-reveal. | Slideshow a pagine collegate, linguetta, `.nkcs-left-line`, pattern full-bleed. | Overlay hero da ACF, card home, sede a colonne, referenti, `nkcs-wp-list`, `nkcs-titoli`. |

---

## 2. Schede per tema

### 2.1 Euroinfissi (riferimento)

**Punti di forza**
- Architettura modulare con registri validati (slug con regex, moduli mancanti saltati in silenzio): `inc/moduli/nkcs-moduli-init.php:81-106`.
- Helper contatti con cache `nkcs_contatti()` e href già pronti (`inc/contatti/contatti.php:108`).
- SCSS moderno: `@use`, `color-mix()` per `tint/shade/alpha` (`scss/abstracts/_index.scss:43-62`), mappa breakpoint con `@error`, `$btn-variants`.
- Scroll-reveal robusto (batch, reduced-motion, bfcache, fallback se GSAP manca): `js/moduli/gsap.js:59-110`, `scss/base/_animations.scss:21-41`.
- `gallery-swiper.js` maturo: frecce nascoste se non servono, loop solo sotto i 600px, soglia di trascinamento, click sulle slide laterali che scorre: `js/moduli/gallery-swiper.js:28-85,155`.
- Pagina 404 da ACF con helper `nkcs_pagina_404()` (`inc/contatti/contatti.php:265-288`, `404.php:6-14`).
- Hero LCP protetta dai plugin di lazy-load (`skip-lazy no-lazy data-no-lazy loading="eager"`).
- Accessibilità hero (pausa al focus, reduced-motion, `touch-action: pan-y`) in `js/moduli/hero.js`.

**Punti deboli**
- Template hierarchy incompleta (sezione 5, punto 1).
- Asset mancanti in `img/` (sezione 5, punto 2).
- Molto codice morto lasciato dai restyle di novembre, con commenti storici "era X, poi Y".
- Nessun caricamento condizionale di PhotoSwipe, Font Awesome, Swiper; nessun srcset sulla hero.
- Valori del cliente nel codice (GTM, ID pattern 278, `/contatti/`).

**Peculiarità uniche**
- Header a pillola con telefono a cerchio, CTA "Preventivo Gratuito" ricavata dalla voce di menu con classe `nkcs-menu-item--contatti` e hamburger sempre visibile (`header.php:59-102`).
- Pulsante "Chiama" flottante `.nkcs-call-fab` (`header.php:105-112`).
- Shortcode `[nkcs_sede_form]` (`inc/shortcode/nkcs-shortcode-sede-form.php`, stile in `scss/components/_sede-form.scss`).
- Griglia pagine figlie con ultima riga adattiva (`inc/moduli/pagine-figlie/parts/grid-pagine-figlie.php`, `scss/modules/shortcode/_pagine-figlie-grid.scss:35-64`).
- Occhiello (`scss/nkcs-custom/_nkcs-occhiello.scss`, campo `nkcs_seo_occhiello`), utility `.nkcs-list--no-margin`, variante FAQ scura `.nkcs-faq--white`, spacer `title`, `screenshot.jpg`.

### 2.2 Geonova

**Punti di forza**
- Slideshow "a pagine collegate" accessibile (H1 solo per screen reader, titoli in H2 sovrapposti nella stessa cella, comparsa sfalsata): `geonova/inc/layout/layout.php:133-172`, `geonova/template-parts/hero/slideshow.php:83-115`, `geonova/acf-json/group_nkcs_hero_slides.json`.
- Colori fissi documentati `full-white`/`full-black` (`geonova/scss/abstracts/_index.scss:22-25`, `geonova/theme.json:95-99`).
- Icona +/− delle FAQ in CSS puro (`geonova/scss/vendor/_yoast-faq.scss:80-92,130-134`).
- Hover "glass" del menu desktop con `::before` e sottomenu con "ponte" invisibile (`geonova/scss/layout/_menu.scss:82-130`).
- `preconnect` iubenda e snippet GA4 corretto (`geonova/header.php:17-30`).

**Punti deboli**
- Fermo a settembre: mancano tutte le correzioni di novembre.
- GSAP + ScrollTrigger (circa 117 KB) caricati per quasi niente; `.nkcs-gsap-reveal` senza CSS/JS; `.gs-fade-in` lascia il contenuto invisibile (`geonova/scss/base/_animations.scss:10-18`).
- Spacer `xlarge`/`default` alto 0 (`geonova/scss/vendor/_gutenberg.scss:327-346`).
- Residuo di debug `background-color: rebeccapurple` (`geonova/scss/layout/_menu.scss:353-355`).
- `404.php` incoerente con le altre hero (separatore doppio, "Page Not Found" in inglese, `href="/"`: righe 37-52).
- Commento/codice in contraddizione in `_nkcs-pattern-full.scss` (riga 28 vs 42).

**Peculiarità uniche**
- `geonova/scss/nkcs-custom/_nkcs-left-line.scss` (utility `.nkcs-left-line` con varianti colore).
- `geonova/scss/nkcs-custom/_nkcs-pattern-full.scss` (presente anche in Gasparello): pattern Greenshift immagine+testo a tutta larghezza.
- Linguetta bianca "scorri giù" su tutte le hero; menu mobile che entra da destra con velo scuro.

### 2.3 Gasparello

**Punti di forza**
- Overlay hero configurabile da ACF con CSS generato e sanificato (`sanitize_hex_color`, opacità 0-100): `gasparello/inc/contatti/contatti.php:268-316`, `gasparello/acf-json/group_nkcs_opzioni.json:1399-1540`.
- Toast CF7 accessibili (`role="alert"/"status"`, `type="button"`, barra di avanzamento, reduced-motion): `gasparello/js/moduli/form-cf7.js:1-55`, `gasparello/scss/components/_form-cf7.scss:111-130,745-905`.
- Slideshow con `srcset`/`sizes` e lazy dalla 2ª slide (`gasparello/template-parts/hero/slideshow.php:55-63`).
- Shortcode con convenzione `nkcs_shortcode_<nome>` e alias deprecati (`gasparello/inc/moduli/pagine-figlie/modulo.php:69-111`, `gasparello/inc/shortcode/nkcs-shortcode-sede.php:228-229`).
- `overscroll-behavior` separato per asse (`gasparello/scss/base/_general.scss:23-35`), `scroll-padding-top` legato a `--header-total` (riga 20).
- `esc_url($href, ['tel'])` per tel e mailto.

**Punti deboli**
- Base di settembre: non ha le migliorie di novembre (GSAP, frecce Swiper, menu mobile, 404, FAQ, protezione LCP).
- ✔ `gasparello/404.php:71` fa `nl2br(esc_html())` su una textarea ACF già con `new_lines: br` (`group_nkcs_opzioni.json:1370`): compare `<br />` come testo.
- Fallback `img/404-not-found.jpg` inesistente in `gasparello/img/`; SVG `-hover` delle frecce assenti.
- Dati del cliente nel codice (claim `header.php:67`, ID GA, slug `osvaldo`/`vittorio`, `$dark-green`).
- `_hero.scss:407-545` contiene codice morto segnalato ma non rimosso.

**Peculiarità uniche**
- Shortcode `[nkcs_shortcode_card_home]` (`gasparello/inc/shortcode/nkcs-shortcode-card.php:33-79`) e `scss/components/_card-home.scss`.
- Sede con `layout="colonne"` e titolo con accento (`gasparello/inc/shortcode/nkcs-shortcode-sede.php:79-88,137-222`, `scss/components/_sede-box.scss:236-336`).
- `scss/nkcs-custom/_nkcs-wp-list.scss` (lista con spunta SVG) e `_nkcs-titoli.scss` (`.nkcs-occhiello`, `.nkcs-line`).
- Header a due fasce e footer a tre colonne con logo secondario e descrizione.

---

## 3. Euroinfissi: cosa manca e cosa ha in più

**Manca rispetto a Gasparello**
- Overlay hero da ACF; toast CF7; `:has()` per la variante form white.
- `srcset`/`sizes` e lazy sulle slide dalla 2ª.
- Convenzione shortcode `nkcs_shortcode_*` con alias deprecati.
- `overscroll-behavior` per asse, `--header-total`, serie di opacità, `full-white`.
- Sede a colonne, logo secondario/descrizione nel footer, anteprima ACF scura nell'editor.
- `nkcs-wp-list`, `.nkcs-line`, ombra opzionale nella mappa dei pulsanti.

**Manca rispetto a Geonova**
- Modalità slideshow a pagine collegate (il CSS esiste ancora in `euroinfissi/scss/layout/_hero.scss:374-429` ma è inutilizzato).
- Icona FAQ +/− in CSS puro, blur sul pulsante glass (`geonova/scss/components/_buttons.scss:450-455`).
- `.nkcs-left-line`, `_nkcs-pattern-full`, `preconnect` iubenda.
- File immagine che Euroinfissi richiama ma non ha: `img/arrows/*.svg`, `img/lavorazioni/icon-lavorazione.svg`.

**Ha in più (miglioramenti rispetto a entrambi)**
- Scroll-reveal ScrollTrigger completo, `gallery-swiper.js` e `swiper-pagine-figlie.js` evoluti, `mobile-menu.js` con `aria-label` dinamico.
- 404 da ACF con helper in cache, protezione LCP dai plugin lazy-load.
- FAQ a card con variante scura, spacer `title` coerente col CSS, campo `nkcs_seo_occhiello`.
- `[nkcs_sede_form]`, griglia pagine figlie, header a pillola con FAB chiamata, menu `paesi` nel footer, `screenshot.jpg`.

I file "solo Euroinfissi diverso" (`front-page.php`, `page.php`, `template-parts/hero/pagina.php`, `js/moduli/gallery-swiper.js`, `gsap.js`, `mobile-menu.js`, `scss/base/_animations.scss`, `scss/vendor/_yoast-faq.scss`, `acf-json/group_6884b89871c07.json`, `acf-json/group_nkcs_seo.json`) sono tutti miglioramenti. Unica riserva: il fallback dell'immagine hero preso dal gruppo "Pagina 404" (`front-page.php:30-34`, `page.php:17-21`) è semanticamente discutibile.

---

## 4. Soluzioni da portare in Euroinfissi

| # | Soluzione | Origine | Destinazione in Euroinfissi | Sforzo |
|---|---|---|---|---|
| 1 | Overlay hero configurabile da ACF (togliere i `default_value`, così "vuoto = valore del tema" funziona) | `gasparello/inc/contatti/contatti.php:268-316`, `gasparello/acf-json/group_nkcs_opzioni.json:1399-1540` | `euroinfissi/inc/contatti/contatti.php`, `acf-json/group_nkcs_opzioni.json` (già compatibile: `scss/layout/_hero.scss:52,304-308`) | Medio-basso |
| 2 | Toast CF7 accessibili | `gasparello/js/moduli/form-cf7.js:1-55`, `gasparello/scss/components/_form-cf7.scss:111-130,745-905` | gli stessi file in euroinfissi | Basso (JS), medio (SCSS) |
| 3 | Contenitore `:has()` per form white | `gasparello/scss/components/_form-cf7.scss:565-575` | `euroinfissi/scss/components/_form-cf7.scss` | Basso |
| 4 | `srcset`/`sizes` e lazy dalla 2ª slide (tenere `skip-lazy`/`eager` solo sulla 1ª) | `gasparello/inc/layout/layout.php:153-167`, `gasparello/template-parts/hero/slideshow.php:52-64`; `geonova/template-parts/hero/slideshow.php:59-60` | `euroinfissi/inc/layout/layout.php:138-150`, `euroinfissi/template-parts/hero/slideshow.php:62-71` | Basso |
| 5 | Nomi shortcode `nkcs_shortcode_<nome>` con alias deprecati | `gasparello/inc/moduli/pagine-figlie/modulo.php:69-111`, `gasparello/inc/shortcode/nkcs-shortcode-sede.php:228-229` | `euroinfissi/inc/moduli/pagine-figlie/modulo.php:66-100`, `euroinfissi/inc/shortcode/nkcs-shortcode-sede.php`, `nkcs-shortcode-sede-form.php` | Basso |
| 6 | `overscroll-behavior` per asse | `gasparello/scss/base/_general.scss:23-35` | `euroinfissi/scss/base/_general.scss:11-14` | Basso |
| 7 | `--header-total` e scroll-padding | `gasparello/scss/layout/_header.scss:35-63`, `gasparello/scss/base/_general.scss:18-21` | `euroinfissi/scss/layout/_header.scss`, `_general.scss:8` (oggi 82px fisso) | Basso |
| 8 | Serie di opacità (generarla con `@each`) e `full-white` | `gasparello/scss/abstracts/_index.scss:21-25,39-110`; `geonova/scss/abstracts/_index.scss:22-25`, `geonova/theme.json:95-99` | `euroinfissi/scss/abstracts/_index.scss`, `theme.json` | Basso |
| 9 | Sede a colonne (referenti generici con `telefoni="slug1,slug2"`, senza "Orari di Apertura" fisso) | `gasparello/inc/shortcode/nkcs-shortcode-sede.php:79-88,98-111,137-222`, `gasparello/scss/components/_sede-box.scss:236-336` | gli stessi file in euroinfissi | Medio |
| 10 | Footer: logo secondario con fallback, descrizione (dentro `nkcs_contatti()`), `esc_url(...,['tel'])`, logo "Powered by" con dimensioni | `gasparello/footer.php:41-50,90-92,140-146` | `euroinfissi/footer.php:77,110,117,190-192`, `inc/contatti/contatti.php` | Basso |
| 11 | Slug unificati e helper `nkcs_sede_principale()`/`nkcs_sede_maps_url()` (un solo formato Maps `api=1`) | `gasparello/header.php:33-55`, `gasparello/footer.php:53-56` | `euroinfissi/inc/contatti/contatti.php`; correggere `euroinfissi/footer.php:41-43` | Basso-medio |
| 12 | Anteprima scura blocchi ACF in editor (con fix `alpha($white, 35%)`) | `gasparello/scss/editor.scss:79-91` | `euroinfissi/scss/editor.scss` | Basso |
| 13 | Lista con spunta SVG e `.nkcs-line` | `gasparello/scss/nkcs-custom/_nkcs-wp-list.scss`, `_nkcs-titoli.scss:38-54`, `gasparello/img/list/*.svg` | `euroinfissi/scss/nkcs-custom/` (unire a `_nkcs-list.scss`) | Basso |
| 14 | Ombra opzionale nella mappa pulsanti | `gasparello/scss/components/_buttons.scss:142,265-270` | `euroinfissi/scss/components/_buttons.scss:249-263` | Basso |
| 15 | Dimensioni reali immagine 404 | `gasparello/404.php:24-25` | `euroinfissi/404.php:30-31` (oggi 1920×1080 fisso) | Basso |
| 16 | Asset mancanti: `img/arrows/*.svg`, `img/lavorazioni/icon-lavorazione.svg` | `geonova/img/arrows/`, `gasparello/img/arrows/`, `geonova/img/lavorazioni/` | `euroinfissi/img/` | Basso |
| 17 | Slideshow "a pagine collegate" come seconda modalità (select ACF foto/pagine) | `geonova/inc/layout/layout.php:133-172`, `geonova/template-parts/hero/slideshow.php:83-115`, `geonova/acf-json/group_nkcs_hero_slides.json` | `euroinfissi/inc/layout/layout.php`, `template-parts/hero/slideshow.php`, JSON (CSS e `hero.js` già pronti) | Medio |
| 18 | Icona FAQ +/− in CSS puro; blur pulsante glass | `geonova/scss/vendor/_yoast-faq.scss:80-92,130-134`; `geonova/scss/components/_buttons.scss:450-455` | `euroinfissi/scss/vendor/_yoast-faq.scss`, `_buttons.scss:151` | Basso |
| 19 | `preconnect` iubenda + snippet tracking corretto | `geonova/header.php:17-30` | `euroinfissi/header.php:18-23` | Basso |
| 20 | `.nkcs-left-line`, `_nkcs-pattern-full` (correggendo commento/ordine), `p { color: inherit }` | `geonova/scss/nkcs-custom/_nkcs-left-line.scss`, `_nkcs-pattern-full.scss`, `geonova/scss/base/_default.scss:354` | `euroinfissi/scss/nkcs-custom/`, `euroinfissi/scss/base/_default.scss` | Basso (opzionale) |
| 21 | Header classico come variante `NKCS_LAYOUT` | `geonova/header.php:53-75` | `euroinfissi/inc/layout/layout.php:38-40` (CSS già in `scss/layout/_menu.scss:36-311`) | Medio (opzionale) |
| 22 | Card home (meglio come blocco ACF) | `gasparello/inc/shortcode/nkcs-shortcode-card.php`, `gasparello/scss/components/_card-home.scss` | `euroinfissi/inc/blocks/` | Medio (opzionale) |

**Da NON portare** (personalizzazioni cliente): palette `theme.json`, font Barlow, titoli maiuscoli, header a due fasce e claim, referenti `osvaldo`/`vittorio`, `$dark-green`, soglia scroll header 300px, `.wp-block-buttons` a sinistra, GA con ID cablato.

---

## 5. Problemi e incoerenze in Euroinfissi (per gravità; ✔ = verificato direttamente)

1. ✔ **Articoli, ricerca e allegati escono come pagina bianca.** `euroinfissi/index.php` è 0 byte; mancano `single.php`, `singular.php`, `search.php`. `euroinfissi/archive.php` e `home.php` stampano solo header e footer (in `archive.php:5` `$title` non è mai usato). Vale anche per Geonova e Gasparello.
2. ✔ **Asset mancanti**: `euroinfissi/img/` contiene solo `arrow-right.png`, `navbar.png`, `navbar_close.png`, `poweredby.png`. Mancano `img/arrows/*` (4 url nel `css/style.css` compilato, `inc/moduli/pagine-figlie/parts/swiper-pagine-figlie.php:20`, `template-parts/hero/linguetta.php:6,17`), `img/hero.jpg` (`front-page.php:28`, `page.php:15`), `img/logo-white.png` (`header.php:41`, `footer.php:37`), `img/lavorazioni/icon-lavorazione.svg` (`list-pagine-figlie.php:15`). Da verificare se la cartella è stata svuotata solo in questa copia locale. Il mixin `arrow-icon` cerca anche `arrow-<dir>-hover.svg` (`scss/abstracts/_index.scss:122-149`), ma nei temi fratelli esistono solo le varianti `--white`.
3. ✔ **Il menu non è usabile da tastiera**: il toggle è un `div role="button" tabindex="0"` (`template-parts/menu/mobile/mobile-menu-fixed.php:57`) e `js/moduli/mobile-menu.js:28-34` ascolta solo `click` (Invio/Spazio non fanno nulla). È l'unico menu dell'header.
4. ✔ **`wp_make_link_relative()` sulle voci di menu** (`mobile-menu-fixed.php:105,128`) toglie il dominio anche dai link esterni, che si rompono.
5. ✔ **Options page con `capability: edit_posts`** (`acf-json/ui_options_page_6aa2c388e8abc.json`): Collaboratori e Autori possono modificare contatti e mittente email.
6. ✔ **Email**: l'header `From` non ha fallback (`inc/moduli/form/parts/email-helpers.php:74,196`: se `nkcs_email_from` è vuoto diventa `Nome <>`); la conferma parte su `wpcf7_before_send_mail` per qualsiasi form (`hook-email-base.php:14`, la convenzione indica `wpcf7_mail_sent`); `date_default_timezone_set('Europe/Rome')` cambia il fuso globale di PHP (`hook-email-base.php:29`, meglio `wp_date()`). Le validazioni CF7 leggono `$_POST` senza `wp_unslash` (`admin-syntax-highlight.php:33-85`).
7. ✔ **`load_textdomain('nkb', get_template_directory() . './languages')`** (`functions.php:20`): dominio sbagliato (`nkt` in `style.css:6`), path sbagliato (`…/euroinfissi./languages`), funzione sbagliata (vuole un `.mo`). Nessuna stringa usa `__()`/`_e()` e la cartella `languages/` non esiste: è codice morto.
8. ✔ **Swiper**: `wp_enqueue_script('gs-swiper-init')` (`inc/assets/assets.php:102`) non fa nulla (l'handle reale di Greenshift è `gspb-swiper-init`, `plugins/greenshift-…/init.php:278`). Il CSS è registrato con handle `gsswiper-css` e versione `9.3.3` (righe 94-99), ma Greenshift registra già `gsswiper` versione 12.1 (`init.php:306`): possibile doppio caricamento e versione dichiarata sbagliata. Dipendenza da un plugin per una libreria del tema.
9. ✔ **GTM non standard e cablato** (`header.php:18-23`): carica `gtm.js?id=GTM-MD9K22TX` con uno stub `gtag('js', …)` ma senza `dataLayer.push({'gtm.start': …, event:'gtm.js'})`, senza `<noscript>`, ID fisso, nessuna attesa del consenso. Da verificare con Tag Assistant.
10. ✔ **`h4, h5 { color: $white }` globale** in `scss/layout/_footer.scss:49-52`: titoli bianchi su sfondo bianco nei contenuti.
11. ✔ **`overscroll-behavior: none` su html/body** (`scss/base/_general.scss:11-14`): blocca il "trascina per aggiornare" su mobile.
12. **LCP/immagini**: il logo header ha `fetchpriority="high"` e compete con la hero (`header.php:79`; `width/height` 236×40 contro 64px di altezza CSS); la slideshow carica tutte le slide `eager` in dimensione `full` (`template-parts/hero/slideshow.php:60-71`, `inc/layout/layout.php:142`); la hero non ha srcset (`$hero_srcset` e `$hero_sizes` calcolati e mai usati, `page.php:32-33`); il logo del footer non ha dimensioni (`footer.php:77`).
13. **Valori del cliente nel codice**: ID pattern `278` (`template-parts/banda-contatti.php:17`), GTM, link `/contatti/` (`header.php:61`), `#626C7E` in `_nkcs-occhiello.scss:58-61`.
14. **Incoerenze di slug e duplicati**: il footer usa lo slug `principale` (`footer.php:41-43`) mentre header e shortcode usano `<sede>--tel/--cell/--email`; `nkcs_tel_href()` (`email-helpers.php:34`) e `nkcs_href_tel()` (`contatti.php:70`) danno risultati diversi (la prima non aggiunge +39); breadcrumb duplicato tra `pagina.php`, `slideshow.php`, `404.php`; lightbox PhotoSwipe configurata due volte (`gallery-grid.js:17-43`, `gallery-swiper.js:111-135`).
15. **Query/cache**: `nkcs_menu_tree()` chiamata due volte senza cache (`header.php:62`, `mobile-menu-fixed.php:71`); `get_field('nkcs_loghi','option')` ripetuto in `header.php:39` e `footer.php:35` invece di stare nell'helper; manca `update_post_thumbnail_cache()` nella query pagine figlie (`inc/moduli/pagine-figlie/modulo.php:54`).
16. **Incoerenze di configurazione**: font size di `theme.json:16-42` (15/18/24/38/50) diversi da `scss/base/_tipografia.scss:16-21` (15/16/26/32/44), quindi i valori di theme.json non valgono da nessuna parte; i blocchi gallery ignorano `$block['anchor']` e `className` (`inc/blocks/gallery-grid/gallery-grid.php:57`, `gallery-swiper.php:55`) pur dichiarando `anchor: true`; `alignWide` non è una chiave valida in `inc/blocks/spacer/block.json:10`; mancano `<noscript>` e preload coerenti col font usato.
17. **Codice morto o duplicato**
    - PHP/template: `get_permalink_by_path()` (`functions.php:10-14`), costante WPML (`functions.php:7`), `nkcs_modulo_attivo()` (`nkcs-moduli-init.php:66`); orfani `template-parts/menu/desktop/orizzontale.php`, `menu/mobile/mobile-bar.php`, `chiama-fisso.php`, `hero/linguetta.php`; cartella vuota `template-parts/footer/` con `NKCS_LAYOUT['footer']` (`inc/layout/layout.php:39`); menu `paesi` registrato; campi letti ma mai stampati (`nkcs_sede_localita`, `nkcs_firma_accent`).
    - JS: `js/moduli/mobile-bar.js` e `sede-popup.js` non importati; `chiama-fisso.js` eseguito ma senza elemento; rami `slide-content` in `hero.js:28,47-60,115-118`; chiamata `ScrollTrigger.refresh()` senza controllo (`js/main.js:29`).
    - SCSS: `components/_mobile-bar.scss` (commentato, `style.scss:58`), `layout/_menu.scss:32-311` (menu desktop), `layout/_hero.scss:374-429`, `_chiama-fisso.scss`, `.gs-fade-in` (parte invisibile e nessun JS aggiunge `.is-visible`: `_animations.scss:10-19`), `nkcs-gsap-reveal` (`footer.php:73`); `_sede-form.scss:43-88` duplica `.nkcs--form-white`; `.map` orfani.
    - ACF: `nkcs_whatsapp` e sottocampi `nkcs_wa_*` (`group_nkcs_opzioni.json:497-607`), `nkcs_logo_secondario` (riga 50); `nkcs_operiamo_a`/`nkcs_op_*` usati in `contatti.php:198-211` ma non definiti nel JSON.
18. **Commenti obsoleti o residui di temi funerari**: `assets.php:63` ("main.js che NON è un module", contraddetto da `:50-56`); `hero.js:19` (5s vs `AUTOPLAY_DELAY` 10000, riga 37); `gsap.js:7-8` (0.8s vs 1.6s in `_animations.scss:39`); "3 varianti" bottoni (sono 4) in `_buttons.scss:30,120`; "IOF Corona" (`header.php:1`, `mobile-menu.js:6`); "Onoranze Funebri Aguiari" (`email-helpers.php:4`); placeholder in `acf-json/group_nkcs_seo.json:42,177`; `.nkcs-gsap-fade-up` solo in un commento (`slideshow.php:10`); `admin-acf.css` non stila l'intestazione di `nkcs_form_contatti`.
19. **Nome tema e metadati**: `euroinfissi/style.css` ha Theme Name "Tema Custom EuroInfissi", Version 1.0; Geonova e Gasparello condividono "Tema Custom". Il tema base dovrebbe avere nome e versione propri.

**Problemi comuni ai tre temi**: punti 1, 2 (per `hero.jpg` e `logo-white.png`), 3, 6, 7, 8, 12 (hero senza srcset), 17 (`$hero_srcset`), 19.

---

## 6. Conformità alle convenzioni NKCS (Euroinfissi)

| Convenzione | Esito | Prove |
|---|---|---|
| Template hierarchy standard | **No** | `index.php` 0 byte; mancano single/search |
| CPT con `has_archive` | N/A | Nessun CPT |
| Immagini ACF come array | Parziale | Array per loghi/gallery/hero; ID in `nkcs_sede_immagine`, `nkcs_404_immagine`; URL in `nkcs_firma_logo` |
| Shortcode con `ob_start`/`ob_get_clean` | Parziale | Sì in `pagine-figlie/modulo.php:77-98`; `nkcs_sede` e `nkcs_sede_form` hanno markup inline |
| Helper unico con cache | Parziale | `nkcs_contatti()` sì (`contatti.php:108`); loghi, 404, form letti a parte |
| Italiano e commenti datati | Sì | Formato reale `NKCSggmmaa` (la convenzione dice `aammgg`) |
| `@use "../variabili"`/`varfonts as FS` | **No** | Usa `@use "../abstracts" as *` (scelta comunque migliore) |
| BEM `nkcs-`, sezioni numerate | Parziale | Classi legacy: `.header`, `.footer__*`, `.ft-*`, `.btn`, `.form__columns` |
| Hover solo desktop | Quasi | Eccezioni: `_default.scss:453,459`, `_form-cf7.scss:779,801,823`, `_swiper.scss:13`, `_footer.scss:354`, `_menu.scss:295`, `vendor/_greenshift.scss:36-148` |
| Breakpoint 600/768/1024/1200/1500 | Parziale | `wide` = 1600; molti valori ad hoc (550, 1300, 1250, 1400, 767, 1023…) |
| `$btn-variants` + mixin hover | Sì | `_buttons.scss:125-263` |
| JS vanilla `initXxx` | Sì | Tranne `sede-popup.js` (morto) |
| GSAP `matchMedia`, GSAP locale | Parziale | Locale sì (`assets.php:41-42`); `gsap.matchMedia` mai usato |
| Hero LCP con `fetchpriority`/`decoding` | Sì | Ma anche il logo ha priorità alta |
| Swiper con pallini su mobile | Parziale | Sì in hero e pagine figlie; la gallery swiper no |
| Megamenu "una query, due render" | **No** | `nkcs_menu_tree()` chiamata due volte senza cache |
| CF7: modifier, `wpcf7_mail_sent`, From dal dominio | Parziale | `.nkcs--form-white` sì; usa `before_send_mail`; From senza fallback |
| Niente framework/page builder | Parziale | Nessun Bootstrap/Tailwind; dipendenza da Greenshift |

**Convenzioni da aggiornare** (il codice è più avanti della convenzione): partial con `@use "../abstracts" as *`; formato timbro `NKCSggmmaa`; decidere se il breakpoint wide è 1500 o 1600 e uniformare `theme.json` (`wideSize` 1500) e `$bp`.

---

## 7. Piano di ottimizzazione di Euroinfissi

### SUBITO (bug, sicurezza, accessibilità; sforzo basso)
1. Aggiungere `index.php` minimo con loop, più `singular.php` e `search.php` (o `single.php`); rendere utili `archive.php` e `home.php`.
2. Ripristinare gli asset di `img/` copiando da `gasparello/img/arrows/` e `geonova/img/lavorazioni/`; allineare il mixin `arrow-icon` (`scss/abstracts/_index.scss:122-149`) al suffisso `--white` oppure creare i `-hover`; sostituire i fallback `hero.jpg`/`logo-white.png` con un campo ACF o un placeholder reale.
3. Trasformare il toggle del menu in `<button>` (o gestire Invio/Spazio e focus) in `mobile-menu-fixed.php:55-60` e `mobile-menu.js`.
4. Sostituire `wp_make_link_relative()` con `esc_url($it->url)` (`mobile-menu-fixed.php:105,128`).
5. Portare la capability della options page a `manage_options` (o capability dedicata) in `ui_options_page_6aa2c388e8abc.json`.
6. Email: fallback del From (`email-helpers.php:196`), spostare la conferma su `wpcf7_mail_sent` limitata al form di contatto, `wp_date()` al posto di `date_default_timezone_set()`.
7. Rimuovere o correggere `load_textdomain` (`functions.php:20`; se serve: `load_theme_textdomain('nkt', get_template_directory().'/languages')`).
8. Swiper: usare gli handle reali (`gsswiper`, `gspb-swiper-init`) senza ri-registrare il CSS (`assets.php:91-104`).
9. Snippet GTM ufficiale con ID da opzione ACF e `<noscript>` (`header.php:18-23`).
10. `h4, h5` del footer limitati a `.nkcs-footer` (`_footer.scss:49-52`); `overscroll-behavior` per asse (da Gasparello); `esc_url(..., ['tel'])` in `footer.php:110,117` e `mobile-menu-fixed.php:109,122,128`.

### DOPO (porting, performance, pulizia; sforzo medio)
1. Versioning con `filemtime()` e cache-busting dei moduli ES importati da `main.js` (import map o `?ver`).
2. Caricamento condizionale di PhotoSwipe (CSS + modulo inline), Swiper e, se possibile, Font Awesome (`has_block('acf/gallery-*')`, `has_shortcode`).
3. Hero con `wp_get_attachment_image` + `srcset`/`sizes`; slide dalla 2ª in lazy (da Gasparello); togliere `fetchpriority` al logo.
4. Portare da Gasparello: overlay hero ACF, toast CF7, alias shortcode `nkcs_shortcode_*`, `--header-total`, serie alpha, sede a colonne generica, footer (logo secondario e descrizione dentro `nkcs_contatti()`).
5. Unificare slug (`--tel`/`--cell`) e creare `nkcs_sede_principale()`; mettere in cache `nkcs_menu_tree()` e i loghi nell'helper; unificare `nkcs_tel_href()`/`nkcs_href_tel()`.
6. Campo ACF dedicato "immagine hero di default" al posto dell'immagine 404; ID pattern 278 e `/contatti/` spostati in opzioni.
7. Allineare `theme.json` e `_tipografia.scss` (font size); sistemare `block.json` e `anchor/className` dei blocchi gallery.
8. Pulizia del codice morto (sezione 5, punto 17) e riscrittura dei commenti storici; rimuovere i residui funerari.
9. `package.json` con script Sass: sviluppo (expanded + map) e build (compressed, senza map); rimuovere i `.map` orfani.
10. Nome tema, Version e `screenshot.jpg` (1200×900) propri del tema base.

### OPZIONALE
- Modalità slideshow "a pagine collegate" (Geonova) via select ACF; header classico come variante `NKCS_LAYOUT`.
- Utility `.nkcs-left-line`, `_nkcs-pattern-full`, `nkcs-wp-list`, `.nkcs-line`, chiave `shadow` nei pulsanti, blur glass, FAQ +/− in CSS puro, anteprima ACF scura.
- Card home come blocco ACF; Swiper locale al posto di Greenshift; `gsap.matchMedia`.
- Cloudflare Turnstile su CF7 e SMTP (skill `nkcs-turnstile-cloudflare`); `CLAUDE.md` nel tema base con le convenzioni aggiornate.

---

## 8. Appendice — file presenti in un solo tema

| Tema | File |
|---|---|
| Solo Euroinfissi | `inc/moduli/pagine-figlie/parts/grid-pagine-figlie.php`, `inc/shortcode/nkcs-shortcode-sede-form.php`, `scss/components/_sede-form.scss`, `scss/modules/shortcode/_pagine-figlie-grid.scss`, `scss/nkcs-custom/_nkcs-list.scss`, `scss/nkcs-custom/_nkcs-occhiello.scss`, `screenshot.jpg` |
| Solo Geonova | `scss/nkcs-custom/_nkcs-left-line.scss` |
| Solo Gasparello | `inc/shortcode/nkcs-shortcode-card.php`, `scss/components/_card-home.scss`, `scss/nkcs-custom/_nkcs-titoli.scss`, `scss/nkcs-custom/_nkcs-wp-list.scss` |
| Geonova + Gasparello | `scss/nkcs-custom/_nkcs-pattern-full.scss` |

**Modifiche post-fork di Gasparello (per timbro), generiche vs cliente**
- **240926**: font Barlow (cliente); serie alpha e `--header-total` (generico); header a due fasce (cliente); footer a 3 colonne (impaginazione cliente, logo secondario/descrizione generici); slideshow per ID con srcset (generico); menu desktop su header bianco (cliente).
- **250926**: convenzione `nkcs_shortcode_*` con alias (generico); card home (schema generico, contenuti cliente); sede a colonne e titolo con accento (generico); `nkcs-wp-list` e `nkcs-titoli` (generico); anteprima ACF scura (generico, con bug); pulsanti hero, titoli maiuscoli, loader a lineetta, zoom hero (cliente).
- **280926**: 404 da ACF (idea generica, ma Euroinfissi ha già la versione migliore NKCS041126); footer con iubenda/Powered by/indirizzo cliccabile (generico); toast CF7 e `:has()` form white (generico); overscroll per asse (generico); scala z-index documentata (principio generico).
- **290926**: link indirizzo header da "Sede Link" o Google Maps (generico, come helper).
- **141026**: overlay hero da ACF (generico, priorità alta); referenti `osvaldo`/`vittorio` (cliente, generalizzabile); sede-box 5/4 con variabile (generico il meccanismo).

**Modifiche recenti di Euroinfissi (novembre 2026)**: header a pillola e pannello menu a schermo intero (logica generica, misure cliente); FAB chiamata (generico, duplica `chiama-fisso` che resta nel codice); hero solo foto con occhiello e senza linguetta (generico, ha lasciato `_hero.scss:374-429` e rami di `hero.js` morti); 404 da ACF (generico); footer a 4 colonne (cliente); scroll-reveal ScrollTrigger (generico, di ottima qualità); `[nkcs_sede_form]` e griglia pagine figlie (generici); gallery swiper e frecce (generico, miglioramento netto); palette, bottoni, tipografia (cliente); spacer `title`, FAQ a card (generici).
