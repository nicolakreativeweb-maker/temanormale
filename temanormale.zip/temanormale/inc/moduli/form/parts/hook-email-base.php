<?php
/**
 * Email form generico — conferma al mittente per i form CF7.
 * L'email all'impresa resta quella nativa configurata in CF7, non
 * toccata da qui.
 * NKCS100926 — spostato da inc/moduli/form/modulo.php
 * NKCS170926 — rimossa l'esclusione dei form con "necrologio_id": l'hook
 * dedicato ai necrologi non esiste più, questo gestisce tutti i form.
 * NKCS220926 — nome del mittente in grassetto nel saluto ("Gentile <b>Nome</b>,").
 */

if (!defined('ABSPATH')) exit;

add_action('wpcf7_before_send_mail', function ($contact_form) {

    $submission = WPCF7_Submission::get_instance();
    if (!$submission) {
        return;
    }
    $data = $submission->get_posted_data();

    $nome  = sanitize_text_field($data['your-name'] ?? '');
    $email = sanitize_email($data['your-email']     ?? '');

    if (!is_email($email)) {
        return;
    }

    date_default_timezone_set('Europe/Rome');
    $data_ora = date('d/m/Y H:i');

    $a    = nkcs_azienda();
    $body = nkcs_email_wrap('
        <p style="margin:0 0 14px 0;">Gentile <strong>' . esc_html($nome) . '</strong>,</p>
        <p style="margin:0 0 14px 0;">Abbiamo ricevuto il tuo messaggio tramite il form di contatti e ti risponderemo al più presto.</p>
        <p style="margin:0 0 14px 0;">Grazie per averci scritto.</p>
        <p style="font-size:12px; color:#888888; margin:0;">Messaggio inviato il ' . $data_ora . '</p>
    ');

    wp_mail($email, 'Conferma ricezione messaggio', $body, nkcs_email_headers($a['noreply']));
});
