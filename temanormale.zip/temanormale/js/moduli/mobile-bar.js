// Barra mobile fissa — NKCS100926 — estratto da main.js (era initMobileButtons() dentro l'IIFE NKCS)
// NKCS170926 — aggiunto scroll-to-top (voce "torna su" della pillola tablet).

// === BANDA MOBILE FISSA — si nasconde a 300px dalla fine pagina ===
export function initMobileButtons() {
    const bar = document.querySelector('.nkcs-mobile-bar');
    if (!bar) return;

    const OFFSET = 300; // px dalla fine pagina entro cui nascondere la barra

    const update = () => {
        const scrollBottom = window.scrollY + window.innerHeight;
        const docHeight = document.documentElement.scrollHeight;
        const nearEnd = (docHeight - scrollBottom) < OFFSET;
        bar.classList.toggle('is-hidden', nearEnd);
    };

    update();
    window.addEventListener('scroll', update, { passive: true });
    window.addEventListener('resize', update, { passive: true });

    const topBtn = document.getElementById('nkcs-scroll-top');
    if (topBtn) {
        topBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }
}
