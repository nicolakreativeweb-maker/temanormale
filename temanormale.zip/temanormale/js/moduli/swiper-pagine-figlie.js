// Swiper pagine figlie — shortcode shortcode_swiper_pagine_figlie — NKCS220926
// Markup: inc/moduli/pagine-figlie/parts/swiper-pagine-figlie.php
// Swiper è globale, caricato a parte (Greenshift): non importato qui.
// Stesso pattern di gallery-swiper.js: più istanze per pagina, loop solo se le
// slide bastano. Desktop 3 card piene, sotto una card e un pezzo della successiva.
// NKCS220926 — il .swiper è dentro il wrapper .nkcs-swiper-pagine-figlie, che
// contiene anche le frecce (fuori dall'overflow hidden di Swiper).
// NKCS220926 — sotto i 1024px card attiva al centro (centeredSlides), con un
// pezzo della precedente e della successiva ai lati; desktop invariato.

const MAX_PER_VIEW = 3;

export function initSwiperPagineFiglie() {
    const wrappers = document.querySelectorAll('.nkcs-swiper-pagine-figlie');
    if (!wrappers.length) return;

    if (!window.Swiper) {
        console.warn('[NKCS] Swiper non disponibile');
        return;
    }

    wrappers.forEach(wrapper => {
        const el = wrapper.querySelector('.nkcs-swiper-pagine-figlie__slider');
        if (!el) return;

        const slidesCount = el.querySelectorAll('.swiper-slide:not(.swiper-slide-duplicate)').length;

        const nav = wrapper.querySelector('.nkcs-swiper-pagine-figlie__nav');

        // NKCS111126 — frecce nascoste se non c'è niente da scorrere: servono più card
        // di quelle mostrate insieme (slidesPerView del breakpoint attivo)
        const syncArrows = (swiper) => {
            const perView = Number(swiper.params.slidesPerView) || 1;
            nav && nav.classList.toggle('is-hidden', slidesCount <= perView);
        };

        new window.Swiper(el, {
            slidesPerView: 1.1,
            spaceBetween: 20,
            centeredSlides: true,
            loop: slidesCount > MAX_PER_VIEW,
            speed: 600,
            grabCursor: true,
            navigation: {
                prevEl: wrapper.querySelector('.nkcs-swiper-pagine-figlie__arrow--prev'),
                nextEl: wrapper.querySelector('.nkcs-swiper-pagine-figlie__arrow--next'),
            },
            pagination: {
                el: el.querySelector('.swiper-pagination'),
                clickable: true,
            },
            on: {
                // this = istanza Swiper (init scatta prima che esista la variabile)
                init() { syncArrows(this); },
                breakpoint() { syncArrows(this); },
                resize() { syncArrows(this); },
            },
            breakpoints: {
                0: { slidesPerView: 1.1, spaceBetween: 20, centeredSlides: true },
                601: { slidesPerView: 1.5, spaceBetween: 20, centeredSlides: true },
                769: { slidesPerView: 2.2, spaceBetween: 30, centeredSlides: true },
                1025: { slidesPerView: MAX_PER_VIEW, spaceBetween: 30, centeredSlides: false },
            },
        });
    });
}
