<?php

/**
 * Hero — variante slideshow — NKCS100926
 * Interattività (frecce, autoplay, pausa) in js/moduli/hero.js → initHeroSlideshow().
 * NKCS110926 — pulsanti dal repeater nkcs_seo_pulsanti (nkcs_hero_pulsanti()),
 *              tolto il pulsante fisso "I Nostri Servizi Funebri"
 * NKCS210926 — riallineata a pagina.php: stessa section con la 'class' del
 *              chiamante (home → --home, interne → standard), stessi breadcrumbs,
 *              stesso content. Via --full, nkcs-gsap-fade-up e i dots.
 *              Hook nkcs-hero-page--slideshow (per il JS), N immagini di sfondo,
 *              frecce prev/next. Con meno di 2 slide delega a pagina.php.
 * NKCS210926 — ogni slide è una PAGINA collegata (nkcs_hero_slides()): titolo,
 *              riassunto e pulsante "Scopri di più" cambiano con l'immagine, con
 *              fade-up in sequenza (titolo → testo → pulsante, in _hero.scss).
 *              L'H1 della pagina corrente resta nell'HTML ma visibile solo agli
 *              screen reader; i titoli delle slide sono H2 con lo stesso stile.
 *              I breadcrumbs (pagine interne) restano fissi.
 * NKCS210926 — linguetta bianca "scorri giù" in fondo (template-parts/hero/linguetta.php).
 * NKCS210926 — occhiello sopra il titolo di ogni slide: titolo della pagina madre
 *              della pagina collegata (es. "Pali di Fondazione").
 * NKCS210926 — pulsante "Scopri di più" in variante glass (btn--glass);
 *              frecce con icone chevron-left / chevron-right.
 * NKCS220926 — pallini (uno per slide) sopra la linguetta: stampati sempre, ma
 *              visibili solo nella home sotto i 600px, dove le frecce sono
 *              nascoste (vedi _hero.scss). Sincronizzati da hero.js.
 *
 * NKCS031126 — la slideshow cambia SOLO le foto: titolo (H1), descrizione e pulsanti
 *              sono quelli della pagina corrente, fissi, come in pagina.php. Le slide
 *              forniscono solo image/alt; titolo, riassunto, link e occhiello delle
 *              pagine collegate non vengono più stampati.
 *
 * $args attesi: gli stessi di pagina.php, più
 *   'slides'  array  [ ['image','alt','title','excerpt','link','eyebrow'], ... ] da nkcs_hero_slides()
 */

if (!defined('ABSPATH')) exit;

$nkcs_slides = $args['slides'] ?? [];

// NKCS210926 — meno di 2 slide: hero di sempre, HTML identico
if (count($nkcs_slides) < 2) {
    get_template_part('template-parts/hero/pagina', null, $args);
    return;
}

$nkcs_width       = $args['width'] ?? 1920;
$nkcs_height      = $args['height'] ?? 1080;
$nkcs_title       = $args['title'] ?? '';
$nkcs_breadcrumbs = $args['breadcrumbs'] ?? [];
$nkcs_class       = $args['class'] ?? '';
$nkcs_description = $args['description'] ?? false; // NKCS031126
$nkcs_buttons     = $args['buttons'] ?? [];       // NKCS031126
// NKCS131126 — occhiello tolto dalla hero
?>

<section class="nkcs-hero-page<?= $nkcs_class ? ' ' . esc_attr($nkcs_class) : '' ?> nkcs-hero-page--slideshow">

    <div class="nkcs-hero-page__bg">
        <?php foreach ($nkcs_slides as $i => $slide) : ?>
            <img
                class="nkcs-hero-page__bg-image skip-lazy no-lazy<?= $i === 0 ? ' is-active' : '' ?>"
                data-no-lazy="1"
                loading="eager"
                src="<?= esc_url($slide['image']) ?>"
                alt="<?= $i === 0 ? esc_attr($slide['alt']) : '' ?>"
                width="<?= esc_attr($nkcs_width) ?>"
                height="<?= esc_attr($nkcs_height) ?>"
                <?= $i === 0 ? 'fetchpriority="high"' : '' ?>
                <?= $i === 0 ? 'decoding="sync"' : 'decoding="async"' ?>>
        <?php endforeach; ?>
    </div>

    <div class="nkcs-hero-page__overlay"></div>

    <div class="nkcs-hero-page__content">

        <div class="nkcs-hero-page__content__title-wrapper">

            <nav class="nkcs-breadcrumbs" aria-label="Breadcrumb">
                <?php foreach ($nkcs_breadcrumbs as $i => $crumb) : ?>
                    <?php if ($crumb['url']) : ?>
                        <a href="<?= esc_url($crumb['url']) ?>" class="nkcs-breadcrumbs__link"><?= esc_html($crumb['label']) ?></a>
                    <?php else : ?>
                        <span class="nkcs-breadcrumbs__current" aria-current="page"><?= esc_html($crumb['label']) ?></span>
                    <?php endif; ?>
                    <?php if ($i < count($nkcs_breadcrumbs) - 1) : ?>
                        <span class="nkcs-breadcrumbs__sep" aria-hidden="true"></span>
                    <?php endif; ?>
                <?php endforeach; ?>
            </nav>

            <h1 class="nkcs-hero-page__title has-xlarge-font-size">
                <?= wp_kses($nkcs_title, ['br' => []]) ?>
            </h1>

            <?php if ($nkcs_description) : ?>
                <div class="nkcs-hero-page__sub">
                    <?= wp_kses_post($nkcs_description) ?>
                </div>
            <?php endif; ?>

            <?php nkcs_hero_pulsanti($nkcs_buttons); ?>

            <!-- Paginazione a trattini, sotto il testo — NKCS031126 -->
            <div class="nkcs-hero-slides__dots">
                <?php foreach ($nkcs_slides as $i => $slide) : ?>
                    <button
                        class="nkcs-hero-slides__dot<?= $i === 0 ? ' is-active' : '' ?>"
                        type="button"
                        aria-label="Vai alla slide <?= $i + 1 ?>"
                        <?= $i === 0 ? 'aria-current="true"' : '' ?>></button>
                <?php endforeach; ?>
            </div>
        </div>

    </div>

    <!-- Frecce laterali PREV / NEXT — NKCS210926 -->
    <button class="nkcs-hero-slides__btn nkcs-hero-slides__btn--prev" type="button" aria-label="Slide precedente">
        <i class="fa-solid fa-chevron-left" aria-hidden="true"></i>
    </button>
    <button class="nkcs-hero-slides__btn nkcs-hero-slides__btn--next" type="button" aria-label="Slide successiva">
        <i class="fa-solid fa-chevron-right" aria-hidden="true"></i>
    </button>

    <?php /* NKCS031126 — linguetta "scorri giù" rimossa dalle hero */ ?>

</section>
