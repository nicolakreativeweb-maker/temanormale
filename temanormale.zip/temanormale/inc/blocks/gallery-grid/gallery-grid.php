<?php
// ============================================================
// BLOCCO ACF: Gallery Grid + PhotoSwipe — NKCS240726
// Blocco aggiuntivo rispetto a acf/gallery-swiper: qui niente
// Swiper, le immagini vanno tutte a griglia (celle 1:1) e il
// click apre lo stesso PhotoSwipe.
//
// Campi ACF sul blocco (acf/gallery-grid), gruppo
// "group_nkcs_gallery_grid":
//   - "nkcs_gallery_images"       (Gallery)
//   - "nkcs_gallery_col_desktop"  (Select 1-6) — ≥1024px, default 4
//   - "nkcs_gallery_col_tablet"   (Select 1-6) — 769-1024px, default 3
//   - "nkcs_gallery_col_tablet_sm"(Select 1-6) — 768px, default 2
//   - "nkcs_gallery_col_mobile"   (Select 1-4) — ≤600px, default 1
// I 4 valori pilotano altrettante custom property --nkcs-grid-cols-*
// via inline style, lette nei breakpoint SCSS (scss/components/_gallery.scss).
// ============================================================

$gallery     = get_field('nkcs_gallery_images');
$col_desktop = get_field('nkcs_gallery_col_desktop');
$col_tablet  = get_field('nkcs_gallery_col_tablet');
$col_tablet_sm = get_field('nkcs_gallery_col_tablet_sm');
$col_mobile  = get_field('nkcs_gallery_col_mobile');

if (empty($gallery) || !is_array($gallery)) {
    if (!empty($is_preview)) {
        echo '<p style="padding:20px;text-align:center;opacity:.6;">Seleziona le immagini nel campo Gallery per vedere l\'anteprima.</p>';
    }
    return;
}

if ($is_preview) {
    printf(
        '<div style="padding:20px;text-align:center;opacity:.6;">Gallery Grid — %d immagini selezionate</div>',
        count($gallery)
    );
    return;
}

$align_class = !empty($block['align']) ? 'align' . $block['align'] : '';
$grid_uid    = 'nkcs-gallery-grid-' . $block['id'];

$cols_desktop   = (!empty($col_desktop) && (int) $col_desktop > 0) ? (int) $col_desktop : 4;
$cols_tablet    = (!empty($col_tablet) && (int) $col_tablet > 0) ? (int) $col_tablet : 3;
$cols_tablet_sm = (!empty($col_tablet_sm) && (int) $col_tablet_sm > 0) ? (int) $col_tablet_sm : 2;
$cols_mobile    = (!empty($col_mobile) && (int) $col_mobile > 0) ? (int) $col_mobile : 1;

$grid_style = sprintf(
    '--nkcs-grid-cols-desktop: %d; --nkcs-grid-cols-tablet: %d; --nkcs-grid-cols-tablet-sm: %d; --nkcs-grid-cols-mobile: %d;',
    $cols_desktop,
    $cols_tablet,
    $cols_tablet_sm,
    $cols_mobile
);
?>

<div class="<?= esc_attr($align_class) ?>">
    <section class="nkcs-gallery-grid"
        id="<?= esc_attr($grid_uid) ?>"
        style="<?= esc_attr($grid_style) ?>">

        <?php foreach ($gallery as $img) :
            $full  = wp_get_attachment_image_src($img['ID'], 'full');
            $large = wp_get_attachment_image_src($img['ID'], 'large');
            if (!$full || !$large) continue;
        ?>
            <a class="nkcs-gallery-grid__item"
                href="<?= esc_url($full[0]) ?>"
                data-pswp-width="<?= esc_attr($full[1]) ?>"
                data-pswp-height="<?= esc_attr($full[2]) ?>"
                target="_blank">
                <img class="nkcs-gallery-grid__image"
                    src="<?= esc_url($large[0]) ?>"
                    alt="<?= esc_attr($img['alt'] ?: get_the_title()) ?>"
                    loading="lazy"
                    decoding="async">
                <span class="nkcs-gallery-grid__zoom" aria-hidden="true">
                    <i class="fa-solid fa-circle-plus"></i>
                </span>
            </a>
        <?php endforeach; ?>

    </section>
</div>