<?php

/**
 * Helper menu — inc/layout/menu.php — NKCS100926
 * nkcs_menu_tree(): albero a 2 livelli del menu 'primary', usato dal
 * mobile-menu. Logica spostata da header.php (era inline).
 */

if (!defined('ABSPATH')) exit;

/**
 * Restituisce l'albero a 2 livelli del menu 'primary'.
 * Ogni nodo di primo livello ha 'item' (WP_Post del menu item) e
 * 'children' (array di WP_Post, i figli diretti).
 *
 * @return array<int, array{item: object, children: object[]}>
 */
function nkcs_menu_tree(): array
{
    $locations = get_nav_menu_locations();
    $items     = !empty($locations['primary'])
        ? (wp_get_nav_menu_items($locations['primary']) ?: [])
        : [];

    $tree = [];
    foreach ($items as $it) {
        if ((int) $it->menu_item_parent === 0) {
            $tree[$it->ID] = ['item' => $it, 'children' => []];
        }
    }
    foreach ($items as $it) {
        $parent = (int) $it->menu_item_parent;
        if ($parent !== 0 && isset($tree[$parent])) {
            $tree[$parent]['children'][] = $it;
        }
    }

    return $tree;
}
