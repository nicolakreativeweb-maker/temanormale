<?php

/**
 * SHORTCODE — Box "Sede" — NKCS170926
 * ------------------------------------------------------------
 * Non fa parte di un modulo (inc/moduli/): la sede è un dato
 * trasversale, letto dalla stessa fonte del footer/banda-contatti
 * (vedi inc/contatti/contatti.php → nkcs_contatti()).
 *
 * NKCS220926 — riscritto sul nuovo layout (testi bianchi su sfondo scuro,
 * icone in cerchio chiaro, riquadro orari, mappa sotto) e sulla nuova
 * convenzione di slug a doppio trattino della Options Page
 * "Contatti Globali":
 * NKCS131126 — niente più suffissi "--tel" / "--cell" / "--email": in ogni
 * repeater si usa lo STESSO slug della sede.
 *   - Sede   → repeater Sedi,     riga con nkcs_sede_slug  = slug
 *                                 (senza slug: la PRIMA sede = sede principale)
 *   - Tel    → repeater Telefoni, TUTTE le righe con nkcs_tel_slug   = slug
 *              (numero che inizia per 3 → icona cellulare e "Cell:", altrimenti "Tel:")
 *   - Email  → repeater Email,    TUTTE le righe con nkcs_email_slug = slug
 *   - Orari  → repeater nkcs_sede_orari della sede (label + orario)
 * Esempio per la sede "sede-principale": slug "sede-principale" anche sulle
 * righe di Telefoni ed Email. Se non ce ne sono semplicemente non compaiono
 * nel box (nessun errore).
 *
 * Uso:
 *   [nkcs_sede]                          → sede principale (prima riga di Sedi)
 *   [nkcs_sede slug="sede-principale"]   → sede precisa
 *
 * Attributi:
 *   slug    string  Slug della sede. Opzionale: vuoto = prima sede.
 *   mappa   bool    "0" per nascondere il riquadro mappa. Default: mostrato.
 *   titolo  bool    "1" per stampare il nome della sede come titolo sopra
 *                   la lista. Default: nascosto (come nel layout).
 *
 * Mappa: immagine statica (campo ACF "Sede Immagine", nkcs_sede_immagine)
 * con overlay hover "Vai alla mappa". Il link punta a nkcs_sede_link se
 * compilato in ACF, altrimenti a una ricerca Google Maps generata
 * dall'indirizzo (nessuna API key richiesta). Senza immagine il riquadro
 * mappa non viene stampato.
 *
 * NKCS131126 — orari dal repeater (non più wysiwyg): ogni riga stampa
 * <div class="open-hours-item"><strong>Label</strong> orario</div>, già
 * stilizzato in _sede-box.scss (label in grassetto sopra l'orario).
 *
 * Stili: scss/components/_sede-box.scss
 *
 * @package NKCS
 */

if (! defined('ABSPATH')) {
    exit;
}

/**
 * Renderizza il box "Sede" per lo shortcode [nkcs_sede].
 *
 * @param array $atts Attributi dello shortcode.
 * @return string HTML del box, o stringa vuota se non c'è nessuna sede.
 */
function nkcs_shortcode_sede($atts): string
{
    $atts = shortcode_atts([
        'slug'   => '',
        'mappa'  => '1',
        'titolo' => '0',
    ], $atts, 'nkcs_sede');

    $sede = nkcs_contatto('sedi', trim($atts['slug']));
    if (!$sede) return '';

    // NKCS131126 — righe collegate: stesso slug della sede in Telefoni ed Email
    $telefoni = nkcs_contatti_per_slug('telefoni', $sede['slug']);
    $email    = nkcs_contatti_per_slug('email', $sede['slug']);

    $indirizzo_piano = wp_strip_all_tags($sede['indirizzo']);

    // Link mappa: priorità al campo ACF Sede Link, fallback su ricerca
    // Google Maps generata dall'indirizzo.
    $maps_url = $sede['link']['url'] ?? '';
    if ($maps_url === '' && $indirizzo_piano !== '') {
        $maps_url = 'https://www.google.com/maps?q=' . rawurlencode($indirizzo_piano);
    }

    ob_start();
?>
    <div class="nkcs-sede-box">

        <?php if ($atts['titolo'] === '1') : ?>
            <h2 class="nkcs-sede-box__title"><?= nkcs_esc_br($sede['nome']) ?></h2>
        <?php endif; ?>

        <ul class="nkcs-sede-box__list">

            <?php if ($sede['indirizzo']) : ?>
                <li class="nkcs-sede-box__item">
                    <span class="nkcs-sede-box__icon"><i class="fa-solid fa-location-dot" aria-hidden="true"></i></span>
                    <?php if ($maps_url) : ?>
                        <a class="nkcs-sede-box__text nkcs-sede-box__text--no-underline" href="<?= esc_url($maps_url) ?>" target="_blank" rel="noopener"><?= nkcs_esc_br($sede['indirizzo']) ?></a>
                    <?php else : ?>
                        <span class="nkcs-sede-box__text"><?= nkcs_esc_br($sede['indirizzo']) ?></span>
                    <?php endif; ?>
                </li>
            <?php endif; ?>

            <?php foreach ($telefoni as $tel) :
                // Cellulare italiano: le cifre (senza prefisso +39 / 0039) iniziano per 3
                $cifre   = preg_replace('/^(?:\+|00)39/', '', preg_replace('/[^0-9+]/', '', $tel['numero']));
                $is_cell = ($cifre[0] ?? '') === '3';
            ?>
                <li class="nkcs-sede-box__item">
                    <span class="nkcs-sede-box__icon"><i class="fa-solid <?= $is_cell ? 'fa-mobile-screen-button' : 'fa-phone' ?>" aria-hidden="true"></i></span>
                    <a class="nkcs-sede-box__text" href="<?= esc_url($tel['href']) ?>"><?= $is_cell ? 'Cell' : 'Tel' ?>: <?= esc_html($tel['numero']) ?></a>
                </li>
            <?php endforeach; ?>

            <?php foreach ($email as $mail) : ?>
                <li class="nkcs-sede-box__item">
                    <span class="nkcs-sede-box__icon"><i class="fa-solid fa-envelope" aria-hidden="true"></i></span>
                    <a class="nkcs-sede-box__text" href="<?= esc_url($mail['href']) ?>">Email: <?= esc_html($mail['indirizzo']) ?></a>
                </li>
            <?php endforeach; ?>

        </ul>

        <?php if ($sede['orari']) : ?>
            <div class="nkcs-sede-box__orari">
                <?php foreach ($sede['orari'] as $orario) : ?>
                    <div class="open-hours-item">
                        <?php if ($orario['label'] !== '') : ?><strong><?= esc_html($orario['label']) ?></strong><?php endif; ?>
                        <?= esc_html($orario['orario']) ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if ($atts['mappa'] !== '0' && $sede['immagine_id'] && $maps_url) : ?>
            <a class="nkcs-sede-box__map nkcs-hover-maps" href="<?= esc_url($maps_url) ?>" target="_blank" rel="noopener">
                <?= wp_get_attachment_image($sede['immagine_id'], 'medium_large', false, [
                    'class' => 'nkcs-sede-box__map-img',
                    'alt'   => esc_attr(wp_strip_all_tags($sede['nome'])),
                ]) ?>
            </a>
        <?php endif; ?>

    </div>
<?php
    return ob_get_clean();
}
add_shortcode('nkcs_sede', 'nkcs_shortcode_sede');
