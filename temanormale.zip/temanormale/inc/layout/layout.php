<?php

/**
 * ============================================================
 * CONFIGURAZIONE LAYOUT NKCS — inc/layout/layout.php — NKCS100926
 * ------------------------------------------------------------
 * Sceglie quale variante caricare per le parti di pagina sempre
 * presenti (menu, hero, footer), che vivono in template-parts/.
 * A differenza di inc/moduli/ (funzionalità spegnibili on/off),
 * qui non si spegne nulla: si sceglie tra N varianti dello stesso
 * pezzo di pagina.
 * NKCS110926 — aggiunto nkcs_hero_pulsanti() (repeater nkcs_seo_pulsanti)
 * NKCS210926 — aggiunto nkcs_hero_slides() (gruppo ACF group_nkcs_hero_slides):
 *              hero_home e hero_pagina passano per la variante 'slideshow', che
 *              con meno di 2 slide valide delega a 'pagina' (hero di sempre).
 *              NKCS031126 — ora le slide sono solo foto: galleria ACF nkcs_hero_immagini.
 * ============================================================
 */

if (!defined('ABSPATH')) exit;

/**
 * Variante attiva per ciascuna area di layout.
 * Chiave  => area (nome cartella dentro template-parts/<gruppo>/)
 * Valore  => nome del file variante (senza .php)
 * NKCS100926 — variante menu_mobile rinominata 'megamenu-fixed' → 'mobile-menu-fixed'.
 * NKCS150926 — hero_home passata da 'slideshow' a 'pagina': un'unica immagine
 * fissa, come le altre hero. 'slideshow' resta disponibile come variante.
 * NKCS210926 — hero_home e hero_pagina → 'slideshow'. È uno SWITCH, non una
 * grafica diversa: slideshow.php usa lo stesso markup di pagina.php e, se la
 * pagina non ha almeno 2 foto nella galleria nkcs_hero_immagini, carica direttamente pagina.php con gli stessi $args
 * (HTML identico).
 * NKCS131126 — menu sopra i 1024px a scelta (sotto i 1024px c'è SEMPRE il
 * menu mobile, 'menu_mobile'):
 *   'megamenu'    → hamburger + pannello a tutto schermo anche su desktop (il menu di sempre)
 *   'orizzontale' → voci in riga nell'header con tendine in hover (come Geonova);
 *                   hamburger e pannello solo sotto i 1024px
 * La variante finisce anche come classe sul <body> (nkcs-menu--megamenu /
 * nkcs-menu--orizzontale), usata da layout/_menu.scss.
 * NKCS131126 — 'menu_desktop' si sceglie da admin: Contatti Globali → Menu →
 * "Menu sopra i 1024px" (vedi NKCS_LAYOUT_ACF). Il valore qui sotto vale
 * solo se il campo è vuoto o non valido.
 */
const NKCS_LAYOUT = [
    'menu_desktop' => 'megamenu', // 'megamenu' | 'orizzontale' — riserva del campo ACF
    'menu_mobile'  => 'mobile-menu-fixed',
    'hero_home'    => 'slideshow',
    'hero_pagina'  => 'pagina', // NKCS041126 — slideshow solo in homepage; pagine interne: hero a immagine singola
    'footer'       => 'quattro-colonne',
];

/**
 * Mappa area di layout → cartella base in template-parts/.
 * Serve perché più aree condividono lo stesso gruppo (menu_desktop e
 * menu_mobile vivono entrambi sotto template-parts/menu/, ma in
 * sottocartelle diverse).
 */
const NKCS_LAYOUT_GRUPPI = [
    'menu_desktop' => 'menu/desktop',
    'menu_mobile'  => 'menu/mobile',
    'hero_home'    => 'hero',
    'hero_pagina'  => 'hero',
    'footer'       => 'footer',
];

/**
 * Aree di layout sceglibili da admin — NKCS131126
 * Area => [gruppo ACF, sottocampo] nella options page "Contatti Globali"
 * (acf-json/group_nkcs_opzioni.json). Per aggiungerne una: nuovo sottocampo
 * con valori = nomi dei file variante, poi una riga qui.
 */
const NKCS_LAYOUT_ACF = [
    'menu_desktop' => ['nkcs_menu', 'nkcs_menu_desktop'],
];

/**
 * Variante attiva di un'area di layout — NKCS131126
 * Prima il campo ACF (se l'area è in NKCS_LAYOUT_ACF), poi NKCS_LAYOUT.
 * Il valore ACF vale solo se è un nome pulito e il file della variante
 * esiste in template-parts/<gruppo>/: altrimenti si torna a NKCS_LAYOUT.
 * Risultato in cache per la richiesta (header e body_class lo chiedono entrambi).
 *
 * @param string $area Chiave presente in NKCS_LAYOUT.
 * @return string Nome del file variante (senza .php), '' se l'area non esiste.
 */
function nkcs_layout_variante(string $area): string
{
    static $cache = [];
    if (isset($cache[$area])) return $cache[$area];

    $variante = NKCS_LAYOUT[$area] ?? '';

    if (isset(NKCS_LAYOUT_ACF[$area], NKCS_LAYOUT_GRUPPI[$area]) && function_exists('get_field')) {
        [$gruppo_acf, $campo] = NKCS_LAYOUT_ACF[$area];
        $valori = get_field($gruppo_acf, 'option');
        $scelta = is_array($valori) && is_string($valori[$campo] ?? null) ? $valori[$campo] : '';

        if (
            $scelta !== ''
            && preg_match('/^[a-z0-9-]+$/', $scelta)
            && is_file(get_theme_file_path('template-parts/' . NKCS_LAYOUT_GRUPPI[$area] . '/' . $scelta . '.php'))
        ) {
            $variante = $scelta;
        }
    }

    return $cache[$area] = $variante;
}

/**
 * Carica la variante attiva di un'area di layout.
 * Wrapper su get_template_part(), coerente con nkcs_modulo_attivo()
 * in inc/moduli/nkcs-moduli-init.php.
 * NKCS131126 — la variante arriva da nkcs_layout_variante() (campo ACF o NKCS_LAYOUT).
 *
 * @param string $area Chiave presente in NKCS_LAYOUT.
 * @param array  $args Dati passati al template part (get_template_part li inoltra a $args).
 * @return void
 */
function nkcs_layout_part(string $area, array $args = []): void
{
    if (!isset(NKCS_LAYOUT[$area], NKCS_LAYOUT_GRUPPI[$area])) {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[NKCS] Area di layout non configurata: ' . $area);
        }
        return;
    }

    $variante = nkcs_layout_variante($area);
    $gruppo   = NKCS_LAYOUT_GRUPPI[$area];

    get_template_part("template-parts/{$gruppo}/{$variante}", null, $args);
}

/**
 * Classe sul <body> con la variante del menu desktop — NKCS131126
 * nkcs-menu--megamenu | nkcs-menu--orizzontale: serve al CSS per sapere,
 * sopra i 1024px, se mostrare l'hamburger + pannello o la nav in riga.
 */
add_filter('body_class', function (array $classes): array {
    $classes[] = 'nkcs-menu--' . sanitize_html_class(nkcs_layout_variante('menu_desktop'));
    return $classes;
});

/**
 * Posizione dell'header rispetto alla hero — NKCS131126
 *   'sovrapposto' → header trasparente sopra l'immagine, bianco da scrollato (come prima)
 *   'staccato'    → header sempre bianco e hero che parte sotto di lui
 * Valore di riserva se il campo ACF (Contatti Globali → Menu e header → Header) è vuoto.
 * Sotto i 1024px l'header è sempre bianco con la hero sotto, in entrambi i casi.
 */
const NKCS_HEADER_POSIZIONE = 'sovrapposto';

/**
 * Posizione dell'header scelta in admin, oppure NKCS_HEADER_POSIZIONE.
 * Finisce come classe sull'header: nkcs-header--sovrapposto | nkcs-header--staccato
 * (layout/_header.scss, layout/_menu.scss, layout/_hero.scss).
 *
 * @return string 'sovrapposto' | 'staccato'
 */
function nkcs_header_posizione(): string
{
    static $posizione = null;
    if ($posizione !== null) return $posizione;

    $posizione = NKCS_HEADER_POSIZIONE;

    if (function_exists('get_field')) {
        $valori = get_field('nkcs_menu', 'option');
        $scelta = is_array($valori) ? ($valori['nkcs_header_posizione'] ?? '') : '';
        if (in_array($scelta, ['sovrapposto', 'staccato'], true)) {
            $posizione = $scelta;
        }
    }

    return $posizione;
}

/**
 * Stampa i pulsanti call-to-action dell'hero dal repeater ACF "nkcs_seo_pulsanti"
 * (gruppo group_nkcs_seo). Usato da template-parts/hero/pagina.php.
 *
 * Etichetta: nkcs_seo_btn_etichetta, altrimenti il titolo del link.
 * Le righe senza url o senza testo vengono saltate; senza righe valide non stampa nulla.
 *
 * @param mixed $righe Valore del repeater (array di righe, oppure false/null se vuoto).
 * @return void
 */
function nkcs_hero_pulsanti($righe): void
{
    $pulsanti = [];

    foreach ((array) $righe as $riga) {
        $link      = $riga['nkcs_seo_btn_link'] ?? null;          // ACF link (return array)
        $url       = $link['url'] ?? '';
        $etichetta = ($riga['nkcs_seo_btn_etichetta'] ?? '') ?: ($link['title'] ?? '');

        if ($url === '' || $etichetta === '') continue;

        $target = $link['target'] ?? '';
        $attr   = $target ? ' target="' . esc_attr($target) . '" rel="noopener"' : '';

        $pulsanti[] = '<a class="btn nkcs-btn--arrow-long" href="' . esc_url($url) . '"' . $attr . '>'
            . esc_html($etichetta) . '</a>';
    }

    if (!$pulsanti) return;

    echo '<div class="flex__center mt--10 gap--10">' . implode('', $pulsanti) . '</div>';
}

/**
 * Slide della hero slideshow dal gruppo ACF "group_nkcs_hero_slides" — NKCS210926
 * NKCS031126 — ora è una semplice galleria (campo nkcs_hero_immagini, return "array"):
 * si caricano le foto nella pagina e cambiano solo quelle. Niente più flag né
 * pagine collegate; titolo, descrizione e pulsanti restano quelli della pagina.
 * Usato da front-page.php e page.php, che passano il risultato in $args['slides'].
 *
 * Ogni slide:
 *   image → URL dell'immagine (full)
 *   alt   → alt della foto, fallback titolo della pagina
 *
 * Senza ACF o con campo vuoto restituisce []; con meno di 2 foto la hero
 * resta quella statica (slideshow.php delega a pagina.php).
 *
 * @param int $post_id ID della pagina che mostra la hero.
 * @return array<int, array{image: string, alt: string}>
 */
function nkcs_hero_slides(int $post_id): array
{
    if (!function_exists('get_field')) {
        return [];
    }

    $slides = [];

    foreach ((array) get_field('nkcs_hero_immagini', $post_id) as $img) {
        if (empty($img['url'])) continue;

        $slides[] = [
            'image' => $img['url'],
            'alt'   => trim((string) ($img['alt'] ?? '')) !== '' ? $img['alt'] : get_the_title($post_id),
        ];
    }

    return $slides;
}
