<?php

/**
 * ============================================================
 * REGISTRO MODULI NKCS — NKCS040926
 * ------------------------------------------------------------
 * Carica i moduli elencati in NKCS_MODULI_ATTIVI.
 * Ogni modulo vive in inc/moduli/<slug>/ e deve esporre un
 * file modulo.php, che è il suo unico punto di ingresso.
 *
 * Struttura attesa di un modulo:
 *   inc/moduli/<slug>/modulo.php   → hook, CPT, query, render
 *   Gli stili dei moduli a shortcode vivono in scss/modules/shortcode/
 *   (quelli dei blocchi di inc/blocks/ in scss/modules/blocks/) e vanno
 *   aggiunti a scss/style.scss, non dentro inc/moduli/. — NKCS220926
 *
 * Il JS resta centralizzato in js/main.js: i moduli NON
 * registrano script propri.
 *
 * Per disattivare un modulo su un cliente basta commentare
 * la sua riga in NKCS_MODULI_ATTIVI.
 * ============================================================
 */

// Blocca l'accesso diretto al file
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Cartella base dei moduli, con slash finale.
 */
if (!defined('NKCS_MODULI_DIR')) {
    define('NKCS_MODULI_DIR', get_template_directory() . '/inc/moduli/');
}

/**
 * Elenco dei moduli attivi, nell'ordine di caricamento.
 * Lo slug corrisponde al nome della cartella in inc/moduli/.
 */
const NKCS_MODULI_ATTIVI = [
    'form',
    'pagine-figlie', // NKCS220926 — sostituisce 'lavorazioni': shortcode generici lista/swiper per slug
];
// NKCS170926 — 'necrologi', 'necrologi-social' e 'messaggi-cordoglio' rimossi
// insieme alle loro cartelle: il sito non gestisce più i necrologi (CPT,
// archivio/singolo, swiper, messaggi di cordoglio, pubblicazione social).
// NKCS180926 — 'faq' rimosso: le FAQ usano il blocco di Yoast SEO
// (stili in scss/vendor/_yoast-faq.scss, JS in js/moduli/faq-yoast.js).
// NKCS100926 — 'megamenu' e 'hero-slideshow' rimossi: sono varianti di
// layout (template-parts/menu/mobile/mobile-menu-fixed.php e
// template-parts/hero/slideshow.php, scelte da inc/layout/layout.php),
// non funzionalità spegnibili. Vedi NKCS_LAYOUT.
// NKCS100926 — 'banda-contatti' rimosso: era uno slot riservato ma mai
// riempito (nessun inc/moduli/banda-contatti/modulo.php è mai esistito).
// NKCS220926 — la sezione vive ora in template-parts/banda-contatti.php
// (pattern sincronizzato 278), fuori dai moduli.

/**
 * Verifica se un modulo è dichiarato attivo.
 * Utile nei template per non stampare markup di moduli spenti.
 *
 * @param string $slug Slug del modulo (nome cartella).
 * @return bool
 */
function nkcs_modulo_attivo(string $slug): bool
{
    return in_array($slug, NKCS_MODULI_ATTIVI, true);
}

/**
 * Carica il modulo.php di ogni modulo attivo.
 *
 * Un modulo dichiarato ma non ancora presente su disco viene
 * saltato senza fatal error: serve durante la migrazione, mentre
 * le cartelle vengono create una alla volta. Con WP_DEBUG attivo
 * la mancanza viene comunque loggata.
 *
 * @return void
 */
function nkcs_carica_moduli(): void
{
    foreach (NKCS_MODULI_ATTIVI as $slug) {

        // Lo slug diventa parte di un path: accetto solo minuscole, cifre e trattini
        if (!preg_match('/^[a-z0-9\-]+$/', $slug)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[NKCS] Slug modulo non valido, ignorato: ' . $slug);
            }
            continue;
        }

        $file = NKCS_MODULI_DIR . $slug . '/modulo.php';

        if (!file_exists($file)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[NKCS] Modulo attivo ma non trovato: ' . $slug . '/modulo.php');
            }
            continue;
        }

        require_once $file;
    }
}

nkcs_carica_moduli();
