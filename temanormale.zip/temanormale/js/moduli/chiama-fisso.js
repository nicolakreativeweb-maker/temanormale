// Pulsante "Chiama" fisso — NKCS220926 — template-parts/chiama-fisso.php
// Stessa logica della vecchia mobile bar (js/moduli/mobile-bar.js, ora
// disattivata): si nasconde entro OFFSET px dalla fine della pagina, così
// non copre il footer.

const OFFSET = 300; // px dalla fine pagina entro cui nascondere il pulsante

export function initChiamaFisso() {
    const btn = document.querySelector('.nkcs-chiama-fisso');
    if (!btn) return;

    const update = () => {
        const scrollBottom = window.scrollY + window.innerHeight;
        const docHeight = document.documentElement.scrollHeight;
        btn.classList.toggle('is-hidden', (docHeight - scrollBottom) < OFFSET);
    };

    update();
    window.addEventListener('scroll', update, { passive: true });
    window.addEventListener('resize', update, { passive: true });
}
