<?php

/**
 * Menu mobile — variante mobile-menu fixed (slide da destra) — NKCS100926
 * Spostato da header.php: toggle + pannello. Markup invariato.
 * Interattività (apri/chiudi, accordion sottomenu) in js/moduli/mobile-menu.js → initMobileMenu().
 *
 * NKCS100926 — nel markup originale il toggle vive dentro
 * .header__content (gli serve il flex del genitore per la posizione),
 * mentre il pannello è fratello di <header> (è position:fixed, non gli
 * serve stare lì, ma per non dipendere dall'assenza di transform sugli
 * antenati lo teniamo comunque fuori). Un solo file, reso in due punti
 * da header.php tramite $args['parte']: 'toggle' | 'pannello' (default:
 * entrambi, utile se in futuro serve un'unica chiamata).
 *
 * NKCS100926 — rinominato il blocco BEM: nkcs-megamenu-fixed →
 * nkcs-menu-mobile (tutti gli elementi __*), id nkcs-navbar-toggle →
 * nkcs-menu-mobile-toggle, nkcs-megamenu-close → nkcs-menu-mobile-close.
 * La lista voci sta in <nav class="nkcs-menu-mobile__nav">, con
 * aria-label distinto da quello del menu desktop.
 *
 * NKCS100926 — file rinominato da megamenu-fixed.php (variante
 * NKCS_LAYOUT 'megamenu-fixed' → 'mobile-menu-fixed').
 *
 * NKCS220926 — pulsante "Chiama" fisso in fondo al pannello
 * (.nkcs-menu-mobile__footer), fuori dalla zona che scorre, con il numero
 * in chiaro (solo cornetta + numero, niente etichetta; l'aria-label
 * "Chiama <numero>" resta per gli screen reader). Stesso numero del pulsante flottante
 * (template-parts/chiama-fisso.php): riga Telefoni con lo slug della sede
 * principale, altrimenti la prima riga di Telefoni. Senza numero
 * il pulsante non viene stampato.
 *
 * NKCS230926 — toggle: via l'icona hamburger (img/navbar.png), al suo posto
 * la scritta "Menu" + un "+" a destra (stile testuale, vedi layout/_header.scss).
 * NKCS031126 — toggle: tornato all'hamburger (3 barre, .header__navbar-bars), visibile su tutti i breakpoint.
 * NKCS031126 — pannello a tutto schermo su ogni breakpoint (il toggle hamburger è sempre
 * visibile): a sinistra le voci grandi con sottomenu "a tendina" in griglia a 2 colonne
 * (prima voce "Vedi tutti"), a destra i contatti (email, telefono, indirizzo, social).
 * Il pannello scende dall'alto; niente più barra né pulsante di chiusura propri: l'header resta sopra
 * il pannello e il suo hamburger diventa una X (layout/_header.scss). In fondo al pannello
 * (.nkcs-menu-mobile__footer) c'è anche una freccetta in su che lo chiude (id nkcs-menu-mobile-close). Tolti il pulsante "Chiama" in fondo e l'icona Facebook in lista: ora stanno nei contatti.
 * NKCS111126 — tolta la barra in fondo con la freccetta in su (.nkcs-menu-mobile__footer / #nkcs-menu-mobile-close):
 *              il pannello si chiude dal toggle in header, che a menu aperto diventa "Chiudi" + X Font Awesome.
 * NKCS230926 — barra top del pannello: stesso trattamento del toggle, scritta
 * "Menu" + la "x" di chiusura a destra (prima solo la x in un box 40x40), con
 * misure identiche a quelle dell'header (vedi layout/_menu.scss).
 */

if (!defined('ABSPATH')) exit;

$nkcs_parte = $args['parte'] ?? 'tutto';
?>

<?php if ($nkcs_parte !== 'pannello') : ?>
    <div class="header__navbar no-hover"
        id="nkcs-menu-mobile-toggle"
        role="button" tabindex="0"
        aria-expanded="false"
        aria-controls="nkcs-menu-mobile"
        aria-label="Apri il menu">
        <span class="header__navbar-bars" aria-hidden="true"><span></span><span></span><span></span></span>
        <?php // NKCS111126 — a menu aperto l'hamburger lascia il posto a "Chiudi" + X (visibile solo con aria-expanded="true", vedi layout/_header.scss) ?>
        <span class="header__navbar-close" aria-hidden="true">
            <span class="header__navbar-close-label">Chiudi</span>
            <i class="fa-solid fa-xmark"></i>
        </span>
    </div>
<?php endif; ?>

<?php if ($nkcs_parte !== 'toggle') :
    $nkcs_tree     = nkcs_menu_tree();

    // --- Contatti (colonna destra) — NKCS031126 ---
    // NKCS131126 — contatti della sede principale: in ogni repeater la riga con
    // lo stesso slug della sede (niente più "--tel"), altrimenti la prima riga.
    $nkcs_sede_main = nkcs_contatto('sedi');
    $nkcs_email     = nkcs_contatto_sede('email', $nkcs_sede_main);
    $nkcs_facebook  = nkcs_contatto_sede('facebook', $nkcs_sede_main);
    $nkcs_instagram = nkcs_contatto_sede('instagram', $nkcs_sede_main);
    $nkcs_cell      = nkcs_contatto_sede('telefoni', $nkcs_sede_main);

    $nkcs_indirizzo = $nkcs_sede_main
        ? trim(wp_strip_all_tags(str_replace(['<br>', '<br/>', '<br />'], ', ', $nkcs_sede_main['indirizzo'])))
        : '';
?>
<!-- MENU MOBILE — pannello a tutto schermo, scende dall'alto -->
<div class="nkcs-menu-mobile" id="nkcs-menu-mobile" aria-hidden="true">

    <!-- CONTENUTO -->
    <div class="nkcs-menu-mobile__inner">
        <div class="nkcs-menu-mobile__container">

            <!-- COL MENU (SX) -->
            <div class="nkcs-menu-mobile__col nkcs-menu-mobile__col--menu">
                <nav class="nkcs-menu-mobile__nav" aria-label="Menu principale mobile">
                    <ul class="nkcs-menu-mobile__list">
                        <?php foreach ($nkcs_tree as $node) :
                            $it       = $node['item'];
                            $children = $node['children'];
                            $has_sub  = !empty($children);
                            $href     = wp_make_link_relative($it->url);
                            $target   = $it->target ?: '_self';
                        ?>
                            <li class="nkcs-menu-mobile__item<?= $has_sub ? ' has-sub' : '' ?>">
                                <a href="<?= esc_attr($href) ?>" target="<?= esc_attr($target) ?>"
                                    class="nkcs-menu-mobile__link">
                                    <?= esc_html($it->title) ?>
                                    <?php if ($has_sub) : ?>
                                        <i class="fa-solid fa-angle-down" aria-hidden="true"></i>
                                    <?php endif; ?>
                                </a>

                                <?php if ($has_sub) : ?>
                                    <ul class="nkcs-menu-mobile__sub">
                                        <?php // prima voce automatica verso la pagina della voce padre ?>
                                        <?php if ($href && $href !== '#') : ?>
                                            <li class="nkcs-menu-mobile__sub-all">
                                                <a href="<?= esc_attr($href) ?>" target="<?= esc_attr($target) ?>">Vedi tutti</a>
                                            </li>
                                        <?php endif; ?>

                                        <?php foreach ($children as $child) : ?>
                                            <li>
                                                <a href="<?= esc_attr(wp_make_link_relative($child->url)) ?>"
                                                    target="<?= esc_attr($child->target ?: '_self') ?>">
                                                    <?= esc_html($child->title) ?>
                                                </a>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </nav>
            </div>

            <!-- COL CONTATTI (DX) — NKCS031126 -->
            <div class="nkcs-menu-mobile__col nkcs-menu-mobile__col--contatti">
                <ul class="nkcs-menu-mobile__contatti">

                    <?php if ($nkcs_email) : ?>
                        <li>
                            <span class="nkcs-menu-mobile__contatto-label">Email</span>
                            <a class="nkcs-menu-mobile__contatto" href="<?= esc_url($nkcs_email['href'], ['mailto']) ?>">
                                <i class="fa-solid fa-envelope" aria-hidden="true"></i>
                                <?= esc_html($nkcs_email['indirizzo']) ?>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if ($nkcs_cell) : ?>
                        <li>
                            <span class="nkcs-menu-mobile__contatto-label">Telefono</span>
                            <a class="nkcs-menu-mobile__contatto" href="<?= esc_url($nkcs_cell['href'], ['tel']) ?>">
                                <i class="fa-solid fa-phone" aria-hidden="true"></i>
                                <?= esc_html($nkcs_cell['numero']) ?>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if ($nkcs_indirizzo !== '') : ?>
                        <li>
                            <span class="nkcs-menu-mobile__contatto-label">Dove siamo</span>
                            <?php if (!empty($nkcs_sede_main['link']['url'])) : ?>
                                <a class="nkcs-menu-mobile__contatto"
                                    href="<?= esc_url($nkcs_sede_main['link']['url']) ?>"
                                    target="<?= esc_attr($nkcs_sede_main['link']['target'] ?: '_blank') ?>" rel="noopener">
                                    <i class="fa-solid fa-location-dot" aria-hidden="true"></i>
                                    <?= esc_html($nkcs_indirizzo) ?>
                                </a>
                            <?php else : ?>
                                <span class="nkcs-menu-mobile__contatto">
                                    <i class="fa-solid fa-location-dot" aria-hidden="true"></i>
                                    <?= esc_html($nkcs_indirizzo) ?>
                                </span>
                            <?php endif; ?>
                        </li>
                    <?php endif; ?>

                    <?php if ($nkcs_facebook) : ?>
                        <li>
                            <span class="nkcs-menu-mobile__contatto-label">Facebook</span>
                            <a class="nkcs-menu-mobile__contatto"
                                href="<?= esc_url($nkcs_facebook['link']['url']) ?>"
                                target="<?= esc_attr($nkcs_facebook['link']['target'] ?: '_blank') ?>" rel="noopener">
                                <i class="fa-brands fa-facebook" aria-hidden="true"></i>
                                <?= esc_html($nkcs_facebook['etichetta'] ?: 'Facebook') ?>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if ($nkcs_instagram) : ?>
                        <li>
                            <span class="nkcs-menu-mobile__contatto-label">Instagram</span>
                            <a class="nkcs-menu-mobile__contatto"
                                href="<?= esc_url($nkcs_instagram['link']['url']) ?>"
                                target="<?= esc_attr($nkcs_instagram['link']['target'] ?: '_blank') ?>" rel="noopener">
                                <i class="fa-brands fa-instagram" aria-hidden="true"></i>
                                <?= esc_html($nkcs_instagram['etichetta'] ?: 'Instagram') ?>
                            </a>
                        </li>
                    <?php endif; ?>

                </ul>
            </div>

        </div>
    </div>

</div>
<?php endif; ?>
