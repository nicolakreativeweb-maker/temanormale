// Form Contact Form 7 — toast, reset, stati — NKCS100926 — estratto da main.js (era initFormCf7() dentro l'IIFE NKCS)
export function initFormCf7() {
    const forms = document.querySelectorAll('.wpcf7 form');
    if (!forms.length) return;

    let toastContainer = document.querySelector('.nkcs-cf7-toast__container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.classList.add('nkcs-cf7-toast__container');
        document.body.appendChild(toastContainer);
    }

    function showToast(message, type = 'error') {
        const toast = document.createElement('div');
        toast.classList.add('nkcs-cf7-toast', `nkcs-cf7-toast--${type}`);
        toast.innerHTML = `
            <span class="nkcs-cf7-toast__icon">
                <i class="fa-solid ${type === 'error' ? 'fa-circle-exclamation' : 'fa-circle-check'}"></i>
            </span>
            <span class="nkcs-cf7-toast__message">${message}</span>
            <button class="nkcs-cf7-toast__close" aria-label="Chiudi">
                <i class="fa-solid fa-xmark"></i>
            </button>
        `;
        toastContainer.appendChild(toast);
        requestAnimationFrame(() => toast.classList.add('is-visible'));
        toast.querySelector('.nkcs-cf7-toast__close').addEventListener('click', () => removeToast(toast));
        setTimeout(() => removeToast(toast), 5000);
    }

    function removeToast(toast) {
        toast.classList.remove('is-visible');
        toast.addEventListener('transitionend', () => toast.remove(), { once: true });
    }

    function fadeHide(el, delay, remove = false) {
        setTimeout(() => {
            if (!el) return;
            el.style.transition = 'opacity .4s ease';
            el.style.opacity = '0';
            setTimeout(() => remove ? el.remove() : el.style.display = 'none', 400);
        }, delay);
    }

    function hideResponseOutput(wpcf7) { fadeHide(wpcf7.querySelector('.wpcf7-response-output'), 5000); }
    function hideValidationTips(wpcf7) {
        wpcf7.querySelectorAll('.wpcf7-not-valid-tip').forEach(tip => fadeHide(tip, 3000, true));
    }

    function resetForm(form) {
        const wpcf7 = form.closest('.wpcf7');
        setTimeout(() => {
            form.querySelectorAll('input:not([type="submit"]):not([type="hidden"])').forEach(el => {
                el.type === 'checkbox' || el.type === 'radio' ? el.checked = false : el.value = '';
            });
            form.querySelectorAll('textarea, select').forEach(el => el.value = '');
            const states = ['sent', 'submitting', 'invalid', 'spam', 'failed'];
            form.classList.remove(...states);
            wpcf7?.classList.remove(...states, 'init');
            const output = wpcf7?.querySelector('.wpcf7-response-output');
            if (output) { output.style.display = 'none'; output.style.opacity = '0'; }
            wpcf7?.querySelectorAll('.wpcf7-not-valid-tip').forEach(tip => tip.remove());
            wpcf7?.querySelectorAll('.wpcf7-not-valid').forEach(el => el.classList.remove('wpcf7-not-valid'));
        }, 500);
    }

    forms.forEach(form => {
        const wpcf7 = form.closest('.wpcf7');
        const submit = form.querySelector('.wpcf7-submit');
        let justSent = false;

        wpcf7.addEventListener('wpcf7beforesubmit', () => form.classList.add('is-loading'));
        wpcf7.addEventListener('wpcf7submit', () => form.classList.remove('is-loading'));
        submit?.addEventListener('pointerdown', () => {
            if (submit.disabled) showToast('Devi accettare la privacy policy per continuare.', 'error');
        });
        wpcf7.addEventListener('wpcf7mailsent', () => {
            justSent = true;
            showToast('Messaggio inviato con successo!', 'success');
            hideResponseOutput(wpcf7);
            resetForm(form);
            setTimeout(() => justSent = false, 1500);
        });
        wpcf7.addEventListener('wpcf7invalid', () => {
            if (justSent) return;
            const isPrivacy = form.querySelector('.wpcf7-acceptance.wpcf7-not-valid');
            showToast(isPrivacy ? 'Devi accettare la privacy policy per continuare.' : 'Compila tutti i campi obbligatori.', 'error');
            hideResponseOutput(wpcf7);
            hideValidationTips(wpcf7);
        });
        wpcf7.addEventListener('wpcf7spam', () => {
            if (justSent) return;
            showToast('Invio bloccato. Riprova tra qualche istante.', 'error');
            hideResponseOutput(wpcf7);
            hideValidationTips(wpcf7);
        });
        wpcf7.addEventListener('wpcf7mailfailed', () => {
            if (justSent) return;
            showToast("Errore durante l'invio. Riprova più tardi.", 'error');
            hideResponseOutput(wpcf7);
            hideValidationTips(wpcf7);
        });
    });
}
